package com.example.project.model
/*
 * Zintle Komazi
 * 2019098256
 * EXAM PROJECT CSIP6853
 * 5 JUNE 2024

 */
import androidx.lifecycle.LiveData

class CanvasRepository(private val canvasElementDao: CanvasElementDao) {
    val allCanvasElements: LiveData<List<CanvasElement>> = canvasElementDao.getAllCanvasElements()

    suspend fun insert(canvasElement: CanvasElement) {
        canvasElementDao.insert(canvasElement)
    }

    suspend fun delete(canvasElement: CanvasElement) {
        canvasElementDao.delete(canvasElement)
    }
}
