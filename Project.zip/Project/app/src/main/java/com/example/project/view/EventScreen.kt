package com.example.project.view

/*
 * Zintle Komazi
 * 2019098256
 * EXAM PROJECT CSIP6853
 * 5 JUNE 2024

 */

import android.content.Intent
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.DrawerValue
import androidx.compose.material.ModalDrawer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.rememberDrawerState
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.project.MapsActivity
import com.example.project.R
import com.example.project.viewmodel.UserViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun EventContent(paddingValues: PaddingValues, navController: NavController, userViewModel: UserViewModel) {
    val context = LocalContext.current // Get the context
    val infiniteTransition = rememberInfiniteTransition()

    val rotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 4000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        )
    )

    var offsetY by remember { mutableStateOf(0f) }
    LaunchedEffect(Unit) {
        while (true) {
            offsetY = -10f
            delay(1000)
            offsetY = 10f
            delay(1000)
        }
    }
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(paddingValues)
            .padding(0.dp),
        contentAlignment = Alignment.TopStart
    ) {
        Image(
            painter = painterResource(id = R.drawable.layout1),
            contentDescription = "Background Image",
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues),
            contentAlignment = Alignment.Center // Center the content within the box
        ) {
            Image(
                painter = painterResource(id = R.drawable.map), // Replace with your map icon drawable resource
                contentDescription = "Map Icon",
                modifier = Modifier
                    .size(100.dp)
                    .rotate(rotation) // Apply the rotation animation
                    .offset(y = offsetY.dp) // Apply the floating animation
                    .clickable {
                        val intent = Intent(context, MapsActivity::class.java)
                        context.startActivity(intent)
                    }
            )
        }
    }
}

@Composable
fun EventScreen(navController: NavController, userViewModel: UserViewModel, selectedTab: MutableState<Int>) {
    EventModalDrawerComponent(navController = navController, userViewModel = userViewModel, selectedTab = selectedTab)

}


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EventModalDrawerComponent(navController: NavController, userViewModel: UserViewModel, selectedTab: MutableState<Int>) {
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val coroutineScope = rememberCoroutineScope()
    val user by userViewModel.currentUser.observeAsState()
    val isLogoutDialogVisible by userViewModel.isLogoutDialogVisible.observeAsState(false)

    ModalDrawer(
        drawerState = drawerState,
        drawerContent = {
            DrawerHeader(user, userViewModel, navController)
            DrawerItems(navController, selectedTab, userViewModel)
        },
        gesturesEnabled = drawerState.isOpen
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("${user?.name ?: "User"} Maps",color = Color.White) },
                    navigationIcon = {
                        IconButton(onClick = { coroutineScope.launch { drawerState.open() } }) {
                            Icon(Icons.Filled.Menu, contentDescription = "Menu",tint = Color.White)
                        }
                    },
                    colors = TopAppBarDefaults.smallTopAppBarColors(
                        containerColor = Color(android.graphics.Color.rgb(107, 64, 246))
                    )
                )
            },
            bottomBar = { HomeBottomBar(navController, selectedTab) }
        ) { paddingValues ->
            EventContent(paddingValues, navController, userViewModel)
        }
    }

    if (isLogoutDialogVisible) {
        LogoutDialog(
            user = user,
            onConfirm = {
                userViewModel.logout()
                navController.navigate("main") {
                    popUpTo("home") { inclusive = true }
                }
            },
            onDismiss = {
                userViewModel.hideLogoutDialog()
            }
        )
    }
}







