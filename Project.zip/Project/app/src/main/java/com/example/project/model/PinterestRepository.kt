package com.example.project.model

/*
 * Zintle Komazi
 * 2019098256
 * EXAM PROJECT CSIP6853
 * 5 JUNE 2024

 */

import androidx.lifecycle.LiveData


class PinterestRepository(private val pinterestDao: PinterestDao) {

    fun getAllMemories(): LiveData<List<PinterestMemory>> = pinterestDao.getAllMemories()

    suspend fun insertMemory(memory: PinterestMemory) {
        pinterestDao.insertMemory(memory)
    }
}
