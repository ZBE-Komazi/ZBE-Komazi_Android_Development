package com.example.project.view

/*
 * Zintle Komazi
 * 2019098256
 * EXAM PROJECT CSIP6853
 * 5 JUNE 2024

 */

import android.content.Intent
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutLinearInEasing
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.Button
import androidx.compose.material.ButtonDefaults
import androidx.compose.material.Card
import androidx.compose.material.DrawerValue
import androidx.compose.material.ModalDrawer
import androidx.compose.material.Text
import androidx.compose.material.TextField
import androidx.compose.material.TextFieldDefaults
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Event
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Message
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.rememberDrawerState
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.project.MapsActivity
import com.example.project.R
import com.example.project.model.Invitation
import com.example.project.viewmodel.InvitationViewModel
import com.example.project.viewmodel.UserViewModel
import kotlinx.coroutines.launch
import kotlin.math.abs

@Composable
fun InvitationScreen(navController: NavController, userViewModel: UserViewModel, invitationViewModel: InvitationViewModel, selectedTab: MutableState<Int>) {
    InvitationModalDrawerComponent(navController = navController, userViewModel = userViewModel, invitationViewModel = invitationViewModel, selectedTab = selectedTab)
}


@Composable
fun InvitationContent(
    paddingValues: PaddingValues,
    navController: NavController,
    userViewModel: UserViewModel,
    invitationViewModel: InvitationViewModel,
) {
    val invitations = invitationViewModel.allInvitations.observeAsState(initial = emptyList()).value
    val listState = rememberLazyListState()
    val coroutineScope = rememberCoroutineScope()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(0.dp),
        contentAlignment = Alignment.TopStart
    ) {
        Image(
            painter = painterResource(id = R.drawable.transparent),
            contentDescription = "Background Image",
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(
                modifier = Modifier.fillMaxHeight(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    IconButton(
                        onClick = {
                            coroutineScope.launch {
                                val targetIndex =
                                    (listState.firstVisibleItemIndex - 1).coerceAtLeast(0)
                                listState.animateScrollToItem(targetIndex)
                            }
                        },
                        enabled = listState.firstVisibleItemIndex > 0
                    ) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Previous")
                    }

                    IconButton(
                        onClick = {
                            coroutineScope.launch {
                                val targetIndex =
                                    (listState.firstVisibleItemIndex + 1).coerceAtMost(invitations.size - 1)
                                listState.animateScrollToItem(targetIndex)
                            }
                        },
                        enabled = listState.firstVisibleItemIndex < invitations.size - 1
                    ) {
                        Icon(Icons.Default.ArrowForward, contentDescription = "Next")
                    }
                }
                LazyRow(state = listState) {
                    items(invitations) { invitation ->
                        ThreadsInviteCard(invitation)
                    }
                }
            }
        }
    }
}


@Composable
fun ThreadsInviteCard(invitation: Invitation) {
    var axisY by remember { mutableStateOf(0f) }

    var isAutomaticAnimationActive by remember { mutableStateOf(true) }
    var isCompletingAnimationActive by remember { mutableStateOf(false) }
    var isQuickDragAnimationActive by remember { mutableStateOf(false) }

    var animationDragAmount by remember { mutableStateOf(0f) }

    ThreadsInviteCardHolder(
        frontSide = { CardFrontSide(invitation = invitation) },
        backSide = { CardBackSide() },
        positionAxisY = if (isAutomaticAnimationActive) {
            val automaticTurningAnimation = remember { Animatable(axisY) }
            LaunchedEffect(isAutomaticAnimationActive) {
                if (isAutomaticAnimationActive) {
                    automaticTurningAnimation.animateTo(
                        targetValue = if (axisY >= 0) axisY + 360f else -360f + axisY,
                        animationSpec = infiniteRepeatable(
                            tween(7000, easing = FastOutSlowInEasing)
                        ),
                    )
                }
            }
            automaticTurningAnimation.value
        } else if (isCompletingAnimationActive) {
            val completeTurningAnimation = remember { Animatable(axisY) }
            LaunchedEffect(isCompletingAnimationActive) {
                if (isCompletingAnimationActive) {
                    completeTurningAnimation.animateTo(
                        targetValue = if(abs(axisY.toInt()) % 360 <= 90) 0f
                        else if (abs(axisY.toInt()) % 360 in 91..270)
                            if (axisY > 0) 180f else -180f
                        else if (axisY > 0) 360f else -360f,
                        animationSpec = tween(500, easing = FastOutLinearInEasing)
                    )
                }
            }
            completeTurningAnimation.value
        } else if (isQuickDragAnimationActive) {
            val quickDragAnimation = remember { Animatable(axisY) }
            LaunchedEffect(isQuickDragAnimationActive) {
                if (isQuickDragAnimationActive) {
                    quickDragAnimation.animateTo(
                        targetValue = if (animationDragAmount > 0) 360f * 2 else -360f * 2,
                        animationSpec = tween(1250, easing = LinearEasing)
                    )
                }
            }
            quickDragAnimation.value
        } else {
            axisY
        },
        modifier = Modifier
            .padding(
                horizontal = 24.dp,
                vertical = 24.dp
            )
            .size(width = 300.dp, height = 480.dp)
            .pointerInput(Unit) {
                detectHorizontalDragGestures(
                    onDragStart = { _ ->
                        isAutomaticAnimationActive = false // Stop animation.
                        isCompletingAnimationActive = false // Stop animation.
                    },
                    onDragEnd = {
                        // Stop animations.
                        isAutomaticAnimationActive = false
                        isCompletingAnimationActive = false
                        isQuickDragAnimationActive = false

                        // If user did not drag enough, just show completing animation.
                        if (abs(animationDragAmount) > 12f) {
                            isQuickDragAnimationActive = true
                        } else {
                            isCompletingAnimationActive = true
                        }
                    },
                    onHorizontalDrag = { _, dragAmount ->
                        // Update rotation based on drag.
                        axisY = if (dragAmount < 0) {
                            (axisY - abs(dragAmount)) % 360 // Turn left for negative numbers.
                        } else {
                            (axisY + abs(dragAmount)) % 360 // Turn right for positive numbers.
                        }
                        animationDragAmount = dragAmount // Keep updated drag amount.
                    }
                )
            }
    )
}



// Ensure `CreateInvitationForm` is called and reachable in your navigation graph
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreateInvitationForm(navController: NavController, invitationViewModel: InvitationViewModel) {
    var title by remember { mutableStateOf("") }
    var username by remember { mutableStateOf("") }
    var instagram by remember { mutableStateOf("") }
    var userId by remember { mutableStateOf("") }
    var date by remember { mutableStateOf("") }
    var time by remember { mutableStateOf("") }
    var userImage by remember { mutableStateOf(R.drawable.ic_user_avatar) }
    var userQrCode by remember { mutableStateOf(R.drawable.ic_qr_code) }

    // Using a consistent style theme
    val typography = MaterialTheme.typography
    val colors = MaterialTheme.colorScheme
    val textFieldColors = TextFieldDefaults.textFieldColors(
        cursorColor = colors.onSurface,
        focusedIndicatorColor = colors.primary, // color for the bottom line when TextField is focused
        unfocusedIndicatorColor = colors.onSurface.copy(alpha = 0.5f) // color for the bottom line when TextField is unfocused
    )

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("Create New Invitation", style = typography.titleSmall, color = colors.primary)
        Spacer(modifier = Modifier.height(16.dp))
        TextField(
            value = title,
            onValueChange = { title = it },
            label = { Text("Event Title") },
            singleLine = true,
            colors = textFieldColors
        )
        TextField(
            value = username,
            onValueChange = { username = it },
            label = { Text("Username") },
            singleLine = true,
            colors = textFieldColors
        )
        TextField(
            value = instagram,
            onValueChange = { instagram = it },
            label = { Text("Instagram") },
            singleLine = true,
            colors = textFieldColors
        )
        TextField(
            value = userId,
            onValueChange = { userId = it },
            label = { Text("User ID") },
            singleLine = true,
            colors = textFieldColors
        )
        TextField(
            value = date,
            onValueChange = { date = it },
            label = { Text("Date") },
            singleLine = true,
            colors = textFieldColors
        )
        TextField(
            value = time,
            onValueChange = { time = it },
            label = { Text("Time") },
            singleLine = true,
            colors = textFieldColors
        )
        Button(
            onClick = {
                invitationViewModel.createInvitation(title, username, instagram, userId, date, time, userImage, userQrCode)
                navController.popBackStack()
            },
            colors = ButtonDefaults.buttonColors(backgroundColor = colors.primary)
        ) {
            Text("Submit Invitation", color = colors.onPrimary)
        }
    }
}




@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InvitationModalDrawerComponent(navController: NavController, userViewModel: UserViewModel, invitationViewModel: InvitationViewModel, selectedTab: MutableState<Int>) {
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val coroutineScope = rememberCoroutineScope()
    val user by userViewModel.currentUser.observeAsState()
    val isLogoutDialogVisible by userViewModel.isLogoutDialogVisible.observeAsState(false)

    ModalDrawer(
        drawerState = drawerState,
        drawerContent = {
            DrawerHeader(user, userViewModel, navController)
            DrawerItems(navController, selectedTab, userViewModel)  // Pass the invitationViewModel here if needed for the drawer
        },
        gesturesEnabled = drawerState.isOpen
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("${user?.name ?: "User"}'s Invitations",color = Color(0xFFFFA500)) },  // Updated title to reflect the content
                    navigationIcon = {
                        IconButton(onClick = { coroutineScope.launch { drawerState.open() } }) {
                            Icon(Icons.Filled.Menu, contentDescription = "Menu",tint = Color(0xFFFFA500))
                        }
                    },
                    colors = TopAppBarDefaults.smallTopAppBarColors(
                        containerColor = Color(android.graphics.Color.rgb(107, 64, 246))
                    )
                )
            },
            bottomBar = { InviteBottomBar(navController, selectedTab) }
        ) { paddingValues ->
            InvitationContent(paddingValues, navController, userViewModel, invitationViewModel)  // Ensure the InvitationContent receives all required parameters
        }
    }

    if (isLogoutDialogVisible) {
        LogoutDialog(
            user = user,
            onConfirm = {
                userViewModel.logout()
                navController.navigate("main") {
                    popUpTo("home") { inclusive = true }
                }
            },
            onDismiss = {
                userViewModel.hideLogoutDialog()
            }
        )
    }
}

//begins


/**
 * This holder manages logic to show correct side of the card.
 */
@Composable
fun ThreadsInviteCardHolder(
    modifier: Modifier = Modifier,
    positionAxisY: Float,
    frontSide: @Composable () -> Unit = {},
    backSide: @Composable () -> Unit = {},
) {
    Card(
        modifier = modifier
            .graphicsLayer {
                rotationY = positionAxisY // Move card according to value of customY.
                cameraDistance = 14f * density
            },
    ) {

        // Here, logic is about coordinate system such as [0..90], [91..270], [270..360].
        if (abs(positionAxisY.toInt()) % 360 <= 90) {
            Box(
                Modifier.fillMaxSize()
            ) {
                frontSide()
            }
        } else if (abs(positionAxisY.toInt()) % 360 in 91..270) {
            Box(
                Modifier
                    .fillMaxSize()
                    .graphicsLayer {
                        rotationY = 180f // Important to avoid mirror effect.
                    },
            ) {
                backSide()
            }
        } else {
            Box(
                Modifier.fillMaxSize()
            ) {
                frontSide()
            }
        }
    }
}


@Composable
fun CardBackSide() {

    // All card surface.
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White),
        contentAlignment = Alignment.Center,
    ) {

        // Top black half circle.
        CardBlackHalfCircles(modifier = Modifier.align(alignment = Alignment.TopCenter))

        Image(
            modifier = Modifier.size(size = 160.dp),
            painter = painterResource(id = R.drawable.ic_threads_black),
            contentDescription =""
        )

        // Bottom black half circle.
        CardBlackHalfCircles(modifier = Modifier.align(alignment = Alignment.BottomCenter))
    }
}

@Composable
@Preview
fun CardBackSidePreview() {
    CardBackSide()
}


private val spaceBetweenItems = 28.dp
private val framePadding = 24.dp

@Composable
fun CardFrontSide(
    invitation: Invitation
) {

    // All card surface.
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White),
        contentAlignment = Alignment.Center,
    ) {

        // Top black half circle.
        CardBlackHalfCircles(modifier = Modifier.align(alignment = Alignment.TopCenter))


        // Card content.
        CardContent(
            date = invitation.date,
            time = invitation.time,
            instagram = invitation.instagram,
            userId = invitation.userId,
            username = invitation.username,
            userImage = invitation.userImage,
            userQrCode = invitation.userQrCode
        )

        // Bottom black half circle.
        CardBlackHalfCircles(modifier = Modifier.align(alignment = Alignment.BottomCenter))
    }
}

@Composable
fun CardBlackHalfCircles(
    modifier: Modifier
) {
    Canvas(
        modifier = modifier
            .border(color = Color.Magenta, width = 2.dp)
    ) {
        drawCircle(
            color = Color.Black,
            radius = 24.dp.toPx()
        )
    }
}

@Composable
fun CardContent(
    date: String,
    time: String,
    instagram: String,
    userId: String,
    username: String,
    userImage: Int,
    userQrCode: Int,
) {
    Column (
        modifier = Modifier
    ) {

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {

            CardTitleText(title = "DATE", info = date)

            CardBrand(modifier = Modifier.align(alignment = Alignment.Bottom))
        }

        Spacer(modifier = Modifier.height(spaceBetweenItems))

        CardTitleText(title = "TIME", info = time)

        Spacer(modifier = Modifier.height(spaceBetweenItems))

        CardTitleText(title = "USERNAME", info = username)

        Spacer(modifier = Modifier.height(spaceBetweenItems))

        CardUserQrCode(userQrCode = userQrCode, modifier = Modifier.align(alignment = Alignment.Start))

        Spacer(modifier = Modifier.height(spaceBetweenItems))

        CardDashDivider()

        Spacer(modifier = Modifier.height(spaceBetweenItems))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row (
                verticalAlignment = Alignment.CenterVertically
            ) {

                CardUserImage(userImage = userImage)

                CardInstagram(text = instagram)
            }

            CardUserId(text = userId)
        }
    }
}

@Composable
fun CardTitleText(title: String, info: String) {
    Column {
        Text(
            modifier = Modifier.padding(
                horizontal = framePadding
            ),
            text = title,
            color = Color.Black,
            fontWeight = FontWeight.ExtraBold,
            style = TextStyle(
                fontSize = 12.sp,
                fontFamily = FontFamily.Monospace,
            )
        )

        Text(
            modifier = Modifier.padding(
                horizontal = framePadding
            ),
            text = info,
            color = Color.Black,
            style = TextStyle(
                fontSize = 20.sp,
                fontFamily = FontFamily.Monospace
            )
        )
    }
}

@Composable
fun CardBrand(
    modifier: Modifier
) {
    Image(
        modifier = modifier
            .padding(
                end = framePadding
            )
            .size(size = 42.dp),
        painter = painterResource(id = R.drawable.ic_threads_black),
        contentDescription =""
    )
}

@Composable
fun CardDashDivider() {
    Canvas(
        Modifier
            .fillMaxWidth()
            .height(1.dp)) {
        drawLine(
            color = Color.DarkGray,
            start = Offset(0f, 0f),
            end = Offset(size.width, 0f),
            pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 14f), 0f)
        )
    }
}

@Composable
fun CardUserQrCode(userQrCode: Int, modifier: Modifier) {
    Image(
        modifier = modifier
            .padding(horizontal = framePadding)
            .size(size = 56.dp),
        painter = painterResource(id = userQrCode),
        contentDescription =""
    )
}

@Composable
fun CardUserImage(userImage: Int) {
    Image(
        modifier = Modifier
            .padding(start = framePadding)
            .size(size = 42.dp)
            .clip(CircleShape) ,
        contentScale = ContentScale.Crop,
        painter = painterResource(id = userImage),
        contentDescription = ""
    )
}

@Composable
fun CardInstagram(text: String) {
    Text(
        modifier = Modifier.padding(start = 16.dp),
        text = text,
        color = Color.Black,
        fontWeight = FontWeight.SemiBold,
        style = TextStyle(
            fontSize = 12.sp,
            fontFamily = FontFamily.Default,
            letterSpacing = 0.7.sp,
        )
    )
}

@Composable
fun CardUserId(text: String) {
    Text(
        modifier = Modifier.padding(end = framePadding),
        text = text,
        color = Color.Black,
        fontWeight = FontWeight.Light,
        style = TextStyle(
            fontSize = 14.sp,
            fontFamily = FontFamily.Default,
            letterSpacing = 1.sp,
        )
    )
}


@Composable
fun InviteBottomBar(navController: NavController, selectedTab: MutableState<Int>) {
    var showDialog by remember { mutableStateOf(false) }
    val context = LocalContext.current // Get the context
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(72.dp)  // Set a fixed height for the bottom navigation bar area
    ) {
        NavigationBar(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth(),
            containerColor = Color(android.graphics.Color.rgb(107, 64, 246))
        ) {
            NavigationBarItem(
                icon = { Icon(Icons.Filled.Home, contentDescription = "Home", tint = Color(0xFFFFA500)) },
                label = { androidx.compose.material3.Text("HOME", color = Color.White) },
                selected = selectedTab.value == 0,
                onClick = {
                    selectedTab.value = 0
                    navController.navigate("home")
                }
            )

            NavigationBarItem(
                icon = { Icon(Icons.Filled.Event, contentDescription = "Event", tint = Color(0xFFFFA500)) },
                label = { androidx.compose.material3.Text("MAP", color = Color.White) },
                selected = selectedTab.value == 1,
                onClick = {
                    selectedTab.value = 1
                    // Launch MapsActivity
                    val intent = Intent(context, MapsActivity::class.java)
                    context.startActivity(intent)
                }
            )

            Spacer(modifier = Modifier.weight(1f, true))  // Dynamic spacing for alignment

            NavigationBarItem(
                icon = { Icon(Icons.Filled.Notifications, contentDescription = "Notify", tint = Color(0xFFFFA500)) },
                label = { androidx.compose.material3.Text("NOTIFY", color = Color.White) },
                selected = selectedTab.value == 2,
                onClick = {
                    selectedTab.value = 2
                    navController.navigate("notifyBottomNav")
                }
            )

            NavigationBarItem(
                icon = { Icon(Icons.Filled.Message, contentDescription = "Message", tint = Color(0xFFFFA500)) },
                label = { androidx.compose.material3.Text("BOT", color = Color.White) },
                selected = selectedTab.value == 3,
                onClick = {
                    selectedTab.value = 3
                    navController.navigate("messageBottomNav")
                }
            )
        }

        FloatingActionButton(
            onClick = { navController.navigate("createInvitation") },
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 10.dp)
                .size(60.dp),
            containerColor = MaterialTheme.colorScheme.secondary
        ) {
            Icon(
                imageVector = Icons.Filled.Add,
                contentDescription = "Add",
                tint = Color(0xFFFFA500),
                modifier = Modifier.size(36.dp)
            )
        }
    }
}
