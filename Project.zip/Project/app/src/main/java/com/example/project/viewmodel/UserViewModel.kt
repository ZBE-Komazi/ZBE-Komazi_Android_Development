package com.example.project.viewmodel

/*
 * Zintle Komazi
 * 2019098256
 * EXAM PROJECT CSIP6853
 * 5 JUNE 2024

 */

import android.net.Uri
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.project.model.User
import com.example.project.model.UserRepository
import kotlinx.coroutines.launch


class UserViewModel(private val userRepository: UserRepository) : ViewModel() {

    val currentUser = MutableLiveData<User?>()
    // LiveData to track if the user is logged in
    private val _isLoggedIn = MutableLiveData<Boolean>(false)
    val isLoggedIn: LiveData<Boolean> = _isLoggedIn

    // LiveData for logout dialog visibility
    private val _isLogoutDialogVisible = MutableLiveData<Boolean>(false)
    val isLogoutDialogVisible: LiveData<Boolean> = _isLogoutDialogVisible

    fun registerUser(user: User, onSuccess: () -> Unit, onError: (String) -> Unit) {
        viewModelScope.launch {
            try {
                userRepository.registerUser(user)
                _isLoggedIn.value = true
                currentUser.value = user
                onSuccess()
            } catch (e: Exception) {
                onError(e.message ?: "Error registering user")
            }
        }
    }

    fun loginUser(email: String, password: String, onResult: (User?, String?) -> Unit) {
        viewModelScope.launch {
            val user = userRepository.loginUser(email, password)
            if (user != null) {
                currentUser.value = user
                _isLoggedIn.value = true
                onResult(user, null)
            } else {
                onResult(null, "Invalid credentials")
            }
        }
    }

    fun logout() {
        _isLoggedIn.value = false
        currentUser.value = null
        _isLogoutDialogVisible.value = false
    }

    fun updateProfilePicture(email: String, uri: Uri) {
        viewModelScope.launch {
            userRepository.updateProfilePicture(email, uri.toString())
            val updatedUser = currentUser.value?.apply {
                profilePictureUri = uri.toString()
            }
            currentUser.value = updatedUser
        }
    }

    fun resetPassword(email: String, newPassword: String, onResult: (Boolean, String?) -> Unit) {
        viewModelScope.launch {
            try {
                val success = userRepository.resetPassword(email, newPassword)
                onResult(success, null)
            } catch (e: Exception) {
                onResult(false, e.message ?: "Error resetting password")
            }
        }
    }

    fun showLogoutDialog() {
        _isLogoutDialogVisible.value = true
    }

    fun hideLogoutDialog() {
        _isLogoutDialogVisible.value = false
    }

    fun updateUserDetails(email: String, name: String, surname: String, phone: String, country: String, onResult: (Boolean, String?) -> Unit) {
        viewModelScope.launch {
            try {
                userRepository.updateUserDetails(email, name, surname, phone, country)
                currentUser.value = currentUser.value?.copy(name = name, surname = surname, phone = phone, country = country)
                onResult(true, null)
            } catch (e: Exception) {
                onResult(false, e.message ?: "Error updating user details")
            }
        }
    }

}


class UserViewModelFactory(private val userRepository: UserRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(UserViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return UserViewModel(userRepository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
