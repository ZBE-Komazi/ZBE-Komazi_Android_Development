package com.example.project.view


/*
 * Zintle Komazi
 * 2019098256
 * EXAM PROJECT CSIP6853
 * 5 JUNE 2024

 */


import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.DrawerValue
import androidx.compose.material.ModalDrawer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.rememberDrawerState
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.project.R
import com.example.project.viewmodel.UserViewModel
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(navController: NavController, userViewModel: UserViewModel, selectedTab: MutableState<Int>) {
    SettingsModalDrawerComponent(navController = navController, userViewModel = userViewModel, selectedTab = selectedTab)

}


@Composable
fun SettingsContent(paddingValues: PaddingValues, navController: NavController, userViewModel: UserViewModel) {
    // Toggle variable to switch between dark and light themes
    var darkTheme by remember { mutableStateOf(false) }

    // Determine which icon to display based on the theme
    val iconId = if (darkTheme) R.drawable.sun else R.drawable.moon

    // Animate the rotation of the icon when theme is switched
    val rotationAngle by animateFloatAsState(targetValue = if (darkTheme) 180f else 0f)
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(paddingValues)
            .padding(16.dp),
        contentAlignment = Alignment.TopStart
    ) {
        Column(
            modifier = Modifier.fillMaxHeight(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            IconButton(onClick = { darkTheme = !darkTheme }) {
                Icon(
                    // Set the icon image based on the selected theme
                    painter = painterResource(id = iconId),
                    contentDescription = null,
                    // Set the icon tint color based on the selected theme
                    tint = MaterialTheme.colorScheme.onBackground,
                    // Apply rotation animation to the icon
                    modifier = Modifier
                        .size(100.dp)
                        .graphicsLayer(rotationZ = rotationAngle),
                )

            }
        }
    }
}




@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsModalDrawerComponent(navController: NavController, userViewModel: UserViewModel, selectedTab: MutableState<Int>) {
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val coroutineScope = rememberCoroutineScope()
    val user by userViewModel.currentUser.observeAsState()
    val isLogoutDialogVisible by userViewModel.isLogoutDialogVisible.observeAsState(false)

    ModalDrawer(
        drawerState = drawerState,
        drawerContent = {
            DrawerHeader(user, userViewModel, navController)
            DrawerItems(navController, selectedTab, userViewModel)
        },
        gesturesEnabled = drawerState.isOpen
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("${user?.name ?: "User"} Settings",color = Color.White) },
                    navigationIcon = {
                        IconButton(onClick = { coroutineScope.launch { drawerState.open() } }) {
                            Icon(Icons.Filled.Menu, contentDescription = "Menu",tint = Color.White)
                        }
                    },
                    colors = TopAppBarDefaults.smallTopAppBarColors(
                        containerColor = Color(android.graphics.Color.rgb(107, 64, 246))
                    )
                )
            },
            bottomBar = { HomeBottomBar(navController, selectedTab) }
        ) { paddingValues ->
            SettingsContent(paddingValues, navController, userViewModel)
        }
    }

    if (isLogoutDialogVisible) {
        LogoutDialog(
            user = user,
            onConfirm = {
                userViewModel.logout()
                navController.navigate("main") {
                    popUpTo("home") { inclusive = true }
                }
            },
            onDismiss = {
                userViewModel.hideLogoutDialog()
            }
        )
    }
}



