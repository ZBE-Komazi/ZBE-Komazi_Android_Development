package com.example.project.model


/*
 * Zintle Komazi
 * 2019098256
 * EXAM PROJECT CSIP6853
 * 5 JUNE 2024

 */
import androidx.lifecycle.LiveData


class InvitationRepository(private val dao: InvitationDao) {
    val allInvitations: LiveData<List<Invitation>> = dao.getAllInvitations()

    suspend fun insertInvitation(invitation: Invitation) {
        dao.insertInvitation(invitation)
    }
}
