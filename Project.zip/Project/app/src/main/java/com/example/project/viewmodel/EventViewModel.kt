package com.example.project.viewmodel


/*
 * Zintle Komazi
 * 2019098256
 * EXAM PROJECT CSIP6853
 * 5 JUNE 2024

 */

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.project.model.Event
import com.example.project.model.EventRepository
import kotlinx.coroutines.launch

class EventViewModel(private val repository: EventRepository) : ViewModel() {
    val allEvents: LiveData<List<Event>> = repository.allEvents
    val archivedEvents: LiveData<List<Event>> = repository.archivedEvents
    fun insert(event: Event) = viewModelScope.launch { repository.insert(event) }
    fun delete(event: Event) = viewModelScope.launch { repository.delete(event) }
    fun archive(event: Event) = viewModelScope.launch {
        val archivedEvent = event.copy(isArchived = true)
        repository.update(archivedEvent)
    }
}

class EventViewModelFactory(private val repository: EventRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(EventViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return EventViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}