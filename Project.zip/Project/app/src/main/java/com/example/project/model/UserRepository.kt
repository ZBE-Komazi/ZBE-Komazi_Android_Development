package com.example.project.model

/*
 * Zintle Komazi
 * 2019098256
 * EXAM PROJECT CSIP6853
 * 5 JUNE 2024

 */

class UserRepository(private val userDao: UserDao) {
    suspend fun registerUser(user: User) = userDao.insertUser(user)

    suspend fun loginUser(email: String, password: String): User? {
        val user = userDao.getUserByEmail(email)
        if (user != null && user.password == password) {
            return user
        }
        return null
    }

    suspend fun updateProfilePicture(email: String, uri: String) {
        userDao.updateProfilePictureUri(email, uri)
    }


    suspend fun resetPassword(email: String, newPassword: String): Boolean {
        val user = userDao.getUserByEmail(email)
        return if (user != null) {
            userDao.updatePassword(email, newPassword)
            true
        } else {
            false
        }
    }

    suspend fun updateUserDetails(email: String, name: String, surname: String, phone: String, country: String) {
        val user = userDao.getUserByEmail(email)
        if (user != null) {
            val updatedUser = user.copy(name = name, surname = surname, phone = phone, country = country)
            userDao.insertUser(updatedUser)
        }
    }

}
