package com.example.project.view

/*
 * Zintle Komazi
 * 2019098256
 * EXAM PROJECT CSIP6853
 * 5 JUNE 2024

 */



import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.DrawerValue
import androidx.compose.material.ModalDrawer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.rememberDrawerState
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.project.viewmodel.UserViewModel
import kotlinx.coroutines.launch


@Composable
fun MessageScreen(navController: NavController, userViewModel: UserViewModel, selectedTab: MutableState<Int>) {
    MessageModalDrawerComponent(navController = navController, userViewModel = userViewModel, selectedTab = selectedTab)

}


@Composable
fun MessageContent(paddingValues: PaddingValues, navController: NavController, userViewModel: UserViewModel) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(paddingValues)
            .padding(16.dp),
        contentAlignment = Alignment.TopStart
    ) {
        Column(
            modifier = Modifier.fillMaxHeight(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {

        }
    }
}



@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MessageModalDrawerComponent(navController: NavController, userViewModel: UserViewModel, selectedTab: MutableState<Int>) {
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val coroutineScope = rememberCoroutineScope()
    val user by userViewModel.currentUser.observeAsState()
    val isLogoutDialogVisible by userViewModel.isLogoutDialogVisible.observeAsState(false)

    ModalDrawer(
        drawerState = drawerState,
        drawerContent = {
            DrawerHeader(user, userViewModel, navController)
            DrawerItems(navController, selectedTab, userViewModel)
        },
        gesturesEnabled = drawerState.isOpen
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("${user?.name ?: "User"} Messages",color = Color.White) },
                    navigationIcon = {
                        IconButton(onClick = { coroutineScope.launch { drawerState.open() } }) {
                            Icon(Icons.Filled.Menu, contentDescription = "Menu",tint = Color.White)
                        }
                    },
                    colors = TopAppBarDefaults.smallTopAppBarColors(
                        containerColor = Color(android.graphics.Color.rgb(107, 64, 246))
                    )
                )
            },
            bottomBar = { HomeBottomBar(navController, selectedTab) }
        ) { paddingValues ->
            MessageContent(paddingValues, navController, userViewModel)
        }
    }

    if (isLogoutDialogVisible) {
        LogoutDialog(
            user = user,
            onConfirm = {
                userViewModel.logout()
                navController.navigate("main") {
                    popUpTo("home") { inclusive = true }
                }
            },
            onDismiss = {
                userViewModel.hideLogoutDialog()
            }
        )
    }
}
