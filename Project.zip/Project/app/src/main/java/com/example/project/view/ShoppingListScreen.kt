package com.example.project.view

/*
 * Zintle Komazi
 * 2019098256
 * EXAM PROJECT CSIP6853
 * 5 JUNE 2024

 */

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.AlertDialog
import androidx.compose.material.Card
import androidx.compose.material.DrawerValue
import androidx.compose.material.DropdownMenuItem
import androidx.compose.material.ModalDrawer
import androidx.compose.material.Text
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Event
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Message
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.rememberDrawerState
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.TextField
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.project.R
import com.example.project.model.ShoppingList
import com.example.project.model.toJson
import com.example.project.viewmodel.ShoppingListViewModel
import com.example.project.viewmodel.UserViewModel
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import kotlinx.coroutines.launch

@Composable
fun ShoppingListScreen(
    navController: NavController,
    userViewModel: UserViewModel,
    shoppingListViewModel: ShoppingListViewModel,
    selectedTab: MutableState<Int>
) {
    ShoppingListModalDrawerComponent(
        navController = navController,
        userViewModel = userViewModel,
        shoppingListViewModel = shoppingListViewModel,
        selectedTab = selectedTab
    )
}

@Composable
fun ShoppingListContent(
    paddingValues: PaddingValues,
    navController: NavController,
    userViewModel: UserViewModel,
    shoppingListViewModel: ShoppingListViewModel
) {
    val shoppingLists by shoppingListViewModel.allShoppingLists.observeAsState(emptyList())
    val context = LocalContext.current
    var showParticipantsDialog by remember { mutableStateOf(false) }
    var participants by remember { mutableStateOf(emptyList<String>()) }
    Box(
        modifier = Modifier
            .fillMaxSize()
    ) {
        // Background image
        Image(
            painter = painterResource(id = R.drawable.transparent),
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp),
            contentAlignment = Alignment.TopStart
        ) {
            Column(
                modifier = Modifier
                    .fillMaxHeight()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    text = "Create A Shopping List",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.primary
                )

                shoppingLists.forEach { shoppingList ->
                    val participantsList = shoppingList.participants.toList()
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(150.dp) // Adjust the height to make the card smaller
                            .padding(vertical = 8.dp)
                            .clickable {
                                navController.navigate("shoppingListDetail/${shoppingList.id}")
                            }
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(Color(0xFFFFA500)), // Ensure background color is applied
                            contentAlignment = Alignment.Center
                        ) {
                            Image(
                                painter = painterResource(id = R.drawable.cart), // Replace with the new image
                                contentDescription = "Business Logo",
                                modifier = Modifier.size(100.dp), // Adjust size as needed
                                contentScale = ContentScale.Crop
                            )
                            Column(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .background(Color.Black.copy(alpha = 0.6f))
                                    .padding(16.dp),
                                verticalArrangement = Arrangement.Top,
                                horizontalAlignment = Alignment.Start
                            ) {
                                Text(
                                    text = shoppingList.title,
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                    color = Color.White,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.fillMaxWidth()
                                )
                                Text(
                                    text = shoppingList.category,
                                    style = MaterialTheme.typography.titleSmall,
                                    color = Color.White,
                                    textAlign = TextAlign.Left
                                )
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(top = 8.dp)
                                        .verticalScroll(rememberScrollState())
                                ) {
                                    participantsList.take(5).forEach { participant ->
                                        Text(
                                            text = "• $participant",
                                            style = MaterialTheme.typography.titleSmall,
                                            color = Color.White,
                                            modifier = Modifier.padding(vertical = 2.dp)
                                        )
                                    }
                                    if (participantsList.size > 5) {
                                        Text(
                                            text = "• More...",
                                            style = MaterialTheme.typography.titleSmall,
                                            color = Color.White,
                                            modifier = Modifier
                                                .padding(vertical = 2.dp)
                                                .clickable {
                                                    participants = participantsList
                                                    showParticipantsDialog = true
                                                }
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        if (showParticipantsDialog) {
            AlertDialog(
                onDismissRequest = { showParticipantsDialog = false },
                title = { Text("Participants") },
                text = { Text(participants.joinToString("\n") { "• $it" }) },
                confirmButton = {
                    Button(onClick = { showParticipantsDialog = false }) {
                        Text("OK")
                    }
                },
                shape = RoundedCornerShape(16.dp),
                backgroundColor = MaterialTheme.colorScheme.surfaceVariant
            )
        }
    }
}

@Composable
fun AddShoppingListDialog(
    showDialog: Boolean,
    onDismiss: () -> Unit,
    onAdd: (String, String, List<String>) -> Unit
) {
    if (showDialog) {
        var title by rememberSaveable { mutableStateOf("") }
        val categories = listOf("Conference", "Seminar", "Workshop", "Concert", "Festival", "Party", "Exhibition", "Networking", "Sports", "Other")
        var category by rememberSaveable { mutableStateOf(categories.first()) }
        var email by rememberSaveable { mutableStateOf("") }
        val emails = remember { mutableStateListOf<String>() }
        var expanded by remember { mutableStateOf(false) }

        AlertDialog(
            onDismissRequest = onDismiss,
            title = { Text("Add Shopping List") },
            text = {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    TextField(
                        value = title,
                        onValueChange = { title = it },
                        label = { Text("Title") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color.White, RoundedCornerShape(8.dp))
                            .padding(8.dp)
                    )
                    // Category Dropdown
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color.White, RoundedCornerShape(8.dp))
                            .padding(8.dp)
                    ) {
                        TextField(
                            value = category,
                            onValueChange = {},
                            label = { Text("Category") },
                            readOnly = true,
                            trailingIcon = {
                                Icon(Icons.Filled.ArrowDropDown, contentDescription = null, Modifier.clickable { expanded = true })
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color.White, RoundedCornerShape(8.dp))
                        )
                        DropdownMenu(
                            expanded = expanded,
                            onDismissRequest = { expanded = false }
                        ) {
                            categories.forEach { categoryName ->
                                DropdownMenuItem(onClick = {
                                    category = categoryName
                                    expanded = false
                                }) {
                                    Text(categoryName)
                                }
                            }
                        }
                    }
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color.White, RoundedCornerShape(8.dp))
                            .padding(8.dp)
                    ) {
                        TextField(
                            value = email,
                            onValueChange = { email = it },
                            label = { Text("Add Email") },
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(
                            onClick = {
                                if (email.isNotBlank()) {
                                    emails.add(email)
                                    email = ""
                                }
                            },
                            modifier = Modifier
                                .size(36.dp)
                                .background(MaterialTheme.colorScheme.primary, CircleShape)
                        ) {
                            Icon(Icons.Filled.Add, contentDescription = "Add Email", tint = Color.White)
                        }
                    }
                    Column(
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        emails.forEach {
                            Text(text = it, modifier = Modifier.padding(8.dp))
                        }
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    onAdd(title, category, emails)
                    onDismiss()
                }) {
                    Text("Add")
                }
            },
            dismissButton = {
                Button(onClick = onDismiss) {
                    Text("Cancel")
                }
            },
            shape = RoundedCornerShape(16.dp),
            backgroundColor = MaterialTheme.colorScheme.surfaceVariant
        )
    }
}

fun List<String>.toJson(): String {
    return Gson().toJson(this)
}

fun String.toList(): List<String> {
    return Gson().fromJson(this, object : TypeToken<List<String>>() {}.type)
}


@Composable
fun ShoppingBottomBar(
    navController: NavController,
    selectedTab: MutableState<Int>,
    shoppingListViewModel: ShoppingListViewModel
) {
    var showDialog by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(72.dp)  // Set a fixed height for the bottom navigation bar area
    ) {
        NavigationBar(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth(),
            containerColor = Color(android.graphics.Color.rgb(107, 64, 246))
        ) {
            NavigationBarItem(
                icon = { Icon(Icons.Filled.Home, contentDescription = "Home",tint = Color(0xFFFFA500)) },
                label = { Text("HOME",color = Color.White) },
                selected = selectedTab.value == 0,
                onClick = {
                    selectedTab.value = 0
                    navController.navigate("home")
                }
            )

            NavigationBarItem(
                icon = { Icon(Icons.Filled.Event, contentDescription = "Event",tint = Color(0xFFFFA500)) },
                label = { Text("MAP",color = Color.White) },
                selected = selectedTab.value == 1,
                onClick = {
                    selectedTab.value = 1
                    navController.navigate("eventBottomNav")
                }
            )

            Spacer(modifier = Modifier.weight(1f, true))  // Dynamic spacing for alignment

            NavigationBarItem(
                icon = { Icon(Icons.Filled.Notifications, contentDescription = "Notify",tint = Color(0xFFFFA500)) },
                label = { Text("NOTIFY",color = Color.White) },
                selected = selectedTab.value == 2,
                onClick = {
                    selectedTab.value = 2
                    navController.navigate("notifyBottomNav")
                }
            )

            NavigationBarItem(
                icon = { Icon(Icons.Filled.Message, contentDescription = "Message",tint = Color(0xFFFFA500)) },
                label = { Text("MESSAGE",color = Color.White) },
                selected = selectedTab.value == 3,
                onClick = {
                    selectedTab.value = 3
                    navController.navigate("messageBottomNav")
                }
            )
        }

        FloatingActionButton(
            onClick = { showDialog = true },
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 10.dp)
                .size(60.dp),
            containerColor = MaterialTheme.colorScheme.secondary
        ) {
            Icon(
                imageVector = Icons.Filled.Add,
                contentDescription = "Add",
                tint = Color(0xFFFFA500),
                modifier = Modifier.size(36.dp)
            )
        }
    }

    if (showDialog) {
        AddShoppingListDialog(
            showDialog = showDialog,
            onDismiss = { showDialog = false },
            onAdd = { title, category, participants ->
                val newShoppingList = ShoppingList(
                    title = title,
                    category = category,
                    participants = participants.toJson(),
                    items = "[]" // Initialize with an empty list
                )
                shoppingListViewModel.insert(newShoppingList)
            }
        )
    }
}


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ShoppingListModalDrawerComponent(
    navController: NavController,
    userViewModel: UserViewModel,
    shoppingListViewModel: ShoppingListViewModel,
    selectedTab: MutableState<Int>
) {
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val coroutineScope = rememberCoroutineScope()
    val user by userViewModel.currentUser.observeAsState()
    val isLogoutDialogVisible by userViewModel.isLogoutDialogVisible.observeAsState(false)

    ModalDrawer(
        drawerState = drawerState,
        drawerContent = {
            DrawerHeader(user, userViewModel, navController)
            DrawerItems(navController, selectedTab, userViewModel)
        },
        gesturesEnabled = drawerState.isOpen
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text(" ${user?.name ?: "User"} ShoppingList",color = Color(0xFFFFA500)) },
                    navigationIcon = {
                        IconButton(onClick = { coroutineScope.launch { drawerState.open() } }) {
                            Icon(Icons.Filled.Menu, contentDescription = "Menu",tint = Color(0xFFFFA500))
                        }
                    },
                    colors = TopAppBarDefaults.smallTopAppBarColors(
                        containerColor = Color(android.graphics.Color.rgb(107, 64, 246))
                    )
                )
            },
            bottomBar = { ShoppingBottomBar(navController, selectedTab, shoppingListViewModel) }
        ) { paddingValues ->
            ShoppingListContent(paddingValues, navController, userViewModel, shoppingListViewModel)
        }
    }

    if (isLogoutDialogVisible) {
        LogoutDialog(
            user = user,
            onConfirm = {
                userViewModel.logout()
                navController.navigate("main") {
                    popUpTo("home") { inclusive = true }
                }
            },
            onDismiss = {
                userViewModel.hideLogoutDialog()
            }
        )
    }
}
