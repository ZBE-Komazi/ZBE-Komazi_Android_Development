package com.example.project.model

/*
 * Zintle Komazi
 * 2019098256
 * EXAM PROJECT CSIP6853
 * 5 JUNE 2024
 */

import android.content.Context
import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Update

@Entity(tableName = "event_progress")
data class EventProgress(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val eventId: Int,
    val eventTitle: String,
    val milestone: String,
    val status: String // "Not Started", "In Progress", "Complete"
)

@Dao
interface EventProgressDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProgress(eventProgress: List<EventProgress>)

    @Query("SELECT * FROM event_progress WHERE eventTitle = :eventTitle")
    fun getProgressByEvent(eventTitle: String): LiveData<List<EventProgress>>

    @Update
    suspend fun updateProgress(eventProgress: EventProgress)
}

@Database(entities = [EventProgress::class], version = 1, exportSchema = false)
abstract class EventProgressDatabase : RoomDatabase() {
    abstract fun eventProgressDao(): EventProgressDao

    companion object {
        @Volatile
        private var INSTANCE: EventProgressDatabase? = null

        fun getDatabase(context: Context): EventProgressDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    EventProgressDatabase::class.java,
                    "event_progress_database"
                ).fallbackToDestructiveMigration()
                    .build().also { INSTANCE = it }
            }
    }
}
