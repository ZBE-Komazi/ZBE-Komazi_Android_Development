package com.example.project.model
/*
 * Zintle Komazi
 * 2019098256
 * EXAM PROJECT CSIP6853
 * 5 JUNE 2024

 */
import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.first

val Context.themeDataStore by preferencesDataStore(name = "theme_preferences")

interface AppSettingsRepository {
    suspend fun putThemeString(key: String, value: String)
    suspend fun getThemeString(key: String): Flow<String?>
}

class AppSettingsRepositoryImpl(private val context: Context) : AppSettingsRepository {
    override suspend fun putThemeString(key: String, value: String) {
        val preferencesKey = stringPreferencesKey(key)
        context.themeDataStore.edit { preferences ->
            preferences[preferencesKey] = value
        }
    }

    override suspend fun getThemeString(key: String): Flow<String?> {
        val preferencesKey = stringPreferencesKey(key)
        return context.themeDataStore.data.map { preferences ->
            preferences[preferencesKey]
        }
    }
}
