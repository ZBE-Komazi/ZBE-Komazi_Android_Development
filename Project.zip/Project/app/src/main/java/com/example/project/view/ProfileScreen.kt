package com.example.project.view

/*
 * Zintle Komazi
 * 2019098256
 * EXAM PROJECT CSIP6853
 * 5 JUNE 2024

 */

import android.graphics.Color.rgb
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.DrawerValue
import androidx.compose.material.ModalDrawer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.rememberDrawerState
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import coil.compose.rememberAsyncImagePainter
import com.example.project.R
import com.example.project.viewmodel.UserViewModel
import kotlinx.coroutines.launch


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(navController: NavController, userViewModel: UserViewModel,selectedTab: MutableState<Int>) {

    ProfileModalDrawerComponent(navController = navController, userViewModel = userViewModel, selectedTab = selectedTab)

}


@Composable
fun ProfileContent(paddingValues: PaddingValues, navController: NavController, userViewModel: UserViewModel) {
    val user by userViewModel.currentUser.observeAsState()
    var name by remember { mutableStateOf(user?.name ?: "") }
    var surname by remember { mutableStateOf(user?.surname ?: "") }
    var phone by remember { mutableStateOf(user?.phone ?: "") }
    var country by remember { mutableStateOf(user?.country ?: "") }
    var email by remember {
        mutableStateOf(
            user?.email ?: ""
        )
    } // Assuming email is part of the user data
    var password by remember { mutableStateOf("********") } // Assuming password should not be shown
    var isEditing by remember { mutableStateOf(false) }

    val context = LocalContext.current
    val defaultImage = painterResource(R.drawable.profile) // Default image from res/drawable
    val coroutineScope = rememberCoroutineScope()
    val launcher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let {
            coroutineScope.launch {
                userViewModel.updateProfilePicture(user?.email ?: "", it)
            }
        }
    }
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(paddingValues)
            .padding(0.dp),
        contentAlignment = Alignment.TopStart
    ) {
        Image(
            painter = painterResource(id = R.drawable.layout1),
            contentDescription = "Background Image",
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp),
            contentAlignment = Alignment.TopStart
        ) {
            Column(
                modifier = Modifier.verticalScroll(rememberScrollState())
                    .fillMaxHeight(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {

                Image(
                    painter = if (user?.profilePictureUri != null) rememberAsyncImagePainter(user!!.profilePictureUri) else defaultImage,
                    contentDescription = "Profile Picture",
                    modifier = Modifier
                        .size(100.dp)
                        .clip(CircleShape)
                        .clickable {
                            launcher.launch("image/*")
                        }
                )
                Spacer(modifier = Modifier.height(8.dp))

                if (isEditing) {
                    ProfileField(value = name, label = "Name", onValueChange = { name = it })
                    Spacer(modifier = Modifier.height(8.dp))
                    ProfileField(
                        value = surname,
                        label = "Surname",
                        onValueChange = { surname = it })
                    Spacer(modifier = Modifier.height(8.dp))
                    ProfileField(value = phone, label = "Phone", onValueChange = { phone = it })
                    Spacer(modifier = Modifier.height(8.dp))
                    ProfileField(
                        value = country,
                        label = "Country",
                        onValueChange = { country = it })
                    Spacer(modifier = Modifier.height(8.dp))
                    ProfileField(value = email, label = "Email", enabled = false)
                    Spacer(modifier = Modifier.height(8.dp))
                    ProfileField(value = password, label = "Password", enabled = false)
                    Spacer(modifier = Modifier.height(8.dp))
                } else {
                    ProfileField(value = name, label = "Name", enabled = false)
                    Spacer(modifier = Modifier.height(8.dp))
                    ProfileField(value = surname, label = "Surname", enabled = false)
                    Spacer(modifier = Modifier.height(8.dp))
                    ProfileField(value = phone, label = "Phone", enabled = false)
                    Spacer(modifier = Modifier.height(8.dp))
                    ProfileField(value = country, label = "Country", enabled = false)
                    Spacer(modifier = Modifier.height(8.dp))
                    ProfileField(value = email, label = "Email", enabled = false)
                    Spacer(modifier = Modifier.height(8.dp))
                    ProfileField(value = password, label = "Password", enabled = false)
                }
                Spacer(modifier = Modifier.height(16.dp))
                if (isEditing) {
                    Button(onClick = {
                        userViewModel.updateUserDetails(
                            email = user?.email ?: "",
                            name = name,
                            surname = surname,
                            phone = phone,
                            country = country
                        ) { success, message ->
                            if (success) {
                                isEditing = false
                            } else {
                                // Handle error
                            }
                        }
                    },  modifier = Modifier.fillMaxWidth(),colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFFA500))) {
                        Text(text = "Save",color=Color.Black)
                    }
                } else {
                    Button(onClick = { isEditing = true },  modifier = Modifier.fillMaxWidth(),colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFFA500))) {
                        Text(text = "Edit",color=Color.Black)
                    }
                }
            }
        }
    }
}



@Composable
fun ProfileField(value: String, label: String, onValueChange: (String) -> Unit = {}, enabled: Boolean = true) {
    Column {
        Text(text = label,color= Color.Black)
        TextField(
            value = value,
            onValueChange = onValueChange,
            enabled = enabled,
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(24.dp)
        )
    }
}


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileModalDrawerComponent(navController: NavController, userViewModel: UserViewModel, selectedTab: MutableState<Int>) {
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val coroutineScope = rememberCoroutineScope()
    val user by userViewModel.currentUser.observeAsState()
    val isLogoutDialogVisible by userViewModel.isLogoutDialogVisible.observeAsState(false)

    ModalDrawer(
        drawerState = drawerState,
        drawerContent = {
            DrawerHeader(user, userViewModel, navController)
            DrawerItems(navController, selectedTab, userViewModel)
        },
        gesturesEnabled = drawerState.isOpen
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text(" ${user?.name ?: "User"} Profile",color = Color(0xFFFFA500)) },
                    navigationIcon = {
                        IconButton(onClick = { coroutineScope.launch { drawerState.open() } }) {
                            Icon(Icons.Filled.Menu, contentDescription = "Menu",tint = Color(0xFFFFA500))
                        }
                    },
                    colors = TopAppBarDefaults.smallTopAppBarColors(
                        containerColor = Color(rgb(107, 64, 246))
                    )
                )
            },
            bottomBar = { HomeBottomBar(navController, selectedTab) }
        ) { paddingValues ->
            ProfileContent(paddingValues, navController, userViewModel)
        }
    }

    if (isLogoutDialogVisible) {
        LogoutDialog(
            user = user,
            onConfirm = {
                userViewModel.logout()
                navController.navigate("main") {
                    popUpTo("home") { inclusive = true }
                }
            },
            onDismiss = {
                userViewModel.hideLogoutDialog()
            }
        )
    }
}