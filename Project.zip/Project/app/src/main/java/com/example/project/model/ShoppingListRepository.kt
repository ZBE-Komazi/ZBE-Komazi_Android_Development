package com.example.project.model

/*
 * Zintle Komazi
 * 2019098256
 * EXAM PROJECT CSIP6853
 * 5 JUNE 2024

 */

import androidx.lifecycle.LiveData


class ShoppingListRepository(private val shoppingListDao: ShoppingListDao) {
    val allShoppingLists: LiveData<List<ShoppingList>> = shoppingListDao.getAllShoppingLists()

    suspend fun insert(shoppingList: ShoppingList) {
        shoppingListDao.insert(shoppingList)
    }

    suspend fun delete(shoppingList: ShoppingList) {
        shoppingListDao.delete(shoppingList)
    }

    fun getShoppingListById(id: Int): LiveData<ShoppingList> {
        return shoppingListDao.getShoppingListById(id)
    }
}