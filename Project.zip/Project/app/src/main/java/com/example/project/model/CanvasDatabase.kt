package com.example.project.model
/*
 * Zintle Komazi
 * 2019098256
 * EXAM PROJECT CSIP6853
 * 5 JUNE 2024

 */
import android.content.Context
import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Delete
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
@Entity(tableName = "canvas_elements")
data class CanvasElement(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val type: String,
    val data: String
)

@Dao
interface CanvasElementDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(canvasElement: CanvasElement)

    @Query("SELECT * FROM canvas_elements")
    fun getAllCanvasElements(): LiveData<List<CanvasElement>>

    @Delete
    suspend fun delete(canvasElement: CanvasElement)
}


@Database(entities = [CanvasElement::class], version = 1, exportSchema = false)
abstract class CanvasDatabase : RoomDatabase() {
    abstract fun canvasElementDao(): CanvasElementDao

    companion object {
        @Volatile
        private var INSTANCE: CanvasDatabase? = null

        fun getDatabase(context: Context): CanvasDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    CanvasDatabase::class.java,
                    "canvas_database"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
