package com.example.project.model

/*
 * Zintle Komazi
 * 2019098256
 * EXAM PROJECT CSIP6853
 * 5 JUNE 2024

 */


import androidx.lifecycle.LiveData

// Repository
class EventProgressRepository(private val eventProgressDao: EventProgressDao) {
    suspend fun insertProgress(eventProgress: List<EventProgress>) {
        eventProgressDao.insertProgress(eventProgress)
    }

    fun getProgressByEvent(eventTitle: String): LiveData<List<EventProgress>> {
        return eventProgressDao.getProgressByEvent(eventTitle)
    }

    suspend fun updateProgress(eventProgress: EventProgress) {
        eventProgressDao.updateProgress(eventProgress)
    }
}
