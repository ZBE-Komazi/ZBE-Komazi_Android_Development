package com.example.project.viewmodel

/*
 * Zintle Komazi
 * 2019098256
 * EXAM PROJECT CSIP6853
 * 5 JUNE 2024

 */

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.project.model.AppSettingsRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class SettingsViewModel(private val appSettingsRepository: AppSettingsRepository) : ViewModel() {
    private val _theme = MutableStateFlow<String?>(null)
    val theme = _theme.asStateFlow()

    fun saveTheme(theme: String) {
        viewModelScope.launch {
            appSettingsRepository.putThemeString("theme", theme)
        }
    }

    fun loadTheme() {
        viewModelScope.launch {
            appSettingsRepository.getThemeString("theme").collect { theme ->
                _theme.value = theme
            }
        }
    }
}
