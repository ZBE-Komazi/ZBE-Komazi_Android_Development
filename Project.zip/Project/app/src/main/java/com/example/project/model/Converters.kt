package com.example.project.model

/*
 * Zintle Komazi
 * 2019098256
 * EXAM PROJECT CSIP6853
 * 5 JUNE 2024

 */

import androidx.room.TypeConverter
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.time.LocalDate
import java.time.ZoneId
import java.util.Date

fun Date.toLocalDate(zone: ZoneId = ZoneId.systemDefault()): LocalDate {
    return this.toInstant().atZone(zone).toLocalDate()
}

class Converters {
    @TypeConverter
    fun fromTimestamp(value: Long?): Date? {
        return value?.let { Date(it) }
    }

    @TypeConverter
    fun dateToTimestamp(date: Date?): Long? {
        return date?.time
    }
}


// Convert progressList to JSON string to pass through navigation
fun chartToJson(progressList: List<EventProgress>): String {
    return Gson().toJson(progressList)
}

// Convert JSON string back to List<EventProgress>
fun chartFromJson(json: String): List<EventProgress> {
    val type = object : TypeToken<List<EventProgress>>() {}.type
    return Gson().fromJson(json, type)
}


class DateConverter {
    @TypeConverter
    fun toDate(timestamp: Long?): Date? = timestamp?.let { Date(it) }

    @TypeConverter
    fun toTimestamp(date: Date?): Long? = date?.time
}

fun List<String>.toJson(): String {
    return Gson().toJson(this)
}

fun String.toList(): List<String> {
    return Gson().fromJson(this, object : TypeToken<List<String>>() {}.type)
}

fun List<ShoppingItem>.toItemJson(): String {
    return Gson().toJson(this)
}

fun String.toShoppingItemList(): List<ShoppingItem> {
    return Gson().fromJson(this, object : TypeToken<List<ShoppingItem>>() {}.type)
}
