package com.example.project.view
/*
 * Zintle Komazi
 * 2019098256
 * EXAM PROJECT CSIP6853
 * 5 JUNE 2024

 */

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.DrawerValue
import androidx.compose.material.Icon
import androidx.compose.material.ModalDrawer
import androidx.compose.material.Text
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.rememberDrawerState
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.project.viewmodel.UserViewModel
import kotlinx.coroutines.launch


@Composable
fun CanvasScreen(navController: NavController, userViewModel: UserViewModel, selectedTab: MutableState<Int>) {
    CanvasModalDrawerComponent(navController = navController, userViewModel = userViewModel, selectedTab = selectedTab)
}

@Composable
fun CanvasContent(paddingValues: PaddingValues, navController: NavController, userViewModel: UserViewModel) {
    val brushColor = remember { mutableStateOf(Color.Black) }
    val backgroundColor = remember { mutableStateOf(Color.White) }
    val paths = remember { mutableStateListOf<PathState>() }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(paddingValues)
            .background(backgroundColor.value)
    ) {
        ColorPicker(
            label = "Brush Color",
            selectedColor = brushColor.value,
            onColorSelected = { brushColor.value = it }
        )
        ColorPicker(
            label = "Canvas Background Color",
            selectedColor = backgroundColor.value,
            onColorSelected = { backgroundColor.value = it }
        )
        DrawCanvas(
            brushColor = brushColor.value,
            backgroundColor = backgroundColor.value,
            paths = paths
        )
    }
}

@Composable
fun DrawCanvas(brushColor: Color, backgroundColor: Color, paths: SnapshotStateList<PathState>) {
    val currentPath = remember { mutableStateOf(PathState(brushColor)) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(backgroundColor)
            .pointerInput(Unit) {
                detectDragGestures { change, dragAmount ->
                    change.consume()
                    currentPath.value.path.lineTo(
                        change.position.x,
                        change.position.y
                    )
                    paths.add(currentPath.value.copy())
                }
            }
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            paths.forEach { pathState ->
                drawPath(
                    path = pathState.path,
                    color = pathState.color,
                    style = Stroke(width = 4f, cap = StrokeCap.Round, join = StrokeJoin.Round)
                )
            }
        }
    }
}

@Composable
fun ColorPicker(label: String, selectedColor: Color, onColorSelected: (Color) -> Unit) {
    Column(
        modifier = Modifier.padding(8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(text = label)
        Row {
            ColorButton(Color.Red, onColorSelected)
            ColorButton(Color.Green, onColorSelected)
            ColorButton(Color.Blue, onColorSelected)
            ColorButton(Color.Yellow, onColorSelected)
            ColorButton(Color.Black, onColorSelected)
        }
    }
}

@Composable
fun ColorButton(color: Color, onColorSelected: (Color) -> Unit) {
    Box(
        modifier = Modifier
            .size(40.dp)
            .background(color)
            .clickable { onColorSelected(color) }
            .padding(8.dp)
    )
}

data class PathState(
    val color: Color,
    val path: Path = Path()
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CanvasModalDrawerComponent(navController: NavController, userViewModel: UserViewModel, selectedTab: MutableState<Int>) {
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val coroutineScope = rememberCoroutineScope()
    val user by userViewModel.currentUser.observeAsState()
    val isLogoutDialogVisible by userViewModel.isLogoutDialogVisible.observeAsState(false)

    ModalDrawer(
        drawerState = drawerState,
        drawerContent = {
            DrawerHeader(user, userViewModel, navController)
            DrawerItems(navController, selectedTab, userViewModel)
        },
        gesturesEnabled = drawerState.isOpen
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("${user?.name ?: "User"} Canvas",color = Color.White) },
                    navigationIcon = {
                        IconButton(onClick = { coroutineScope.launch { drawerState.open() } }) {
                            Icon(Icons.Filled.Menu, contentDescription = "Menu",tint = Color.White)
                        }
                    },
                    colors = TopAppBarDefaults.smallTopAppBarColors(
                        containerColor = Color(android.graphics.Color.rgb(107, 64, 246))
                    )
                )
            },
            bottomBar = { HomeBottomBar(navController, selectedTab) }
        ) { paddingValues ->
            CanvasContent(paddingValues, navController, userViewModel)
        }
    }

    if (isLogoutDialogVisible) {
        LogoutDialog(
            user = user,
            onConfirm = {
                userViewModel.logout()
                navController.navigate("main") {
                    popUpTo("home") { inclusive = true }
                }
            },
            onDismiss = {
                userViewModel.hideLogoutDialog()
            }
        )
    }
}

