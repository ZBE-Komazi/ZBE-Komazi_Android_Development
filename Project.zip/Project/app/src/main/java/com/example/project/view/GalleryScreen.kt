package com.example.project.view

import android.net.Uri
import android.widget.MediaController
import android.widget.VideoView
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.DrawerValue
import androidx.compose.material.ModalDrawer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.rememberDrawerState
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.navigation.NavController
import coil.compose.rememberImagePainter
import com.example.project.R
import com.example.project.viewmodel.PinterestViewModel
import com.example.project.viewmodel.UserViewModel
import kotlinx.coroutines.launch


/*
 * Zintle Komazi
 * 2019098256
 * EXAM PROJECT CSIP6853
 * 5 JUNE 2024

 */

@Composable
fun GalleryScreen(
    navController: NavController,
    userViewModel: UserViewModel,
    selectedTab: MutableState<Int>,
    pinterestViewModel: PinterestViewModel,
    memoryTitle: String
) {
    GalleryModalDrawerComponent(
        navController = navController,
        userViewModel = userViewModel,
        selectedTab = selectedTab,
        pinterestViewModel = pinterestViewModel,
        memoryTitle = memoryTitle
    )
}

@Composable
fun GalleryContent(
    paddingValues: PaddingValues,
    navController: NavController,
    userViewModel: UserViewModel,
    pinterestViewModel: PinterestViewModel,
    memoryTitle: String
) {
    val context = LocalContext.current
    val galleryUriList = remember { mutableStateListOf<Uri>() }
    val coroutineScope = rememberCoroutineScope()

    val imageLauncher = rememberLauncherForActivityResult(contract = ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri?.let {
            galleryUriList.add(it)
            coroutineScope.launch {
                val mimeType = context.contentResolver.getType(it)
                pinterestViewModel.createMemory(memoryTitle, System.currentTimeMillis(), it.toString(), "image")
            }
        }
    }

    val videoLauncher = rememberLauncherForActivityResult(contract = ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri?.let {
            galleryUriList.add(it)
            coroutineScope.launch {
                val mimeType = context.contentResolver.getType(it)
                pinterestViewModel.createMemory(memoryTitle, System.currentTimeMillis(), it.toString(), "video")
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(paddingValues)
            .padding(0.dp),
        contentAlignment = Alignment.TopStart
    ) {
        Image(
            painter = painterResource(id = R.drawable.layout2),
            contentDescription = "Background Image",
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Top
        ) {
            Text("Album: $memoryTitle", style = MaterialTheme.typography.titleSmall)
            Spacer(modifier = Modifier.height(16.dp))

            LazyColumn {
                items(galleryUriList) { uri ->
                    val contentResolver = context.contentResolver
                    val mimeType = contentResolver.getType(uri)
                    if (mimeType != null && mimeType.startsWith("image")) {
                        Image(
                            painter = rememberImagePainter(uri),
                            contentDescription = null,
                            modifier = Modifier.size(100.dp)
                        )
                    } else if (mimeType != null && mimeType.startsWith("video")) {
                        AndroidView(factory = {
                            VideoView(context).apply {
                                setVideoURI(uri)
                                setMediaController(MediaController(context).apply {
                                    setAnchorView(this@apply)
                                })
                                requestFocus()
                                start()
                            }
                        }, modifier = Modifier.size(200.dp))
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
            Row {
                Button(
                    onClick = { imageLauncher.launch("image/*") },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFFA500))
                ) {
                    Icon(Icons.Default.PhotoCamera, contentDescription = "Select Photo")
                    Text("Select Photo")
                }
                Spacer(modifier = Modifier.width(8.dp))
                Button(
                    onClick = { videoLauncher.launch("video/*") },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFFA500))
                ) {
                    Icon(Icons.Default.Videocam, contentDescription = "Select Video")
                    Text("Select Video")
                }
            }
            Spacer(modifier = Modifier.height(16.dp))
            Button(onClick = {
                navController.popBackStack()
            }) {
                Text("Done")
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GalleryModalDrawerComponent(
    navController: NavController,
    userViewModel: UserViewModel,
    selectedTab: MutableState<Int>,
    pinterestViewModel: PinterestViewModel,
    memoryTitle: String
) {
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val coroutineScope = rememberCoroutineScope()
    val user by userViewModel.currentUser.observeAsState()

    ModalDrawer(
        drawerState = drawerState,
        drawerContent = {
            DrawerHeader(user, userViewModel, navController)
            DrawerItems(navController, selectedTab, userViewModel)
        },
        gesturesEnabled = drawerState.isOpen
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("${user?.name ?: "User"}'s Gallery",color = Color.White) },
                    navigationIcon = {
                        IconButton(onClick = { coroutineScope.launch { drawerState.open() } }) {
                            Icon(Icons.Filled.Menu, contentDescription = "Menu",tint = Color.White)
                        }
                    },
                    colors = TopAppBarDefaults.smallTopAppBarColors(
                        containerColor = Color(android.graphics.Color.rgb(107, 64, 246))
                    )
                )
            },
            bottomBar = { HomeBottomBar(navController, selectedTab) }
        ) { paddingValues ->
            GalleryContent(paddingValues, navController, userViewModel, pinterestViewModel, memoryTitle)
        }
    }
}

