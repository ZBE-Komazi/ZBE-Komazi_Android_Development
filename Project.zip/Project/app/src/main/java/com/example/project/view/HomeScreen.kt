package com.example.project.view


/*
 * Zintle Komazi
 * 2019098256
 * EXAM PROJECT CSIP6853
 * 5 JUNE 2024

 */

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Context
import android.content.Intent
import android.graphics.Color.rgb
import android.location.Address
import android.location.Geocoder
import android.net.Uri
import android.os.Bundle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.Card
import androidx.compose.material.DrawerValue
import androidx.compose.material.DropdownMenuItem
import androidx.compose.material.ExperimentalMaterialApi
import androidx.compose.material.ListItem
import androidx.compose.material.ModalDrawer
import androidx.compose.material.TextField
import androidx.compose.material.TextFieldDefaults
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Draw
import androidx.compose.material.icons.filled.Event
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Help
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.Mail
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Message
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.QuestionMark
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material.rememberDrawerState
import androidx.compose.material.rememberScaffoldState
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.navigation.NavController
import coil.compose.rememberAsyncImagePainter
import com.example.project.MapsActivity
import com.example.project.R
import com.example.project.model.Event
import com.example.project.model.User
import com.example.project.rememberMapViewWithLifecycle
import com.example.project.viewmodel.EventViewModel
import com.example.project.viewmodel.UserViewModel
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.MapView
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale


@Composable
fun HomeScreen(navController: NavController, userViewModel: UserViewModel,eventViewModel: EventViewModel) {
    val selectedTab = remember { mutableStateOf(0) }
    val paddingValues = remember { PaddingValues() }
    var searchText by remember { mutableStateOf("") }
    ModalDrawerComponent(navController = navController, userViewModel = userViewModel,eventViewModel = eventViewModel, selectedTab = selectedTab)
}


@Composable
fun DrawerHeader(user: User?, userViewModel: UserViewModel, navController: NavController) {
    val context = LocalContext.current
    val defaultImage = painterResource(R.drawable.profile) // Default image from res/drawable
    val coroutineScope = rememberCoroutineScope()
    val launcher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let {
            coroutineScope.launch {
                userViewModel.updateProfilePicture(user?.email ?: "", it)
            }
        }
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(rgb(107, 64, 246))) // Purple background color
            .padding(16.dp), // Padding for the entire Row
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        Image(
            painter = if (user?.profilePictureUri != null) rememberAsyncImagePainter(user.profilePictureUri) else defaultImage,
            contentDescription = "Profile Picture",
            modifier = Modifier
                .padding(8.dp) // Padding to prevent touching the borders
                .size(60.dp)
                .clip(CircleShape)
                .clickable {
                    launcher.launch("image/*")
                }
        )
        Spacer(modifier = Modifier.width(16.dp))
        Column(
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(text = user?.name ?: "Loading...", style = MaterialTheme.typography.titleSmall, color = Color.White)
            Text(text = user?.email ?: "Loading...", style = MaterialTheme.typography.titleSmall, color = Color.White)
        }
    }
}

@Composable
fun LogoutDialog(user: User?, onConfirm: () -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Logout") },
        text = { Text("${user?.name ?: "User"}, are you sure you want to logout?") },
        confirmButton = {
            Button(onClick = onConfirm) {
                Text("Yes")
            }
        },
        dismissButton = {
            Button(onClick = onDismiss) {
                Text("No")
            }
        }
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ModalDrawerComponent(navController: NavController, userViewModel: UserViewModel,eventViewModel: EventViewModel, selectedTab: MutableState<Int>) {
    val context = LocalContext.current
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val coroutineScope = rememberCoroutineScope()
    val user by userViewModel.currentUser.observeAsState()
    val isLogoutDialogVisible by userViewModel.isLogoutDialogVisible.observeAsState(false)

    ModalDrawer(
        drawerState = drawerState,
        drawerContent = {
            DrawerHeader(user, userViewModel, navController)
            DrawerItems(navController, selectedTab, userViewModel)
        },
        gesturesEnabled = drawerState.isOpen
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("Welcome ${user?.name ?: "User"}",color = Color(0xFFFFA500)) },
                    navigationIcon = {
                        IconButton(onClick = { coroutineScope.launch { drawerState.open() } }) {
                            Icon(Icons.Filled.Menu, contentDescription = "Menu",tint = Color(0xFFFFA500))
                        }
                    },
                    colors = TopAppBarDefaults.smallTopAppBarColors(
                        containerColor = Color(rgb(107,64,246))
                    )
                )
            },
            bottomBar = { EventBottomBar(eventViewModel,navController, selectedTab) }
        ) { paddingValues ->
            HomeContent(eventViewModel,paddingValues,navController)
        }
    }

    if (isLogoutDialogVisible) {
        LogoutDialog(
            user = user,
            onConfirm = {
                userViewModel.logout()
                navController.navigate("main") {
                    popUpTo("home") { inclusive = true }
                }
            },
            onDismiss = {
                userViewModel.hideLogoutDialog()
            }
        )
    }
}


@Composable
fun HomeContent(eventViewModel: EventViewModel, paddingValues: PaddingValues,navController: NavController) {
    val context = LocalContext.current
    var searchText by remember { mutableStateOf("") }
    var showFilterMenu by remember { mutableStateOf(false) }
    var sortOption by remember { mutableStateOf("Event Date (A-Z)") }
    val events by eventViewModel.allEvents.observeAsState(listOf())
    var selectedVenue by remember { mutableStateOf<String?>(null) }
    var isValidAddress by remember { mutableStateOf(true) }

    val filteredEvents = events.filter { it.category.contains(searchText, ignoreCase = true) }
    val sortedEvents = when (sortOption) {
        "Creation Date (A-Z)" -> filteredEvents.sortedBy { it.creationDate }
        "Creation Date (Z-A)" -> filteredEvents.sortedByDescending { it.creationDate }
        "Event Date (A-Z)" -> filteredEvents.sortedBy { it.eventDate }
        "Event Date (Z-A)" -> filteredEvents.sortedByDescending { it.eventDate }
        "Category (A-Z)" -> filteredEvents.sortedBy { it.category }
        "Category (Z-A)" -> filteredEvents.sortedByDescending { it.category }
        else -> filteredEvents
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(paddingValues)
            .background(Color.White)
            .padding(0.dp), // Adjust this padding to move your search bar
        contentAlignment = Alignment.TopStart
    ) {
        Image(
            painter = painterResource(id = R.drawable.layout1),
            contentDescription = "Background Image",
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )

        Column(
            modifier = Modifier.fillMaxHeight().verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {

            Spacer(modifier = Modifier.height(60.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 4.dp),  // Further reduced padding for a very slim look
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextField(
                    value = searchText,
                    onValueChange = { searchText = it },
                    modifier = Modifier
                        .padding(horizontal = 30.dp)
                        .height(60.dp)  // Increased height for better touch target and visibility
                        .weight(1f)              // Black border with rounded corners
                       ,  // Interior background color
                    placeholder = { Text("Search events by category", color = Color(0xFFFFA500)) },
                    trailingIcon = {
                        IconButton(onClick = { /* Implement search action if needed */ }) {
                            Icon(Icons.Filled.Search, contentDescription = "Search", tint = Color(0xFFFFA500))
                        }
                    },
                    colors = TextFieldDefaults.textFieldColors(
                        backgroundColor = Color.Black,  // Ensures the interior background color
                        cursorColor = MaterialTheme.colorScheme.onSurface,
                        textColor = Color(0xFFFFA500),
                        placeholderColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f),
                        focusedIndicatorColor = Color.Transparent,
                        unfocusedIndicatorColor = Color.Transparent
                    ),

                    shape = RoundedCornerShape(20.dp),
                    singleLine = true
                )
                IconButton(onClick = { showFilterMenu = true }) {
                    Icon(Icons.Filled.FilterList, contentDescription = "Filter",tint = Color(rgb(107, 64, 246)))
                }
                DropdownMenu(
                    expanded = showFilterMenu,
                    onDismissRequest = { showFilterMenu = false }
                ) {
                    DropdownMenuItem(onClick = {
                        sortOption = "Creation Date (A-Z)"
                        showFilterMenu = false
                    }) {
                        Text("Creation Date (A-Z)")
                    }
                    DropdownMenuItem(onClick = {
                        sortOption = "Creation Date (Z-A)"
                        showFilterMenu = false
                    }) {
                        Text("Creation Date (Z-A)")
                    }
                    DropdownMenuItem(onClick = {
                        sortOption = "Event Date (A-Z)"
                        showFilterMenu = false
                    }) {
                        Text("Event Date (A-Z)")
                    }
                    DropdownMenuItem(onClick = {
                        sortOption = "Event Date (Z-A)"
                        showFilterMenu = false
                    }) {
                        Text("Event Date (Z-A)")
                    }
                    DropdownMenuItem(onClick = {
                        sortOption = "Category (A-Z)"
                        showFilterMenu = false
                    }) {
                        Text("Category (A-Z)")
                    }
                    DropdownMenuItem(onClick = {
                        sortOption = "Category (Z-A)"
                        showFilterMenu = false
                    }) {
                        Text("Category (Z-A)")
                    }
                }
            }
            Spacer(modifier = Modifier.height(20.dp)) // Add spacing between elements

            LazyRow(modifier = Modifier.padding(top = 8.dp)) {
                items(sortedEvents.size) { index ->
                    EventCard(
                        event = sortedEvents[index],
                        onDelete = { eventViewModel.delete(sortedEvents[index]) },
                        onArchive = { eventViewModel.archive(sortedEvents[index]) },
                        onShowMap = { venue ->
                            selectedVenue = venue
                            validateAddress(venue, context) { isValid ->
                                isValidAddress = isValid
                            }

                        } ,     navController = navController
                    )
                }
            }

            if (!isValidAddress) {
                Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Text("Invalid address, can't find it on the map.", color = Color.Red)
                }
            } else {
                selectedVenue?.let { venue ->
                    Spacer(modifier = Modifier.height(10.dp))
                    MapViewForEvent(venue = venue, Modifier.width(400.dp).height(200.dp))
                }
            }
        }
    }
}

@Composable
fun EventCard(event: Event, onDelete: () -> Unit, onArchive: () -> Unit, onShowMap: (String) -> Unit, navController: NavController) {
    var expanded by remember { mutableStateOf(false) }
    var archived by remember { mutableStateOf(false) }
    var showConfirmationDialog by remember { mutableStateOf(false) }
    val scaffoldState = rememberScaffoldState()
    val coroutineScope = rememberCoroutineScope()

    // Confirmation dialog logic
    if (showConfirmationDialog) {
        AlertDialog(
            onDismissRequest = {
                showConfirmationDialog = false
            },
            title = { Text("Archive Card") },
            text = { Text("Do you want to archive this card and move it to the history screen?") },
            confirmButton = {
                Button(onClick = {
                    archived = true
                    onArchive()
                    showConfirmationDialog = false
                    coroutineScope.launch {
                        scaffoldState.snackbarHostState.showSnackbar("The card has been moved to the history screen.")
                    }
                }) {
                    Text("Yes")
                }
            },
            dismissButton = {
                Button(onClick = {
                    showConfirmationDialog = false
                }) {
                    Text("No")
                }
            }
        )
    }

    Card(
        modifier = Modifier
            .padding(horizontal = 4.dp)
            .width(340.dp)
            .height(if (expanded) 500.dp else 400.dp)
            .clickable { expanded = !expanded },
        border = BorderStroke(2.dp, Color.Black),
        backgroundColor = MaterialTheme.colorScheme.primary,
        shape = RectangleShape // Ensures the corners are not rounded
    ) {
        Box(
            modifier = Modifier.fillMaxSize()
        ) {
            Image(
                painter = painterResource(id = R.drawable.purplebackground),
                contentDescription = "Background Image",
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )

            Column(
                modifier = Modifier
                    .verticalScroll(rememberScrollState()) // Make the card scrollable
                    .padding(16.dp)
            ) {
                val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
                val formattedCreationDate = sdf.format(event.creationDate)

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    IconButton(
                        onClick = {
                            if (!archived) {
                                showConfirmationDialog = true
                            }
                        },
                        modifier = Modifier.size(36.dp) // Increased size of the icon
                    ) {
                        Icon(
                            if (archived) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                            contentDescription = "Archive",
                            tint = Color.Green // Changed icon color to white
                        )
                    }
                    Text(
                        formattedCreationDate,
                        style = MaterialTheme.typography.titleMedium, // Changed from titleSmall to titleMedium
                        color = Color.Green,
                        textAlign = TextAlign.End
                    )
                }

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(100.dp),
                    contentAlignment = Alignment.Center // Centers the image inside the box
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.card2),
                        contentDescription = "Event Image",
                        modifier = Modifier.size(80.dp).clip(CircleShape), // Circular image
                        contentScale = ContentScale.Crop
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))
                Column(
                    modifier = Modifier.fillMaxWidth()
                ) {
                    val formattedDate = sdf.format(event.eventDate)

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Text(
                            "  Title:                          ",
                            style = MaterialTheme.typography.titleMedium.copy(color = Color.White)
                        )
                        Text(
                            event.title,
                            style = MaterialTheme.typography.titleMedium,
                            color = Color.Green
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Text(
                            "  Theme:                      ",
                            style = MaterialTheme.typography.titleMedium.copy(color = Color.White)
                        )
                        Text(
                            event.theme,
                            style = MaterialTheme.typography.titleMedium,
                            color = Color.Green
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Text(
                            "  Category:                  ",
                            style = MaterialTheme.typography.titleMedium.copy(color = Color.White)
                        )
                        Text(
                            event.category,
                            style = MaterialTheme.typography.titleMedium,
                            color = Color.Green
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Text(
                            "  Event Date:               ",
                            style = MaterialTheme.typography.titleMedium.copy(color = Color.White)
                        )
                        Text(
                            formattedDate,
                            style = MaterialTheme.typography.titleMedium,
                            color = Color.Green
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                    ) {
                        Text(
                            "  Time:                         ",
                            style = MaterialTheme.typography.titleMedium.copy(color = Color.White)
                        )
                        Text(
                            event.time,
                            style = MaterialTheme.typography.titleMedium,
                            color = Color.Green
                        )
                    }
                    if (expanded) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            Text(
                                "  Venue:                       ",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    color = Color.White
                                )
                            )
                            Text(
                                event.venue,
                                style = MaterialTheme.typography.titleMedium,
                                color = Color.Green
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            Text(
                                "  Max Participants:    ",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    color = Color.White
                                )
                            )
                            Text(
                                event.maxParticipants.toString(),
                                style = MaterialTheme.typography.titleMedium,color = Color.Green
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            Text(
                                "  Description:              ",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    color = Color.White
                                )
                            )
                            Text(
                                event.description,
                                style = MaterialTheme.typography.titleMedium,
                                color = Color.Green
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                        ) {
                            Text(
                                "  Restrictions:             ",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    color = Color.White
                                )
                            )
                            Text(
                                event.restrictions,
                                style = MaterialTheme.typography.titleMedium,
                                color = Color.Green
                            )
                        }
                        Spacer(modifier = Modifier.height(20.dp))
                        Row(
                            horizontalArrangement = Arrangement.SpaceEvenly,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Button(
                                onClick = onDelete,
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Color.Green,
                                    contentColor = Color.Black
                                )
                            ) {
                                Text("Delete", color = Color.Black)
                            }
                            Button(
                                onClick = { onShowMap(event.venue) },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Color.Green,
                                    contentColor = Color.Black
                                )
                            ) {
                                Icon(
                                    Icons.Default.LocationOn,
                                    contentDescription = "Show on Map",
                                    tint = Color.Black
                                )
                            }
                            Button(
                                onClick = {
                                    navController.navigate("progress/${event.title}")
                                },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Color.Green,
                                    contentColor = Color.Black
                                )
                            ) {
                                Icon(
                                    Icons.Default.ShowChart,
                                    contentDescription = "Track Progress",
                                    tint = Color.Black
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}



@Composable
fun MapViewForEvent(venue: String, modifier: Modifier = Modifier)  {
    val context = LocalContext.current
    val mapView = rememberMapViewWithLifecycle()

    AndroidView({ mapView }, modifier = modifier) { mapView ->
        mapView.getMapAsync { googleMap ->
            CoroutineScope(Dispatchers.Main).launch {
                val geocoder = Geocoder(context)
                val addresses: MutableList<Address>? = geocoder.getFromLocationName(venue, 1)
                if (addresses != null && addresses.isNotEmpty()) {
                    val location = addresses[0]
                    val latLng = LatLng(location.latitude, location.longitude)
                    googleMap.clear()
                    googleMap.addMarker(MarkerOptions().position(latLng).title("Marker in $venue"))
                    googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng, 15f))
                }
            }
        }
    }
}

@Composable
fun rememberMapViewWithLifecycle(): MapView {
    val context = LocalContext.current
    val mapView = remember {
        MapView(context).apply { id = R.id.map }
    }
    val lifecycleObserver = rememberMapLifecycleObserver(mapView)
    val lifecycle = LocalLifecycleOwner.current.lifecycle
    DisposableEffect(lifecycle) {
        lifecycle.addObserver(lifecycleObserver)
        onDispose {
            lifecycle.removeObserver(lifecycleObserver)
        }
    }
    return mapView
}

@Composable
fun rememberMapLifecycleObserver(mapView: MapView): LifecycleEventObserver =
    remember(mapView) {
        LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_CREATE -> mapView.onCreate(Bundle())
                Lifecycle.Event.ON_START -> mapView.onStart()
                Lifecycle.Event.ON_RESUME -> mapView.onResume()
                Lifecycle.Event.ON_PAUSE -> mapView.onPause()
                Lifecycle.Event.ON_STOP -> mapView.onStop()
                Lifecycle.Event.ON_DESTROY -> mapView.onDestroy()
                else -> throw IllegalStateException()
            }
        }
    }

private fun validateAddress(address: String,context: Context, onResult: (Boolean) -> Unit) {
    // Implement address validation logic using Geocoder or similar API
    // Call onResult(true) if address is valid, otherwise call onResult(false)
    val geocoder = Geocoder(context)
    val addresses = geocoder.getFromLocationName(address, 1)
    if (addresses != null) {
        onResult(addresses.isNotEmpty())
    }
}


@OptIn(ExperimentalMaterialApi::class)
@Composable
fun DrawerItems(navController: NavController, selectedTab: MutableState<Int>, userViewModel: UserViewModel) {
    val context = LocalContext.current

    Column {
        ListItem(icon = { Icon(Icons.Filled.AccountCircle, contentDescription = "Profile") },
            text = { Text("Profile") },
            modifier = Modifier.clickable {
                navController.navigate("profile")
                selectedTab.value = 0 // Reset or set to specific tab if needed
            }
        )
        ListItem(icon = { Icon(Icons.Filled.CalendarMonth, contentDescription = "Calendar") },
            text = { Text("Calendar") },
            modifier = Modifier.clickable {
                navController.navigate("calendar")
                selectedTab.value = 1 // Reset or set to specific tab if needed
            }
        )
        ListItem(icon = { Icon(Icons.Filled.Draw, contentDescription = "Discover") },
            text = { Text("Discover") },
            modifier = Modifier.clickable {
                navController.navigate("discover")
                selectedTab.value = 2 // Reset or set to specific tab if needed
            }
        )

        ListItem(icon = { Icon(Icons.Filled.Draw, contentDescription = "Pinterest") },
            text = { Text("Pinterest") },
            modifier = Modifier.clickable {
                navController.navigate("pinterest")
                selectedTab.value = 3 // Reset or set to specific tab if needed
            }
        )

        ListItem(icon = { Icon(Icons.Filled.Mail, contentDescription = "Invites") },
            text = { Text("Invites") },
            modifier = Modifier.clickable {
                navController.navigate("invitation")
                selectedTab.value = 4 // Adjust as necessary for your tab setup
            }
        )
        ListItem(icon = { Icon(Icons.Filled.ShoppingCart, contentDescription = "Shopping List") },
            text = { Text("Shopping List") },
            modifier = Modifier.clickable {
                navController.navigate("shoppingList")
                selectedTab.value = 5 // Reset or set to specific tab if needed
            }
        )
        ListItem(icon = { Icon(Icons.Filled.Draw, contentDescription = "Canvas") },
            text = { Text("Canvas") },
            modifier = Modifier.clickable {
                navController.navigate("canvas")
                selectedTab.value = 6 // Reset or set to specific tab if needed
            }
        )
        ListItem(icon = { Icon(Icons.Filled.History, contentDescription = "History") },
            text = { Text("History") },
            modifier = Modifier.clickable {
                navController.navigate("history")
                selectedTab.value = 7// Reset or set to specific tab if needed
            }
        )
        ListItem(icon = { Icon(Icons.Filled.Help, contentDescription = "Agent") },
            text = { Text("Agent") },
            modifier = Modifier.clickable {
                navController.navigate("help")
                selectedTab.value = 8 // Reset or set to specific tab if needed
            }
        )
        ListItem(icon = { Icon(Icons.Filled.QuestionMark, contentDescription = "About") },
            text = { Text("About") },
            modifier = Modifier.clickable {
                navController.navigate("about")
                selectedTab.value = 9 // Reset or set to specific tab if needed
            }
        )

        ListItem(icon = { Icon(Icons.Filled.Settings, contentDescription = "Settings") },
            text = { Text("Settings") },
            modifier = Modifier.clickable {
                navController.navigate("settings")
                selectedTab.value = 10 // Reset or set to specific tab if needed
            }
        )
        ListItem(icon = { Icon(Icons.Filled.Logout, contentDescription = "Log Out") },
            text = { Text("Log Out") },
            modifier = Modifier.clickable {
                userViewModel.showLogoutDialog()
            }
        )
    }
}



@Composable
fun EventBottomBar(eventViewModel: EventViewModel,navController: NavController, selectedTab: MutableState<Int>) {
    var showDialog by remember { mutableStateOf(false) }
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(72.dp)  // Set a fixed height for the bottom navigation bar area
    ) {
        NavigationBar(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth(),
            containerColor = Color(android.graphics.Color.rgb(107, 64, 246)),
            contentColor = Color.Black
        ) {
            NavigationBarItem(
                icon = { Icon(Icons.Filled.Home, contentDescription = "Home",tint = Color(0xFFFFA500)) },
                label = { Text("HOME",color = Color.White) },
                selected = selectedTab.value == 0,
                onClick = {
                    selectedTab.value = 0
                    navController.navigate("home")
                }
            )

            NavigationBarItem(
                icon = { Icon(Icons.Filled.Event, contentDescription = "Event",tint = Color(0xFFFFA500))  },
                label = { Text("MAP",color=Color.White) },
                selected = selectedTab.value == 1,
                onClick = {
                    selectedTab.value = 1
                    navController.navigate("eventBottomNav")
                }
            )

            Spacer(modifier = Modifier.weight(1f, true))  // Dynamic spacing for alignment

            NavigationBarItem(
                icon = { Icon(Icons.Filled.Notifications, contentDescription = "Notify",tint = Color(0xFFFFA500))  },
                label = { Text("NOTIFY",color=Color.White) },
                selected = selectedTab.value == 2,
                onClick = {
                    selectedTab.value = 2
                    navController.navigate("notifyBottomNav")
                }
            )

            NavigationBarItem(
                icon = { Icon(Icons.Filled.Message, contentDescription = "Message",tint = Color(0xFFFFA500))  },
                label = { Text("BOT",color=Color.White) },
                selected = selectedTab.value == 3,
                onClick = {
                    selectedTab.value = 3
                    navController.navigate("chat")
                }
            )
        }

        FloatingActionButton(
            onClick = { showDialog = true },
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 10.dp)
                .size(60.dp),
            containerColor = MaterialTheme.colorScheme.secondary
        ) {
            Icon(
                imageVector = Icons.Filled.Add,
                contentDescription = "Add",
                tint = Color(0xFFFFA500),
                modifier = Modifier.size(36.dp)
            )
        }
    }

    if (showDialog) {
        CreateEventDialog(eventViewModel = eventViewModel,showDialog = showDialog) { showDialog = false }
    }
}

@Composable
fun HomeBottomBar(navController: NavController, selectedTab: MutableState<Int>) {
    var showDialog by remember { mutableStateOf(false) }
    val context = LocalContext.current // Get the context
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(72.dp)  // Set a fixed height for the bottom navigation bar area
    ) {
        NavigationBar(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth(),
            containerColor = Color(android.graphics.Color.rgb(107, 64, 246))
        ) {
            NavigationBarItem(
                icon = { Icon(Icons.Filled.Home, contentDescription = "Home", tint = Color(0xFFFFA500)) },
                label = { Text("HOME", color = Color.White) },
                selected = selectedTab.value == 0,
                onClick = {
                    selectedTab.value = 0
                    navController.navigate("home")
                }
            )

            NavigationBarItem(
                icon = { Icon(Icons.Filled.Event, contentDescription = "Event", tint = Color(0xFFFFA500)) },
                label = { Text("MAP", color = Color.White) },
                selected = selectedTab.value == 1,
                onClick = {
                    selectedTab.value = 1
                    // Launch MapsActivity
                    val intent = Intent(context, MapsActivity::class.java)
                    context.startActivity(intent)
                }
            )

            Spacer(modifier = Modifier.weight(1f, true))  // Dynamic spacing for alignment

            NavigationBarItem(
                icon = { Icon(Icons.Filled.Notifications, contentDescription = "Notify", tint = Color(0xFFFFA500)) },
                label = { Text("NOTIFY", color = Color.White) },
                selected = selectedTab.value == 2,
                onClick = {
                    selectedTab.value = 2
                    navController.navigate("notifyBottomNav")
                }
            )

            NavigationBarItem(
                icon = { Icon(Icons.Filled.Message, contentDescription = "Message", tint = Color(0xFFFFA500)) },
                label = { Text("BOT", color = Color.White) },
                selected = selectedTab.value == 3,
                onClick = {
                    selectedTab.value = 3
                    navController.navigate("messageBottomNav")
                }
            )
        }

        FloatingActionButton(
            onClick = { showDialog = true },
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 10.dp)
                .size(60.dp),
            containerColor = MaterialTheme.colorScheme.secondary
        ) {
            Icon(
                imageVector = Icons.Filled.Add,
                contentDescription = "Add",
                tint = Color(0xFFFFA500),
                modifier = Modifier.size(36.dp)
            )
        }
    }
}

@Composable
fun CreateEventDialog(eventViewModel: EventViewModel, showDialog: Boolean, onDismiss: () -> Unit) {
    var title by rememberSaveable { mutableStateOf("") }
    var theme by rememberSaveable { mutableStateOf("") }
    val categories = listOf("Conference", "Seminar", "Workshop", "Concert", "Festival", "Party", "Exhibition", "Networking", "Sports", "Other")
    var category by rememberSaveable { mutableStateOf(categories.first()) }  // Default to the first category
    var date by rememberSaveable { mutableStateOf(Date()) }
    var eventDate by rememberSaveable { mutableStateOf(Date()) }
    var venue by rememberSaveable { mutableStateOf("") }
    var maxParticipants by rememberSaveable { mutableStateOf("") }
    var description by rememberSaveable { mutableStateOf("") }
    var restrictions by rememberSaveable { mutableStateOf("") }
    var time by rememberSaveable { mutableStateOf(Date()) }
    var expanded by rememberSaveable { mutableStateOf(false) }

    if (showDialog) {
        AlertDialog(
            onDismissRequest = onDismiss,
            title = { Text("Create Event") },
            text = {
                Column(modifier = Modifier.padding(6.dp)) {
                    Spacer(modifier = Modifier.height(10.dp))
                    TextField(
                        value = title,
                        onValueChange = { title = it },
                        label = { Text("Title") },
                        colors = TextFieldDefaults.textFieldColors(
                            backgroundColor = Color.White,
                            cursorColor = Color.Black,
                            focusedIndicatorColor = Color.Black,
                            unfocusedIndicatorColor = Color.Black
                        )
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    TextField(
                        value = theme,
                        onValueChange = { theme = it },
                        label = { Text("Theme",color=Color.Black) },
                        colors = TextFieldDefaults.textFieldColors(
                            backgroundColor = Color.White,
                            cursorColor = Color.Black,
                            focusedIndicatorColor = Color.Black,
                            unfocusedIndicatorColor = Color.Black
                        )
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Box {
                        TextField(
                            value = category,
                            onValueChange = {},
                            label = { Text("Category",color=Color.Black) },
                            readOnly = true,
                            trailingIcon = {
                                Icon(Icons.Filled.ArrowDropDown, "Drop-down icon", Modifier.clickable { expanded = true })
                            },
                            colors = TextFieldDefaults.textFieldColors(
                                backgroundColor = Color.White,
                                cursorColor = Color.Black,
                                focusedIndicatorColor = Color.Black,
                                unfocusedIndicatorColor = Color.Black
                            )
                        )
                        DropdownMenu(
                            expanded = expanded,
                            onDismissRequest = { expanded = false }
                        ) {
                            categories.forEach { categoryName ->
                                DropdownMenuItem(onClick = {
                                    category = categoryName
                                    expanded = false
                                }) {
                                    Text(categoryName)
                                }
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    DatePicker("Event Date", eventDate, onDateChange = { eventDate = it })
                    Spacer(modifier = Modifier.height(10.dp))
                    TextField(
                        value = venue,
                        onValueChange = { venue = it },
                        label = { Text("Venue",color=Color.Black) },
                        colors = TextFieldDefaults.textFieldColors(
                            backgroundColor = Color.White,
                            cursorColor = Color.Black,
                            focusedIndicatorColor = Color.Black,
                            unfocusedIndicatorColor = Color.Black
                        )
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    TextField(
                        value = maxParticipants,
                        onValueChange = { maxParticipants = it },
                        label = { Text("Max Participants",color=Color.Black) },
                        colors = TextFieldDefaults.textFieldColors(
                            backgroundColor = Color.White,
                            cursorColor = Color.Black,
                            focusedIndicatorColor = Color.Black,
                            unfocusedIndicatorColor = Color.Black
                        )
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    TextField(
                        value = description,
                        onValueChange = { description = it },
                        label = { Text("Description",color=Color.Black) },
                        colors = TextFieldDefaults.textFieldColors(
                            backgroundColor = Color.White,
                            cursorColor = Color.Black,
                            focusedIndicatorColor = Color.Black,
                            unfocusedIndicatorColor = Color.Black
                        )
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    TextField(
                        value = restrictions,
                        onValueChange = { restrictions = it },
                        label = { Text("Restrictions",color=Color.Black) },
                        colors = TextFieldDefaults.textFieldColors(
                            backgroundColor = Color.White,
                            cursorColor = Color.Black,
                            focusedIndicatorColor = Color.Black,
                            unfocusedIndicatorColor = Color.Black
                        )
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    TimePicker("Time", time, onTimeChange = { time = it })
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        eventViewModel.insert(
                            Event(
                                title = title,
                                theme = theme,
                                category = category,
                                creationDate = date,
                                eventDate = eventDate,
                                venue = venue,
                                maxParticipants = maxParticipants.toInt(),
                                description = description,
                                restrictions = restrictions,
                                time = SimpleDateFormat("HH:mm", Locale.getDefault()).format(time)
                            )
                        )
                        onDismiss()
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color.Green,
                        contentColor = Color.Black
                    )
                ) {
                    Text("Create")
                }
            },
            dismissButton = {
                Button(
                    onClick = onDismiss,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color.Green,
                        contentColor = Color.Black
                    )
                ) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
fun TimePicker(label: String, time: Date, onTimeChange: (Date) -> Unit) {
    val timeString = remember { mutableStateOf(SimpleDateFormat("HH:mm", Locale.getDefault()).format(time)) }
    val context = LocalContext.current

    TextField(
        value = timeString.value,
        onValueChange = { },
        readOnly = true,
        label = { Text(label,color=Color.Black) },
        trailingIcon = {
            Icon(Icons.Default.Alarm, contentDescription = "Select Time", Modifier.clickable {
                showTimePicker(context, time) {
                    timeString.value = SimpleDateFormat("HH:mm", Locale.getDefault()).format(it)
                    onTimeChange(it)
                }
            })
        }
    )
}

fun showTimePicker(context: Context, initialTime: Date, onTimeChange: (Date) -> Unit) {
    val calendar = Calendar.getInstance().apply { time = initialTime }
    TimePickerDialog(
        context,
        { _, hourOfDay, minute ->
            calendar.set(Calendar.HOUR_OF_DAY, hourOfDay)
            calendar.set(Calendar.MINUTE, minute)
            onTimeChange(calendar.time)
        },
        calendar.get(Calendar.HOUR_OF_DAY),
        calendar.get(Calendar.MINUTE),
        true
    ).show()
}


@Composable
fun DatePicker(label: String, date: Date, onDateChange: (Date) -> Unit) {
    val dateString = remember { mutableStateOf(SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(date)) }
    val context = LocalContext.current

    TextField(
        value = dateString.value,
        onValueChange = { },
        readOnly = true,
        label = { Text(label,color=Color.Black) },
        trailingIcon = {
            Icon(Icons.Default.Event, contentDescription = "Select Date", Modifier.clickable {
                showDatePicker(context, date, onDateChange)
            })
        }
    )
}

fun showDatePicker(context: Context, date: Date, onDateChange: (Date) -> Unit) {
    val calendar = Calendar.getInstance().apply { time = date }
    DatePickerDialog(
        context,
        { _, year, month, day ->
            calendar.set(year, month, day)
            onDateChange(calendar.time)
        },
        calendar.get(Calendar.YEAR),
        calendar.get(Calendar.MONTH),
        calendar.get(Calendar.DAY_OF_MONTH)
    ).show()
}
