package com.example.project
/*
 * Zintle Komazi
 * 2019098256
 * EXAM PROJECT CSIP6853
 * 5 JUNE 2024

 */

import android.app.Application
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.annotation.RequiresApi
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.project.model.AppDatabase
import com.example.project.model.ChatUiModel
import com.example.project.model.EventDatabase
import com.example.project.model.EventProgressDatabase
import com.example.project.model.EventProgressRepository
import com.example.project.model.EventRepository
import com.example.project.model.InvitationDatabase
import com.example.project.model.InvitationRepository
import com.example.project.model.PinterestDatabase
import com.example.project.model.PinterestRepository
import com.example.project.model.ShoppingListDatabase
import com.example.project.model.ShoppingListRepository
import com.example.project.model.UserRepository
import com.example.project.model.chartFromJson
import com.example.project.ui.theme.ProjectTheme
import com.example.project.view.AboutScreen
import com.example.project.view.AlbumContent
import com.example.project.view.CalendarScreen
import com.example.project.view.CanvasScreen
import com.example.project.view.ChatScreen
import com.example.project.view.CreateInvitationForm
import com.example.project.view.EventProgressScreen
import com.example.project.view.EventScreen
import com.example.project.view.FilterScreen
import com.example.project.view.GalleryScreen
import com.example.project.view.HelpScreen
import com.example.project.view.HistoryScreen
import com.example.project.view.HomeScreen
import com.example.project.view.InvitationScreen
import com.example.project.view.MainScreen
import com.example.project.view.MessageScreen
import com.example.project.view.NotifyScreen
import com.example.project.view.PinterestScreen
import com.example.project.view.ProfileScreen
import com.example.project.view.ProgressContent
import com.example.project.view.ResetPasswordScreen
import com.example.project.view.SettingsScreen
import com.example.project.view.ShoppingListDetailScreen
import com.example.project.view.ShoppingListScreen
import com.example.project.view.SignInScreen
import com.example.project.view.SignUpScreen
import com.example.project.viewmodel.ChatViewModel
import com.example.project.viewmodel.EventProgressViewModel
import com.example.project.viewmodel.EventProgressViewModelFactory
import com.example.project.viewmodel.EventViewModel
import com.example.project.viewmodel.EventViewModelFactory
import com.example.project.viewmodel.FilterViewModel
import com.example.project.viewmodel.InvitationViewModel
import com.example.project.viewmodel.InvitationViewModelFactory
import com.example.project.viewmodel.PinterestViewModel
import com.example.project.viewmodel.PinterestViewModelFactory
import com.example.project.viewmodel.ShoppingListViewModel
import com.example.project.viewmodel.ShoppingListViewModelFactory
import com.example.project.viewmodel.UserViewModel
import com.example.project.viewmodel.UserViewModelFactory

class MainActivity : ComponentActivity() {
    @RequiresApi(Build.VERSION_CODES.TIRAMISU)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            ProjectTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    AppNavigation()
                }
            }
        }
    }
}

@RequiresApi(Build.VERSION_CODES.TIRAMISU)
@Composable
fun AppNavigation() {
    val context = LocalContext.current
    val navController = rememberNavController()

    val appDatabase = AppDatabase.getDatabase(context)
    val userRepository = UserRepository(appDatabase.userDao())
    val userViewModel: UserViewModel = viewModel(
        factory = UserViewModelFactory(userRepository)
    )

    val eventDatabase = EventDatabase.getDatabase(context)
    val eventRepository = EventRepository(eventDatabase.eventDao())
    val eventViewModel: EventViewModel = viewModel(
        factory = EventViewModelFactory(eventRepository)
    )

    val shoppingListDatabase = ShoppingListDatabase.getDatabase(context)
    val shoppingListRepository = ShoppingListRepository(shoppingListDatabase.shoppingListDao())
    val shoppingListViewModel: ShoppingListViewModel = viewModel(
        factory = ShoppingListViewModelFactory(shoppingListRepository)
    )

    val pinterestDatabase = PinterestDatabase.getDatabase(context)
    val pinterestRepository = PinterestRepository(pinterestDatabase.pinterestDao())
    val pinterestViewModel: PinterestViewModel = viewModel(
        factory = PinterestViewModelFactory(pinterestRepository)
    )


    val invitationDatabase = InvitationDatabase.getDatabase(context)
    val invitationRepository = InvitationRepository(invitationDatabase.invitationDao())
    val invitationViewModel: InvitationViewModel = viewModel(
        factory = InvitationViewModelFactory(invitationRepository)
    )

    val filterViewModel: FilterViewModel = viewModel(
        factory = ViewModelProvider.AndroidViewModelFactory.getInstance(LocalContext.current.applicationContext as Application)
    )

    val eventProgressDatabase = EventProgressDatabase.getDatabase(context)
    val eventProgressRepository = EventProgressRepository(eventProgressDatabase.eventProgressDao())
    val eventProgressViewModel: EventProgressViewModel = viewModel(
        factory = EventProgressViewModelFactory(eventProgressRepository)
    )

    val chatViewModel: ChatViewModel = viewModel()

    //val isLoggedIn = true
    val isLoggedIn = userViewModel.isLoggedIn.observeAsState(false).value
    val selectedTab = remember { mutableStateOf(0) }

    MaterialTheme {
        NavHost(navController, startDestination = if (isLoggedIn) "home" else "main") {
            composable("main") { MainScreen(navController) }
            composable("signin") { SignInScreen(navController, userViewModel) }
            composable("signup") { SignUpScreen(navController, userViewModel) }
            composable("resetPassword") { ResetPasswordScreen(navController, userViewModel) }
            composable("home") { HomeScreen(navController, userViewModel, eventViewModel) }
            composable("profile") { ProfileScreen(navController, userViewModel, selectedTab) }
            composable("calendar") {
                CalendarScreen(
                    navController,
                    userViewModel,
                    eventViewModel,
                    selectedTab
                )
            }
            composable("discover") {
                FilterScreen(
                    navController,
                    userViewModel,
                    selectedTab,
                    filterViewModel
                )
            }
            composable("pinterest") {
                PinterestScreen(
                    navController,
                    userViewModel,
                    selectedTab,
                    pinterestViewModel
                )
            }
            composable("canvas") { CanvasScreen(navController, userViewModel, selectedTab) }
            composable("shoppingList") {
                ShoppingListScreen(
                    navController,
                    userViewModel,
                    shoppingListViewModel,
                    selectedTab
                )
            }
            composable("history") {
                HistoryScreen(
                    navController,
                    userViewModel,
                    eventViewModel,
                    selectedTab
                )
            }
            composable("help") { HelpScreen(navController, userViewModel, selectedTab) }
            composable("about") { AboutScreen(navController, userViewModel, selectedTab) }
            composable("settings") { SettingsScreen(navController, userViewModel, selectedTab) }
            composable("eventBottomNav") { EventScreen(navController, userViewModel, selectedTab) }
            composable("notifyBottomNav") {
                NotifyScreen(
                    navController,
                    userViewModel,
                    eventViewModel,
                    selectedTab,
                    context
                )
            }
            composable("messageBottomNav") {
                MessageScreen(
                    navController,
                    userViewModel,
                    selectedTab
                )
            }
            composable("chat") {
                val conversation = chatViewModel.conversation.collectAsState(initial = emptyList())
                ChatScreen(
                    navController, userViewModel, selectedTab, model = ChatUiModel(
                        messages = conversation.value,
                        addressee = ChatUiModel.Author.bot
                    ),
                    onSendChatClickListener = { msg -> chatViewModel.sendChat(msg) },
                    modifier = Modifier.fillMaxSize()
                        .background(MaterialTheme.colorScheme.background)
                )
            }
            composable("shoppingListDetail/{shoppingListId}") { backStackEntry ->
                val shoppingListId =
                    backStackEntry.arguments?.getString("shoppingListId")?.toInt() ?: 0
                ShoppingListDetailScreen(
                    navController,
                    userViewModel,
                    selectedTab,
                    shoppingListViewModel,
                    shoppingListId
                )
            }
            composable("gallery/{memoryTitle}") { backStackEntry ->
                val memoryTitle = backStackEntry.arguments?.getString("memoryTitle") ?: ""
                GalleryScreen(
                    navController,
                    userViewModel,
                    selectedTab,
                    pinterestViewModel,
                    memoryTitle
                )
            }
            composable("album/{albumTitle}") { backStackEntry ->
                val albumTitle = backStackEntry.arguments?.getString("albumTitle") ?: ""
                AlbumContent(
                    navController,
                    userViewModel,
                    selectedTab,
                    pinterestViewModel,
                    albumTitle
                )
            }
            composable("invitation") {
                InvitationScreen(navController, userViewModel, invitationViewModel, selectedTab)
            }
            composable("createInvitation") {
                CreateInvitationForm(navController, invitationViewModel)
            }
            composable("progress/{eventTitle}") { backStackEntry ->
                val eventTitle = backStackEntry.arguments?.getString("eventTitle") ?: ""
                EventProgressScreen(navController, eventProgressViewModel, eventTitle)
            }
            composable("canvas") { CanvasScreen(navController, userViewModel, selectedTab) }
            composable(
                route = "progressContent/{progressPercentage}/{progressList}",
                arguments = listOf(
                    navArgument("progressPercentage") { type = NavType.IntType },
                    navArgument("progressList") { type = NavType.StringType }
                )
            ) { backStackEntry ->
                val progressPercentage = backStackEntry.arguments?.getInt("progressPercentage") ?: 0
                val progressListJson = backStackEntry.arguments?.getString("progressList") ?: "[]"
                val progressList = chartFromJson(progressListJson)
                ProgressContent(navController, progressPercentage, progressList)
            }
        }
    }
}

