package com.example.project.view


/*
 * Zintle Komazi
 * 2019098256
 * EXAM PROJECT CSIP6853
 * 5 JUNE 2024

 */

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.Card
import androidx.compose.material.DrawerValue
import androidx.compose.material.ModalDrawer
import androidx.compose.material.Text
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.rememberDrawerState
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.TextField
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.project.R
import com.example.project.model.ShoppingItem
import com.example.project.model.ShoppingList
import com.example.project.model.toItemJson
import com.example.project.model.toShoppingItemList
import com.example.project.viewmodel.ShoppingListViewModel
import com.example.project.viewmodel.UserViewModel
import kotlinx.coroutines.launch

@Composable
fun ShoppingListDetailScreen(
    navController: NavController,
    userViewModel: UserViewModel,
    selectedTab: MutableState<Int>,
    shoppingListViewModel: ShoppingListViewModel,
    shoppingListId: Int
) {
    ShoppingListDetailModalDrawerComponent(
        navController = navController,
        userViewModel = userViewModel,
        selectedTab = selectedTab
    ) {
        ShoppingListDetailContent(
            paddingValues = PaddingValues(),
            navController = navController,
            userViewModel = userViewModel,
            shoppingListViewModel = shoppingListViewModel,
            shoppingListId = shoppingListId
        )
    }
}
@Composable
fun ShoppingListDetailContent(
    paddingValues: PaddingValues,
    navController: NavController,
    userViewModel: UserViewModel,
    shoppingListViewModel: ShoppingListViewModel,
    shoppingListId: Int
) {
    val shoppingList by shoppingListViewModel.getShoppingListById(shoppingListId).observeAsState()

    val categories = listOf(
        "Decorations" to listOf("Balloons", "Streamers", "Centerpieces", "Tablecloths", "Banners"),
        "Food & Beverages" to listOf("Catering", "Beverages", "Snacks", "Desserts", "Cutlery"),
        "Entertainment" to listOf("Music", "DJ", "Photobooth", "Games", "Lighting"),
        "Miscellaneous" to listOf("Invitations", "Party Favors", "Gifts", "Guest Book", "Pens")
    )

    shoppingList?.let { list ->
        var isEditing by remember { mutableStateOf(false) }
        var items by remember { mutableStateOf(list.items.toShoppingItemList().toMutableList()) }
        Box(
            modifier = Modifier
                .fillMaxSize()
        ) {
            // Background image
            Image(
                painter = painterResource(id = R.drawable.transparent),
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .padding(16.dp),
                contentAlignment = Alignment.TopStart
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxHeight()
                        .verticalScroll(rememberScrollState()),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "Event Shopping List",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.primary
                    )

                    categories.forEach { (category, defaultItems) ->
                        Text(
                            text = category,
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(vertical = 8.dp)
                        )
                        defaultItems.forEach { itemName ->
                            val item = items.find { it.name == itemName } ?: ShoppingItem(
                                name = itemName,
                                subItems = listOf()
                            )
                            ShoppingListItem(
                                item,
                                list,
                                shoppingListViewModel,
                                isEditing
                            ) { updatedItem ->
                                val index = items.indexOfFirst { it.name == item.name }
                                if (index >= 0) {
                                    items[index] = updatedItem
                                } else {
                                    items = (items + updatedItem).toMutableList()
                                }
                            }
                        }
                    }

                    // Save and Edit buttons
                    Row(
                        modifier = Modifier.padding(top = 16.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Button(onClick = {
                            // Save the updated shopping list to the database
                            val updatedShoppingList = list.copy(items = items.toItemJson())
                            shoppingListViewModel.insert(updatedShoppingList)
                        }) {
                            Text("Save")
                        }
                        Spacer(modifier = Modifier.width(16.dp))
                        Button(onClick = { isEditing = !isEditing }) {
                            Text(if (isEditing) "Stop Editing" else "Edit")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ShoppingListItem(
    item: ShoppingItem,
    shoppingList: ShoppingList,
    shoppingListViewModel: ShoppingListViewModel,
    isEditing: Boolean,
    onItemUpdated: (ShoppingItem) -> Unit
) {
    var isChecked by remember { mutableStateOf(false) }
    var subItems by remember { mutableStateOf(item.subItems) }
    var newSubItem by remember { mutableStateOf("") }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(8.dp),
        elevation = 4.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = item.name, style = MaterialTheme.typography.titleSmall)
                Checkbox(
                    checked = isChecked,
                    onCheckedChange = { isChecked = it }
                )
            }

            if (isChecked) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(start = 16.dp)
                ) {
                    subItems.forEach { subItem ->
                        Text(text = subItem, style = MaterialTheme.typography.bodySmall)
                    }

                    if (isEditing) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            TextField(
                                value = newSubItem,
                                onValueChange = { newSubItem = it },
                                placeholder = { Text(text = "Add subitem") },
                                modifier = Modifier.weight(1f)
                            )
                            IconButton(
                                onClick = {
                                    if (newSubItem.isNotBlank()) {
                                        subItems = subItems + newSubItem
                                        newSubItem = ""

                                        // Update the item with the new subitem
                                        val updatedItem = item.copy(subItems = subItems)
                                        onItemUpdated(updatedItem)
                                    }
                                }
                            ) {
                                Icon(Icons.Filled.Add, contentDescription = "Add Subitem")
                            }
                        }
                    }
                }
            }
        }
    }
}




@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ShoppingListDetailModalDrawerComponent(
    navController: NavController,
    userViewModel: UserViewModel,
    selectedTab: MutableState<Int>,
    content: @Composable () -> Unit
) {
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val coroutineScope = rememberCoroutineScope()
    val user by userViewModel.currentUser.observeAsState()
    val isLogoutDialogVisible by userViewModel.isLogoutDialogVisible.observeAsState(false)

    ModalDrawer(
        drawerState = drawerState,
        drawerContent = {
            DrawerHeader(user, userViewModel, navController)
            DrawerItems(navController, selectedTab, userViewModel)
        },
        gesturesEnabled = drawerState.isOpen
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("${user?.name ?: "User"} ShoppingList",color = Color(0xFFFFA500)) },
                    navigationIcon = {
                        IconButton(onClick = { coroutineScope.launch { drawerState.open() } }) {
                            Icon(Icons.Filled.Menu, contentDescription = "Menu",tint = Color(0xFFFFA500))
                        }
                    },
                    colors = TopAppBarDefaults.smallTopAppBarColors(
                        containerColor = Color(android.graphics.Color.rgb(107, 64, 246))
                    )
                )
            },
            bottomBar = { HomeBottomBar(navController, selectedTab) }
        ) { paddingValues ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
                    .padding(16.dp),
                contentAlignment = Alignment.TopStart
            ) {
                content()
            }
        }
    }

    if (isLogoutDialogVisible) {
        LogoutDialog(
            user = user,
            onConfirm = {
                userViewModel.logout()
                navController.navigate("main") {
                    popUpTo("home") { inclusive = true }
                }
            },
            onDismiss = {
                userViewModel.hideLogoutDialog()
            }
        )
    }
}