package com.example.project.viewmodel

/*
 * Zintle Komazi
 * 2019098256
 * EXAM PROJECT CSIP6853
 * 5 JUNE 2024

 */

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.project.model.ShoppingList
import com.example.project.model.ShoppingListRepository
import kotlinx.coroutines.launch


class ShoppingListViewModel(private val repository: ShoppingListRepository) : ViewModel() {
    val allShoppingLists: LiveData<List<ShoppingList>> = repository.allShoppingLists

    fun insert(shoppingList: ShoppingList) = viewModelScope.launch {
        repository.insert(shoppingList)
    }

    fun delete(shoppingList: ShoppingList) = viewModelScope.launch {
        repository.delete(shoppingList)
    }

    fun getShoppingListById(id: Int): LiveData<ShoppingList> {
        return repository.getShoppingListById(id)
    }
}


class ShoppingListViewModelFactory(private val repository: ShoppingListRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(ShoppingListViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return ShoppingListViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
