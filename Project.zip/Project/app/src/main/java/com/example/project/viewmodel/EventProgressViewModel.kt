package com.example.project.viewmodel

/*
 * Zintle Komazi
 * 2019098256
 * EXAM PROJECT CSIP6853
 * 5 JUNE 2024

 */


import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.project.model.EventProgress
import com.example.project.model.EventProgressRepository
import kotlinx.coroutines.launch

class EventProgressViewModel(private val repository: EventProgressRepository) : ViewModel() {
    fun getProgressByEvent(eventTitle: String): LiveData<List<EventProgress>> {
        return repository.getProgressByEvent(eventTitle)
    }

    fun updateProgress(eventProgress: EventProgress) {
        viewModelScope.launch {
            repository.updateProgress(eventProgress)
        }
    }

    fun insertProgress(eventProgressList: List<EventProgress>) {
        viewModelScope.launch {
            repository.insertProgress(eventProgressList)
        }
    }
}

class EventProgressViewModelFactory(private val repository: EventProgressRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(EventProgressViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return EventProgressViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
