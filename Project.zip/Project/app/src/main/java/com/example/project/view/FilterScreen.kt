package com.example.project.view

/*
 * Zintle Komazi
 * 2019098256
 * EXAM PROJECT CSIP6853
 * 5 JUNE 2024

 */

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.Card
import androidx.compose.material.DrawerValue
import androidx.compose.material.ModalDrawer
import androidx.compose.material.Text
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.rememberDrawerState
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.project.R
import com.example.project.model.EventItem
import com.example.project.viewmodel.FilterViewModel
import com.example.project.viewmodel.UserViewModel
import kotlinx.coroutines.launch

@Composable
fun FilterScreen(navController: NavController, userViewModel: UserViewModel, selectedTab: MutableState<Int>,filterViewModel: FilterViewModel) {
    FilterModalDrawerComponent(navController = navController, userViewModel = userViewModel, selectedTab = selectedTab,filterViewModel= filterViewModel)

}

@Composable
fun FilterCard(item: EventItem, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(8.dp),
        shape = RoundedCornerShape(8.dp),
        elevation = 4.dp
    ) {
        Column(modifier = Modifier.padding(8.dp)) {
            val imageId = item.getImageResourceId(LocalContext.current)
            Image(
                painter = painterResource(id = imageId),
                contentDescription = "${item.category} Image",
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp),
                contentScale = ContentScale.Crop
            )
            Text(
                text = item.name,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                modifier = Modifier.padding(top = 8.dp)
            )
            Text(
                text = item.description,
                fontSize = 14.sp
            )
        }
    }
}

@Composable
fun FilterContent(paddingValues: PaddingValues, navController: NavController, userViewModel: UserViewModel, filterViewModel: FilterViewModel) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(paddingValues)
            .padding(0.dp),
        contentAlignment = Alignment.TopStart
    ) {
        Image(
            painter = painterResource(id = R.drawable.layout1),
            contentDescription = "Background Image",
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(1.dp),
            contentAlignment = Alignment.TopStart
        ) {
            Column(
                modifier = Modifier.fillMaxHeight(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                var selectedTab by remember { mutableStateOf(0) }
                val categories = listOf(
                    "Balloons",
                    "Streamers",
                    "Drink",
                    "Venue",
                    "Dj",
                    "Music",
                    "Catering",
                    "Cutlery",
                    "Games",
                    "Incentives",
                    "Invitations"
                )

                Column(
                    modifier = Modifier.fillMaxSize().padding(1.dp),
                    verticalArrangement = Arrangement.Top,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Scrollable row for buttons
                    LazyRow(
                        modifier = Modifier.padding(vertical = 5.dp)
                    ) {
                        itemsIndexed(categories) { index, category ->
                            Button(
                                onClick = {
                                    selectedTab = index
                                    filterViewModel.filterItems(category)
                                },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Color(0xFFFFA500), // Orange background
                                    contentColor = Color.Black // Black text
                                ),
                                modifier = Modifier.padding(horizontal = 4.dp)
                            ) {
                                Text(
                                    text = category,
                                    style = MaterialTheme.typography.bodyLarge
                                )
                            }
                        }
                    }

                    // Display filtered items based on the selected category
                    val filteredItems by filterViewModel.filteredItems.collectAsState()
                    LazyVerticalGrid(
                        columns = GridCells.Adaptive(minSize = 128.dp),
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(filteredItems.size) { index ->
                            val span = if (index % 5 == 0 || index % 5 == 2) 2 else 1 // Adjust the span logic based on your UI needs
                            val item = filteredItems[index]
                            GridItem(item = item, span = span)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun GridItem(item: EventItem, span: Int) {
    FilterCard(item = item, modifier = Modifier.fillMaxWidth(fraction = if (span == 2) 1f else 0.5f))
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FilterModalDrawerComponent(navController: NavController, userViewModel: UserViewModel, selectedTab: MutableState<Int>,filterViewModel: FilterViewModel) {
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val coroutineScope = rememberCoroutineScope()
    val user by userViewModel.currentUser.observeAsState()
    val isLogoutDialogVisible by userViewModel.isLogoutDialogVisible.observeAsState(false)

    ModalDrawer(
        drawerState = drawerState,
        drawerContent = {
            DrawerHeader(user, userViewModel, navController)
            DrawerItems(navController, selectedTab, userViewModel)
        },
        gesturesEnabled = drawerState.isOpen
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { androidx.compose.material3.Text("${user?.name ?: "User"} Calendar",color = Color.White) },
                    navigationIcon = {
                        IconButton(onClick = { coroutineScope.launch { drawerState.open() } }) {
                            Icon(Icons.Filled.Menu, contentDescription = "Menu",tint = Color.White)
                        }
                    },
                    colors = TopAppBarDefaults.smallTopAppBarColors(
                        containerColor = Color(android.graphics.Color.rgb(107, 64, 246))
                    )
                )
            },
            bottomBar = { HomeBottomBar(navController, selectedTab) }
        ) { paddingValues ->
            FilterContent(paddingValues, navController, userViewModel,filterViewModel)
        }
    }

    if (isLogoutDialogVisible) {
        LogoutDialog(
            user = user,
            onConfirm = {
                userViewModel.logout()
                navController.navigate("main") {
                    popUpTo("home") { inclusive = true }
                }
            },
            onDismiss = {
                userViewModel.hideLogoutDialog()
            }
        )
    }
}



