package com.example.project.view

/*
 * Zintle Komazi
 * 2019098256
 * EXAM PROJECT CSIP6853
 * 5 JUNE 2024

 */

import android.graphics.Color.rgb
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.Card
import androidx.compose.material.DrawerValue
import androidx.compose.material.ModalDrawer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.rememberDrawerState
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.project.R
import com.example.project.model.Event
import com.example.project.model.toLocalDate
import com.example.project.viewmodel.EventViewModel
import com.example.project.viewmodel.UserViewModel
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.time.LocalDate
import java.time.YearMonth
import java.util.Locale

@Composable
fun CalendarScreen(
    navController: NavController,
    userViewModel: UserViewModel,
    eventViewModel: EventViewModel,
    selectedTab: MutableState<Int>
) {
    CalendarModalDrawerComponent(
        navController = navController,
        userViewModel = userViewModel,
        eventViewModel = eventViewModel,
        selectedTab = selectedTab
    )
}

@Composable
fun CalendarContent(
    paddingValues: PaddingValues,
    navController: NavController,
    userViewModel: UserViewModel,
    eventViewModel: EventViewModel
) {
    val events by eventViewModel.allEvents.observeAsState(initial = emptyList())
    val selectedDate = remember { mutableStateOf(LocalDate.now()) }
    val eventsByDate = remember(events) {
        events.groupBy { it.eventDate.toLocalDate() }
    }
    val monthEvents = events.filter { it.eventDate.toLocalDate().month == selectedDate.value.month }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(paddingValues)
            .padding(0.dp),
        contentAlignment = Alignment.TopStart
    ) {
        // Background image
        Image(
            painter = painterResource(id = R.drawable.transparent),  // Replace 'purplebackground' with your actual drawable resource name
            contentDescription = "Background Image",
            modifier = Modifier
                .fillMaxSize()
                .matchParentSize(),  // This ensures the image stretches to match the parent size
            contentScale = ContentScale.Crop  // This makes sure the image covers the entire available area, cropping if necessary
        )

        // Main Column for content
        Column(
            modifier = Modifier
                .padding(paddingValues)
                .padding(16.dp)
                .fillMaxSize()
        ) {
            MonthNavigation(selectedDate, monthEvents, navController)
            Spacer(modifier = Modifier.height(15.dp))
            SimpleCalendar(YearMonth.from(selectedDate.value), eventsByDate, selectedDate)
            Spacer(modifier = Modifier.height(24.dp))
            EventTimeline(monthEvents)
        }
    }
}

@Composable
fun MonthNavigation(
    selectedDate: MutableState<LocalDate>,
    events: List<Event>,
    navController: NavController
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        IconButton(onClick = {
            selectedDate.value = selectedDate.value.minusMonths(1)
        }) {
            Icon(Icons.Default.ArrowBack, "Previous Month",tint=Color(0xFFFFA500))
        }
        Text(
            text = "${selectedDate.value.month.name.capitalize()} ${selectedDate.value.year}",
            style = MaterialTheme.typography.displayMedium,color = Color(0xFFFFA500)
        )
        IconButton(onClick = {
            selectedDate.value = selectedDate.value.plusMonths(1)
        }) {
            Icon(Icons.Default.ArrowForward, "Next Month", tint=Color(0xFFFFA500))
        }
    }
}


@Composable
fun EventTimeline(events: List<Event>) {
    // Outer Row to hold the line and the event cards
    Row(verticalAlignment = Alignment.CenterVertically) {
        // Line to connect the dots
        Box(
            modifier = Modifier
                .align(Alignment.CenterVertically)  // Align the line to center vertically
                .width(3.dp)
                .fillMaxHeight()
                .background(color = Color.Blue)
        )

        Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
            events.forEach { event ->
                TimelineEventCard(event)
            }
        }
    }
}

@Composable
fun TimelineEventCard(event: Event) {
    val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
    val formattedDate = sdf.format(event.eventDate)

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp, horizontal = 8.dp),

        backgroundColor = Color.Transparent  // Transparent background to show the line behind
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            // Place the dot aligned with the line
            Box(
                modifier = Modifier
                    .size(15.dp)
                    .background(Color.Blue, shape = CircleShape)
                    .padding(4.dp)  // Padding to ensure dot is on the line, adjust as needed
            )
            Column(modifier = Modifier.padding(16.dp)) {
                Text(text = event.title, style = MaterialTheme.typography.titleSmall, color = Color.White)
                Text(text = formattedDate, style = MaterialTheme.typography.titleSmall, color = Color.White)

            }
        }
    }
}

@Composable
fun SimpleCalendar(
    month: YearMonth,
    eventsByDate: Map<LocalDate, List<Event>>,
    selectedDate: MutableState<LocalDate>
) {
    val daysInMonth = month.lengthOfMonth()
    val firstDayOffset = month.atDay(1).dayOfWeek.value % 7
    LazyVerticalGrid(
        columns = GridCells.Fixed(9),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp)
    ) {
        items(daysInMonth + firstDayOffset) { index ->
            if (index >= firstDayOffset) {
                val day = index - firstDayOffset + 1
                val date = month.atDay(day)
                DayCell(date, eventsByDate[date]?.isNotEmpty() == true, selectedDate)
            } else {
                Box(Modifier.padding(8.dp)) { /* Empty space for alignment */ }
            }
        }
    }
}

@Composable
fun DayCell(
    date: LocalDate,
    hasEvents: Boolean,
    selectedDate: MutableState<LocalDate>
) {

    Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier
            .aspectRatio(1f)
            .border(1.dp, Color(0xFFFFA500), shape = RoundedCornerShape(50)) // Apply rounded corners
            .padding(8.dp)
            .background(
                if (hasEvents) Color(rgb(107, 64, 246)) else Color.Transparent, // Purple color for days with events
                shape = RoundedCornerShape(50) // Apply rounded corners to the background
            )
            .clickable { selectedDate.value = date }
    ) {
        Text(text = date.dayOfMonth.toString(), color = Color.White, style = MaterialTheme.typography.titleSmall)
    }
}


@Composable
fun EventList(events: List<Event>, navController: NavController) {
    Column(modifier = Modifier
        .verticalScroll(rememberScrollState())
        .background(Color.White)
    ) {
        events.forEach { event ->
            EventCard(event, navController)
        }
    }
}

@Composable
fun EventCard(event: Event, navController: NavController) {
    Card(modifier = Modifier.padding(8.dp).fillMaxWidth(), backgroundColor = Color.DarkGray) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(text = event.title, color = Color.White, style = MaterialTheme.typography.titleMedium)
            Text(text = event.eventDate.toString(), color = Color.White, style = MaterialTheme.typography.bodyMedium)
        }
    }
}



@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CalendarModalDrawerComponent(
    navController: NavController,
    userViewModel: UserViewModel,
    eventViewModel: EventViewModel,  // Add eventViewModel parameter here
    selectedTab: MutableState<Int>
) {
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val coroutineScope = rememberCoroutineScope()
    val user by userViewModel.currentUser.observeAsState()
    val isLogoutDialogVisible by userViewModel.isLogoutDialogVisible.observeAsState(false)

    ModalDrawer(
        drawerState = drawerState,
        drawerContent = {
            DrawerHeader(user, userViewModel, navController)
            DrawerItems(navController, selectedTab, userViewModel)
        },
        gesturesEnabled = drawerState.isOpen
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("${user?.name ?: "User"} Calendar",color = Color(0xFFFFA500)) },
                    navigationIcon = {
                        IconButton(onClick = { coroutineScope.launch { drawerState.open() } }) {
                            Icon(Icons.Filled.Menu, contentDescription = "Menu",tint = Color.White)
                        }
                    },
                    colors = TopAppBarDefaults.smallTopAppBarColors(
                        containerColor = Color(android.graphics.Color.rgb(107, 64, 246))
                    )
                )
            },
            bottomBar = { HomeBottomBar(navController, selectedTab) }
        ) { paddingValues ->
            CalendarContent(paddingValues, navController, userViewModel, eventViewModel)  // Pass eventViewModel here
        }
    }

    if (isLogoutDialogVisible) {
        LogoutDialog(
            user = user,
            onConfirm = {
                userViewModel.logout()
                navController.navigate("main") {
                    popUpTo("home") { inclusive = true }
                }
            },
            onDismiss = {
                userViewModel.hideLogoutDialog()
            }
        )
    }
}


