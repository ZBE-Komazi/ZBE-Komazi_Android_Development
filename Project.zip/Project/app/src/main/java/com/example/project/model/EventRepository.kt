package com.example.project.model

/*
 * Zintle Komazi
 * 2019098256
 * EXAM PROJECT CSIP6853
 * 5 JUNE 2024

 */

import androidx.lifecycle.LiveData

class EventRepository(private val eventDao: EventDao) {
    val allEvents: LiveData<List<Event>> = eventDao.getAllEvents()
    val archivedEvents: LiveData<List<Event>> = eventDao.getArchivedEvents()
    suspend fun insert(event: Event) { eventDao.insertEvent(event) }
    suspend fun delete(event: Event) { eventDao.deleteEvent(event) }
    suspend fun update(event: Event) { eventDao.updateEvent(event) }
}