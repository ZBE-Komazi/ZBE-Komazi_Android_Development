package com.example.project.model

import android.content.Context
import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Delete
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import androidx.room.Update
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.Date


@Entity(tableName = "events")
data class Event(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val theme: String,
    val category: String,
    val eventDate: Date,
    val creationDate: Date,
    val venue: String,
    val maxParticipants: Int,
    val description: String,
    val restrictions: String,
    val time: String,
    val isArchived: Boolean = false
)

@Dao
interface EventDao {
    @Insert
    suspend fun insertEvent(event: Event)
    @Query("SELECT * FROM events WHERE isArchived = 0")
    fun getAllEvents(): LiveData<List<Event>>
    @Query("SELECT * FROM events WHERE isArchived = 1")
    fun getArchivedEvents(): LiveData<List<Event>>
    @Delete
    suspend fun deleteEvent(event: Event)
    @Update
    suspend fun updateEvent(event: Event)
}

@Database(entities = [Event::class], version = 1, exportSchema = false)
@TypeConverters(DateConverter::class)
abstract class EventDatabase : RoomDatabase() {
    abstract fun eventDao(): EventDao

    companion object {
        @Volatile
        private var INSTANCE: EventDatabase? = null

        fun getDatabase(context: Context): EventDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    EventDatabase::class.java,
                    "event_database"
                ).addCallback(object : RoomDatabase.Callback() {
                    override fun onCreate(db: SupportSQLiteDatabase) {
                        super.onCreate(db)
                        CoroutineScope(Dispatchers.IO).launch {
                            INSTANCE?.eventDao()?.insertEvent(Event(title="Event 1", theme="Networking", category="Social",
                                eventDate=Date(), creationDate=Date(), venue="Wilows Bloemfontein", maxParticipants=50,
                                description="A chance to meet and network.", restrictions="No entry without registration", time="18:00"))
                            INSTANCE?.eventDao()?.insertEvent(Event(title="Tech Conference", theme="Technology", category="Professional",
                                eventDate=Date(), creationDate=Date(), venue="Bloemfontein", maxParticipants=200,
                                description="Annual tech conference.", restrictions="Ticket required", time="09:00"))
                            INSTANCE?.eventDao()?.insertEvent(Event(title="Art Exhibition", theme="Art & Culture", category="Culture",
                                eventDate=Date(), creationDate=Date(), venue="4 logeman st Bloemfontein", maxParticipants=100,
                                description="Explore local artists.", restrictions="Free entry", time="10:00"))
                        }
                    }
                }).build()
                INSTANCE = instance
                instance
            }
        }
    }
}