package com.example.project.model

/*
 * Zintle Komazi
 * 2019098256
 * EXAM PROJECT CSIP6853
 * 5 JUNE 2024

 */

import android.content.Context
import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.project.R
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch


@Entity(tableName = "invitations")
data class Invitation(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String, // New field for the title of the invitation
    val username: String,
    val instagram: String,
    val userId: String,
    val date: String,
    val time: String,
    val userImage: Int = R.drawable.ic_user_avatar,
    val userQrCode: Int = R.drawable.ic_qr_code
)

@Dao
interface InvitationDao {
    @Query("SELECT * FROM invitations")
    fun getAllInvitations(): LiveData<List<Invitation>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertInvitation(invitation: Invitation)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertInvitations(invitations: List<Invitation>)
}

@Database(entities = [Invitation::class], version = 1, exportSchema = false)
abstract class InvitationDatabase : RoomDatabase() {
    abstract fun invitationDao(): InvitationDao

    companion object {
        @Volatile
        private var INSTANCE: InvitationDatabase? = null

        fun getDatabase(context: Context): InvitationDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    InvitationDatabase::class.java,
                    "invitation_database"
                ).addCallback(DatabaseCallback())
                    .fallbackToDestructiveMigration()
                    .build().also { INSTANCE = it }
            }

        private class DatabaseCallback : RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                INSTANCE?.let { database ->
                    CoroutineScope(Dispatchers.IO).launch {
                        populateDatabase(database.invitationDao())
                    }
                }
            }
        }

        suspend fun populateDatabase(invitationDao: InvitationDao) {
            val initialInvitations = listOf(
                Invitation(
                    title = "Birthday Bash",
                    username = "JohnDoe",
                    instagram = "@johndoe",
                    userId = "12345",
                    date = "2024-06-15",
                    time = "18:00",
                    userImage = R.drawable.ic_user_avatar,
                    userQrCode = R.drawable.ic_qr_code
                ),
                Invitation(
                    title = "Conference 2024",
                    username = "JaneDoe",
                    instagram = "@janedoe",
                    userId = "67890",
                    date = "2024-07-20",
                    time = "09:00",
                    userImage = R.drawable.ic_user_avatar,
                    userQrCode = R.drawable.ic_qr_code
                )
            )
            invitationDao.insertInvitations(initialInvitations)
        }
    }
}