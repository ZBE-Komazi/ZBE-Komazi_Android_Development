package com.example.project.model
/*
 * Zintle Komazi
 * 2019098256
 * EXAM PROJECT CSIP6853
 * 5 JUNE 2024

 */

import com.google.android.gms.maps.model.LatLng
import com.google.maps.android.clustering.ClusterItem


data class MarkerItem(
    val itemPosition: LatLng,
    val itemTitle: String = "",
    val itemSnippet: String = ""
) :
    ClusterItem {
    override fun getPosition(): LatLng =
        itemPosition

    override fun getTitle(): String =
        itemTitle

    override fun getSnippet(): String =
        itemSnippet
}