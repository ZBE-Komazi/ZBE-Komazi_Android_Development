package com.example.project.view

/*
 * Zintle Komazi
 * 2019098256
 * EXAM PROJECT CSIP6853
 * 5 JUNE 2024

 */

import android.Manifest
import android.content.Context
import android.os.Build
import androidx.annotation.RequiresApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.Card
import androidx.compose.material.DrawerValue
import androidx.compose.material.ModalDrawer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.rememberDrawerState
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.project.NotificationHandler
import com.example.project.R
import com.example.project.viewmodel.EventViewModel
import com.example.project.viewmodel.UserViewModel
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.isGranted
import com.google.accompanist.permissions.rememberPermissionState
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit


@RequiresApi(Build.VERSION_CODES.TIRAMISU)
@OptIn(ExperimentalPermissionsApi::class)
@Composable
fun NotifyContent(paddingValues: PaddingValues, navController: NavController, userViewModel: UserViewModel, eventViewModel: EventViewModel, context: Context) {
    val events by eventViewModel.allEvents.observeAsState(initial = emptyList())
    val currentDate = LocalDate.now()
    val postNotificationPermission = rememberPermissionState(permission = Manifest.permission.POST_NOTIFICATIONS)
    val notificationHandler = NotificationHandler(context)

    LaunchedEffect(key1 = true) {
        if (!postNotificationPermission.status.isGranted) {
            postNotificationPermission.launchPermissionRequest()
        }
    }
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(paddingValues)
            .padding(0.dp),
        contentAlignment = Alignment.TopStart
    ) {
        Image(
            painter = painterResource(id = R.drawable.layout1),
            contentDescription = "Background Image",
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(paddingValues)
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        events.filter {
            ChronoUnit.DAYS.between(currentDate, it.eventDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate()) <= 14
        }.sortedBy { it.eventDate }
            .forEach { event ->
                val eventLocalDate = event.eventDate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate()
                val daysUntilEvent = ChronoUnit.DAYS.between(currentDate, eventLocalDate)
                val (color, message) = when {
                    daysUntilEvent >= 14 -> Color.Green to "You have more than 2 weeks left until '${event.title}'."
                    daysUntilEvent in 7..13 -> Color.Yellow to "You have 1 week left until '${event.title}'."
                    daysUntilEvent in 1..6 -> Color.Red to "The big day is tomorrow: '${event.title}'."
                    daysUntilEvent == 0L -> Color.Blue to "Good luck today at '${event.title}'! Best wishes!"
                    else -> Color.Gray to "This event has passed."
                }

                // Trigger the notification
                when {
                    daysUntilEvent in 14..15 -> {
                        notificationHandler.showEventNotification(event.title, "You have about 2 weeks left until '${event.title}'.")
                    }
                    daysUntilEvent in 7..13 -> {
                        notificationHandler.showEventNotification(event.title, "You have 1 week left until '${event.title}'.")
                    }
                    daysUntilEvent in 1..6 -> {
                        notificationHandler.showEventNotification(event.title, "The big day is tomorrow: '${event.title}'.")
                    }
                    daysUntilEvent == 0L -> {
                        notificationHandler.showEventNotification(event.title, "Good luck today at '${event.title}'! Best wishes!")
                    }
                }

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    backgroundColor = color
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(text = event.title, style = MaterialTheme.typography.titleSmall, color = Color.White)
                        Text(text = "Date: ${eventLocalDate.format(DateTimeFormatter.ISO_LOCAL_DATE)}", style = MaterialTheme.typography.titleSmall, color = Color.White)
                        Text(text = message, style = MaterialTheme.typography.titleSmall, color = Color.White)
                    }
                }
            }
        }
    }

}


@RequiresApi(Build.VERSION_CODES.TIRAMISU)
@Composable
fun NotifyScreen(navController: NavController, userViewModel: UserViewModel, eventViewModel: EventViewModel, selectedTab: MutableState<Int>, context: Context) {
    NotifyModalDrawerComponent(navController = navController, userViewModel = userViewModel, eventViewModel = eventViewModel, selectedTab = selectedTab, context = context)
}

@RequiresApi(Build.VERSION_CODES.TIRAMISU)
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NotifyModalDrawerComponent(navController: NavController, userViewModel: UserViewModel, eventViewModel: EventViewModel, selectedTab: MutableState<Int>, context: Context) {
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val coroutineScope = rememberCoroutineScope()
    val user by userViewModel.currentUser.observeAsState()

    ModalDrawer(
        drawerState = drawerState,
        drawerContent = {
            DrawerHeader(user, userViewModel, navController)
            DrawerItems(navController, selectedTab, userViewModel)
        },
        gesturesEnabled = drawerState.isOpen
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("${user?.name ?: "User"} Notifications",color = Color.White) },
                    navigationIcon = {
                        IconButton(onClick = { coroutineScope.launch { drawerState.open() } }) {
                            Icon(Icons.Filled.Menu, contentDescription = "Menu",tint = Color.White)
                        }
                    },
                    colors = TopAppBarDefaults.smallTopAppBarColors(
                        containerColor = Color(android.graphics.Color.rgb(107, 64, 246))
                    )
                )
            },
            bottomBar = { HomeBottomBar(navController, selectedTab) }
        ) { paddingValues ->
            NotifyContent(paddingValues, navController, userViewModel, eventViewModel, context)
        }
    }
}