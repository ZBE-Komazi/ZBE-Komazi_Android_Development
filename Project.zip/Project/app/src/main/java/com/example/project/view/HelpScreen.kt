package com.example.project.view

/*
 * Zintle Komazi
 * 2019098256
 * EXAM PROJECT CSIP6853
 * 5 JUNE 2024

 */

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.DrawerValue
import androidx.compose.material.ModalDrawer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.rememberDrawerState
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.project.R
import com.example.project.viewmodel.UserViewModel
import kotlinx.coroutines.launch

@Composable
fun HelpScreen(navController: NavController, userViewModel: UserViewModel, selectedTab: MutableState<Int>) {
    HelpModalDrawerComponent(navController = navController, userViewModel = userViewModel, selectedTab = selectedTab)

}

@Composable
fun HelpContent(paddingValues: PaddingValues, navController: NavController, userViewModel: UserViewModel) {
    val eventPlanners = listOf(
        EventPlanner("Elegant Events", "elegantevents@gmail.com", "123 Party Lane, Celebration City", R.drawable.event1, 5),
        EventPlanner("Party Planners Inc.", "partyplannersinc@gmail.com", "456 Fun Street, Festivalland", R.drawable.event2, 4),
        EventPlanner("Gala Gatherings", "galagatherings@gmail.com", "789 Grand Ave, Eventville", R.drawable.event3, 3)
    )

    val categories = listOf(
        "Wedding Planners" to eventPlanners,
        "Corporate Events" to eventPlanners,
        "Birthday Parties" to eventPlanners
    )
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(paddingValues)
            .padding(0.dp),
        contentAlignment = Alignment.TopStart
    ) {
        Image(
            painter = painterResource(id = R.drawable.transparent),
            contentDescription = "Background Image",
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(5.dp),
            contentAlignment = Alignment.TopStart
        ) {
            Column(
                modifier = Modifier
                    .fillMaxHeight()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    text = "Select to send the agency an email, and inquire about their services",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = Color.White
                )

                categories.forEach { (category, planners) ->
                    Text(
                        text = category,
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = Color(0xFFFFA500),
                        modifier = Modifier.padding(vertical = 8.dp)
                    )
                    LazyRow {
                        items(planners) { planner ->
                            EventPlannerCard(planner, navController)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun EventPlannerCard(planner: EventPlanner, navController: NavController) {
    val context = LocalContext.current

    Card(
        modifier = Modifier
            .width(200.dp)
            .height(250.dp)
            .padding(8.dp)
            .clickable {
                val intent = Intent(Intent.ACTION_SENDTO).apply {
                    data = Uri.parse("mailto:${planner.email}")
                    putExtra(Intent.EXTRA_SUBJECT, "Inquiry about event planning services")
                }
                context.startActivity(intent)
            },
    ) {
        Box {
            Image(
                painter = painterResource(id = planner.logoResId),
                contentDescription = "Business Logo",
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.6f))
                    .padding(16.dp),
                verticalArrangement = Arrangement.SpaceBetween,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = planner.name,
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                    color = Color.White,
                    textAlign = TextAlign.Center
                )
                Text(
                    text = planner.address,
                    style = MaterialTheme.typography.titleSmall,
                    color = Color.White,
                    textAlign = TextAlign.Center
                )
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    repeat(planner.rating) {
                        Icon(imageVector = Icons.Filled.Star, contentDescription = "Star", tint = Color.Yellow)
                    }
                }
                IconButton(onClick = {
                    val gmmIntentUri = Uri.parse("geo:0,0?q=${planner.address}")
                    val mapIntent = Intent(Intent.ACTION_VIEW, gmmIntentUri)
                    mapIntent.setPackage("com.google.android.apps.maps")
                    context.startActivity(mapIntent)
                }) {
                    Icon(
                        imageVector = Icons.Filled.LocationOn,
                        contentDescription = "Location",
                        tint = Color.White
                    )
                }
            }
        }
    }
}

data class EventPlanner(val name: String, val email: String, val address: String, val logoResId: Int, val rating: Int)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HelpModalDrawerComponent(navController: NavController, userViewModel: UserViewModel, selectedTab: MutableState<Int>) {
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val coroutineScope = rememberCoroutineScope()
    val user by userViewModel.currentUser.observeAsState()
    val isLogoutDialogVisible by userViewModel.isLogoutDialogVisible.observeAsState(false)

    ModalDrawer(
        drawerState = drawerState,
        drawerContent = {
            DrawerHeader(user, userViewModel, navController)
            DrawerItems(navController, selectedTab, userViewModel)
        },
        gesturesEnabled = drawerState.isOpen
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("Need Help ${user?.name ?: "User"}",color = Color(0xFFFFA500)) },
                    navigationIcon = {
                        IconButton(onClick = { coroutineScope.launch { drawerState.open() } }) {
                            Icon(Icons.Filled.Menu, contentDescription = "Menu",tint = Color(0xFFFFA500))
                        }
                    },
                    colors = TopAppBarDefaults.smallTopAppBarColors(
                        containerColor = Color(android.graphics.Color.rgb(107, 64, 246))
                    )
                )
            },
            bottomBar = { HomeBottomBar(navController, selectedTab) }
        ) { paddingValues ->
            HelpContent(paddingValues, navController, userViewModel)
        }
    }

    if (isLogoutDialogVisible) {
        LogoutDialog(
            user = user,
            onConfirm = {
                userViewModel.logout()
                navController.navigate("main") {
                    popUpTo("home") { inclusive = true }
                }
            },
            onDismiss = {
                userViewModel.hideLogoutDialog()
            }
        )
    }
}