package com.example.project.model

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch


/*
 * Zintle Komazi
 * 2019098256
 * EXAM PROJECT CSIP6853
 * 5 JUNE 2024

 */

@Entity(tableName = "event_items")
data class EventItem(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val category: String,
    val description: String,
    val imagePath: String  // Path to the image file
) {
    fun getImageResourceId(context: Context): Int {
        return context.resources.getIdentifier(imagePath, "drawable", context.packageName)
    }
}


@Dao
interface EventItemDao {
    @Query("SELECT * FROM event_items WHERE category LIKE :category")
    fun getItemsByCategory(category: String): Flow<List<EventItem>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertItem(eventItem: EventItem)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertItems(eventItems: List<EventItem>)

    @Query("SELECT * FROM event_items WHERE name LIKE '%' || :query || '%'")
    fun searchItems(query: String): Flow<List<EventItem>>
}


@Database(entities = [EventItem::class], version = 1, exportSchema = false)
abstract class FilterDatabase : RoomDatabase() {
    abstract fun eventItemDao(): EventItemDao

    companion object {
        @Volatile private var instance: FilterDatabase? = null

        fun getDatabase(context: Context): FilterDatabase =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    FilterDatabase::class.java,
                    "event_filter_database"
                ).addCallback(DatabaseCallback())
                    .fallbackToDestructiveMigration()
                    .build().also { instance = it }
            }

        private class DatabaseCallback : RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                instance?.let { database ->
                    CoroutineScope(Dispatchers.IO).launch {
                        populateDatabase(database.eventItemDao())
                    }
                }
            }
        }

        suspend fun populateDatabase(eventItemDao: EventItemDao) {
            val initialEventItems = listOf(
                // Balloons
                EventItem(name = "Balloon Festival", category = "Balloons", description = "A celebration with colorful hot air balloons.", imagePath = "balloons"),
                EventItem(name = "Balloon Fair", category = "Balloons", description = "Family fun day with balloon shows and games.", imagePath = "balloons"),
                EventItem(name = "Balloon Parade", category = "Balloons", description = "Parade featuring giant balloon sculptures.", imagePath = "balloons"),
                EventItem(name = "Balloon Night Glow", category = "Balloons", description = "Night event with illuminated hot air balloons.", imagePath = "balloons"),
                EventItem(name = "Balloon Competition", category = "Balloons", description = "Competitive ballooning event for enthusiasts.", imagePath = "balloons"),

                // Streamers
                EventItem(name = "Streamer Parade", category = "Streamers", description = "A parade decorated with vibrant streamers.", imagePath = "streamers"),
                EventItem(name = "Streamer Festival", category = "Streamers", description = "Festival adorned with colorful streamers.", imagePath = "streamers"),
                EventItem(name = "Streamer Night Event", category = "Streamers", description = "An evening event enhanced with beautiful streamers.", imagePath = "streamers"),
                EventItem(name = "Streamer Decor Workshop", category = "Streamers", description = "Workshop on decorating with streamers.", imagePath = "streamers"),
                EventItem(name = "Streamer Art Display", category = "Streamers", description = "Exhibition showcasing creative uses of streamers.", imagePath = "streamers"),

                // Drink
                EventItem(name = "Summer Cocktail Night", category = "Drink", description = "An evening of exotic drinks and music.", imagePath = "drink"),
                EventItem(name = "Winter Warmer Drinks", category = "Drink", description = "A cozy night with warm winter beverages.", imagePath = "drink"),
                EventItem(name = "Classic Wine Tasting", category = "Drink", description = "Tasting event featuring classic wines.", imagePath = "drink"),
                EventItem(name = "Craft Beer Fest", category = "Drink", description = "Festival showcasing local and international craft beers.", imagePath = "drink"),
                EventItem(name = "Drink Mixology Class", category = "Drink", description = "Learn the art of cocktail mixology.", imagePath = "drink"),

                // Venue
                EventItem(name = "Elegant Wedding Venue", category = "Venue", description = "A beautiful outdoor wedding venue.", imagePath = "venue"),
                EventItem(name = "Corporate Event Space", category = "Venue", description = "Ideal venue for corporate events and conferences.", imagePath = "venue"),
                EventItem(name = "Beach Party Location", category = "Venue", description = "Perfect beach location for private parties.", imagePath = "venue"),
                EventItem(name = "Historic Venue Tour", category = "Venue", description = "Tour of historic and culturally significant venues.", imagePath = "venue"),
                EventItem(name = "Urban Rooftop Event", category = "Venue", description = "Host events on a scenic urban rooftop.", imagePath = "venue"),

                // DJ
                EventItem(name = "DJ Music Fest", category = "Dj", description = "A night filled with music from top DJs.", imagePath = "dj"),
                EventItem(name = "DJ Workshop", category = "Dj", description = "Workshop on DJ skills and techniques.", imagePath = "dj"),
                EventItem(name = "DJ Battle Night", category = "Dj", description = "Competitive DJ battle showcasing talent.", imagePath = "dj"),
                EventItem(name = "Electronic Dance Music Party", category = "Dj", description = "Dance the night away at an EDM party.", imagePath = "dj"),
                EventItem(name = "Retro DJ Vinyl Night", category = "Dj", description = "Retro-themed night with DJs spinning vinyl records.", imagePath = "dj"),

                // Music
                EventItem(name = "Orchestral Music Evening", category = "Music", description = "An evening with classical music performances.", imagePath = "music"),
                EventItem(name = "Jazz Night", category = "Music", description = "A night dedicated to jazz music with live bands.", imagePath = "music"),
                EventItem(name = "Rock Concert", category = "Music", description = "Live rock concert featuring popular bands.", imagePath = "music"),
                EventItem(name = "Indie Music Showcase", category = "Music", description = "Discover new talents at our indie music night.", imagePath = "music"),
                EventItem(name = "Choir Performance", category = "Music", description = "Experience the harmonious sounds of a live choir.", imagePath = "music"),

                // Catering
                EventItem(name = "Catering Expo", category = "Catering", description = "Showcase of fine dining and catering services.", imagePath = "catering"),
                EventItem(name = "Wedding Catering Fair", category = "Catering", description = "Explore catering options for weddings.", imagePath = "catering"),
                EventItem(name = "Gourmet Food Festival", category = "Catering", description = "Festival featuring gourmet food from top chefs.", imagePath = "catering"),
                EventItem(name = "Mobile Catering Meetup", category = "Catering", description = "Meetup for mobile catering businesses.", imagePath = "catering"),
                EventItem(name = "Catering Workshop", category = "Catering", description = "Learn catering skills from experienced professionals.", imagePath = "catering")
            )
            eventItemDao.insertItems(initialEventItems)
        }
    }
}