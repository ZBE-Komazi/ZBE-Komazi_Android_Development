package com.example.project.viewmodel

/*
 * Zintle Komazi
 * 2019098256
 * EXAM PROJECT CSIP6853
 * 5 JUNE 2024

 */

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import androidx.lifecycle.viewModelScope
import com.example.project.model.ChatUiModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class ChatViewModel : ViewModel() {

    val conversation: StateFlow<List<ChatUiModel.Message>>
        get() = _conversation
    private val _conversation = MutableStateFlow(
        listOf(ChatUiModel.Message.initConv)
    )

    private val questions = mutableListOf(
        "Host a 'Tomato Gala' and surprise your guests by revealing that tomatoes are actually fruit.",
        "Create a 'Coffee Connoisseur's Evening' where you explore the art of coffee making, including a demo on how a pinch of salt can reduce its bitterness.",
        "Organize a 'Post-Workout Snack Workshop' focusing on bananas and their benefits for workout recovery. Include other potassium-rich foods in your menu.",
        "Plan a 'Heart-Healthy Chocolate Tasting' event that educates attendees on the benefits of dark chocolate and offers samples of various cacao contents.",
        "Design an 'Avocado Appreciation Brunch' that showcases avocados in different dishes. Highlight their role as a source of healthy fats.",
        "Arrange a 'Garlic Feast' to celebrate its immune-boosting properties. Offer a variety of garlic-infused dishes and provide tips on cooking with garlic.",
        "Host a 'Spinach and Super Greens Festival' to discuss the nutritional power of leafy greens like spinach. Include cooking demonstrations and tastings.",
        "Curate a 'Balanced Diet Dessert Party' with dark chocolate as a featured ingredient, discussing moderation and health benefits.",
        "Plan an 'Antioxidant Almond Bash' where guests can learn about the antioxidant benefits of almonds through interactive nut-based recipes and snacks.",
        "Set up a 'Greek Yogurt Breakfast Club' to explore its benefits as a protein source and its role in maintaining digestive health.",
        "Organize a 'Tropical Fruits Fiesta' to explore the health benefits of tropical fruits with a focus on mangoes, known for their skin-health properties.",
        "Host a 'Sustainable Eating Workshop' focusing on the benefits of plant-based diets, including a segment on the environmental impacts of food choices.",
        "Arrange a 'Herbs and Health Gathering' where guests can learn about the health benefits of various herbs through cooking demonstrations and tastings.",
        "Plan a 'Root Vegetable Harvest' event to explore the nutritional benefits of root vegetables, including cooking competitions or tastings.",
        "Create a 'Seafood Sustainability Symposium' with a focus on the health benefits and sustainability of different types of seafood.",
        "Host a 'Whole Grains Workshop' that teaches about the benefits of whole grains in a diet, including cooking sessions with different grains.",
        "Set up a 'Fermentation Fest' to explore the health benefits of fermented foods like kimchi, kombucha, and sauerkraut through tastings and demonstrations.",
        "Organize a 'Healthy Fats Forum' to debunk myths about fats and discuss the benefits of sources like fish oil and nuts.",
        "Arrange a 'Spice Sensation Evening' to explore the health benefits and culinary uses of spices like turmeric and cinnamon.",
        "Plan a 'Local Produce Picnic' to highlight the health and environmental benefits of eating locally sourced fruits and vegetables."

    )

    fun sendChat(msg: String) {

        val myChat = ChatUiModel.Message(msg, ChatUiModel.Author.me)
        viewModelScope.launch {
            _conversation.emit(_conversation.value + myChat)

            delay(1000)
            _conversation.emit(_conversation.value + getRandomQuestion())
        }
    }

    private fun getRandomQuestion(): ChatUiModel.Message {
        val question = if (questions.isEmpty()) {
            "That's all the tips I have for now. Ask me again later!"
        } else {
            questions.random()
        }

        if (questions.isNotEmpty()) questions.remove(question)

        return ChatUiModel.Message(
            text = question,
            author = ChatUiModel.Author.bot
        )
    }
}