package com.example.project.viewmodel

/*
 * Zintle Komazi
 * 2019098256
 * EXAM PROJECT CSIP6853
 * 5 JUNE 2024

 */

import androidx.lifecycle.LiveData
import androidx.lifecycle.MediatorLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.project.model.PinterestMemory
import com.example.project.model.PinterestRepository
import kotlinx.coroutines.launch

class PinterestViewModel(private val repository: PinterestRepository) : ViewModel() {
    val memories: LiveData<List<PinterestMemory>> = repository.getAllMemories()

    private val _albums = MediatorLiveData<List<String>>().apply {
        addSource(memories) { memoryList ->
            value = memoryList.map { it.title }.distinct()
        }
    }
    val albums: LiveData<List<String>> get() = _albums

    fun createMemory(memoryTitle: String, date: Long, mediaPath: String, mediaType: String) {
        val newMemory = PinterestMemory(
            date = date,
            mediaPath = mediaPath,
            mediaType = mediaType,
            title = memoryTitle
        )
        viewModelScope.launch {
            repository.insertMemory(newMemory)
        }
    }
}


class PinterestViewModelFactory(private val repository: PinterestRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(PinterestViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return PinterestViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
