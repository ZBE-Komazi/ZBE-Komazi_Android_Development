package com.example.project.view
/*
 * Zintle Komazi
 * 2019098256
 * EXAM PROJECT CSIP6853
 * 5 JUNE 2024

 */
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.DrawerValue
import androidx.compose.material.ModalDrawer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Facebook
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.rememberDrawerState
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.project.R
import com.example.project.viewmodel.UserViewModel
import kotlinx.coroutines.launch

@Composable
fun AboutScreen(navController: NavController, userViewModel: UserViewModel, selectedTab: MutableState<Int>) {
    AboutModalDrawerComponent(navController = navController, userViewModel = userViewModel, selectedTab = selectedTab)
}

@Composable
fun AboutContent(paddingValues: PaddingValues, navController: NavController, userViewModel: UserViewModel) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(paddingValues)
            .padding(0.dp),
        contentAlignment = Alignment.TopStart
    ) {
        Image(
            painter = painterResource(id = R.drawable.transparent),
            contentDescription = "Background Image",
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxHeight()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // App Logo
                Image(
                    painter = painterResource(id = R.drawable.iteration), // Replace with your app logo resource
                    contentDescription = "App Logo",
                    modifier = Modifier
                        .size(100.dp)
                        .clip(CircleShape)
                        .padding(16.dp).background(Color.Transparent)
                )

                // App Name
                Text(
                    text = "Evntique - Plan Your Perfect Event",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                    color = Color(0xFFFFA500)
                )

                // Short Description
                Text(
                    text = "Evntique is your ultimate event planning app designed to make organizing events a breeze. Whether it's a small gathering or a large conference, Evntique helps you manage every detail to ensure a successful event.",
                    style = MaterialTheme.typography.titleSmall,
                    textAlign = TextAlign.Justify,
                    color = Color.White
                )

                // Divider
                Divider(color = Color.Black, thickness = 2.dp)

                // Company Info
                Text(
                    text = "About Us",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                    color = Color(0xFFFFA500)
                )
                Text(
                    text = "We are a dedicated team of event enthusiasts committed to providing the best tools for planning and executing flawless events. With Evntique, our goal is to simplify the event planning process and make it accessible to everyone.",
                    style = MaterialTheme.typography.titleSmall,
                    textAlign = TextAlign.Justify,
                    color = Color.White
                )

                // Divider
                Divider(color = Color.Black, thickness = 2.dp)
                // Contact Information
                Text(
                    text = "Contact Us",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                    color = Color(0xFFFFA500)
                )

                    Text(
                        text = "Email: contact@buddyapp.com",
                        style = MaterialTheme.typography.titleSmall,
                        textAlign = TextAlign.Start,
                        color = Color.White
                    )
                    Text(
                        text = "Phone: +1 (234) 567-8901",
                        style = MaterialTheme.typography.titleSmall,
                        textAlign = TextAlign.Start,
                        color = Color.White
                    )
                    Text(
                        text = "Address: 123 Travel Street, Wanderlust City, Adventureland",
                        style = MaterialTheme.typography.titleSmall,
                        textAlign = TextAlign.Justify,
                        color = Color.White
                    )


                // Divider
                Divider(color = Color.Black, thickness = 2.dp)

                // Social Media
                Text(
                    text = "Follow Us",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                    color = Color(0xFFFFA500)
                )
                Row(
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { /* TODO: Add action */ }) {
                        Icon(
                            Icons.Filled.Facebook,
                            contentDescription = "Facebook",
                            tint = Color(0xFFFFA500)
                        )
                    }
                    IconButton(onClick = { /* TODO: Add action */ }) {
                        Icon(
                            painterResource(id = R.drawable.twitter),
                            contentDescription = "Twitter",
                            tint = Color(0xFFFFA500),
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    IconButton(onClick = { /* TODO: Add action */ }) {
                        Icon(
                            painterResource(id = R.drawable.instagram),
                            contentDescription = "Instagram",
                            tint = Color(0xFFFFA500),
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AboutModalDrawerComponent(navController: NavController, userViewModel: UserViewModel, selectedTab: MutableState<Int>) {
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val coroutineScope = rememberCoroutineScope()
    val user by userViewModel.currentUser.observeAsState()
    val isLogoutDialogVisible by userViewModel.isLogoutDialogVisible.observeAsState(false)

    ModalDrawer(
        drawerState = drawerState,
        drawerContent = {
            DrawerHeader(user, userViewModel, navController)
            DrawerItems(navController, selectedTab, userViewModel)
        },
        gesturesEnabled = drawerState.isOpen
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("Know More About Us ${user?.name ?: "User"}",color = Color(0xFFFFA500)) },
                    navigationIcon = {
                        IconButton(onClick = { coroutineScope.launch { drawerState.open() } }) {
                            Icon(Icons.Filled.Menu, contentDescription = "Menu",tint = Color(0xFFFFA500))
                        }
                    },
                    colors = TopAppBarDefaults.smallTopAppBarColors(
                        containerColor = Color(android.graphics.Color.rgb(107, 64, 246))
                    )
                )
            },
            bottomBar = { HomeBottomBar(navController, selectedTab) }
        ) { paddingValues ->
            AboutContent(paddingValues, navController, userViewModel)
        }
    }

    if (isLogoutDialogVisible) {
        LogoutDialog(
            user = user,
            onConfirm = {
                userViewModel.logout()
                navController.navigate("main") {
                    popUpTo("home") { inclusive = true }
                }
            },
            onDismiss = {
                userViewModel.hideLogoutDialog()
            }
        )
    }
}
