package com.example.project.view

/*
 * Zintle Komazi
 * 2019098256
 * EXAM PROJECT CSIP6853
 * 5 JUNE 2024

 */

import android.content.Intent
import android.net.Uri
import android.widget.MediaController
import android.widget.VideoView
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.AlertDialog
import androidx.compose.material.Card
import androidx.compose.material.DrawerValue
import androidx.compose.material.ModalDrawer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Event
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Message
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.PhotoAlbum
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.rememberDrawerState
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.livedata.observeAsState
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.navigation.NavController
import coil.compose.rememberImagePainter
import com.example.project.MapsActivity
import com.example.project.R
import com.example.project.viewmodel.PinterestViewModel
import com.example.project.viewmodel.UserViewModel
import kotlinx.coroutines.launch


@Composable
fun PinterestScreen(
    navController: NavController,
    userViewModel: UserViewModel,
    selectedTab: MutableState<Int>,
    pinterestViewModel: PinterestViewModel
) {
    PinterestModalDrawerComponent(
        navController = navController,
        userViewModel = userViewModel,
        selectedTab = selectedTab,
        pinterestViewModel = pinterestViewModel
    ) { paddingValues ->
        PinterestContent(paddingValues, navController, userViewModel, pinterestViewModel)
    }
}


@Composable
fun PinterestContent(
    paddingValues: PaddingValues,
    navController: NavController,
    userViewModel: UserViewModel,
    pinterestViewModel: PinterestViewModel
) {
    val albums by pinterestViewModel.albums.observeAsState(emptyList())
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(0.dp),
        contentAlignment = Alignment.TopStart
    ) {
        Image(
            painter = painterResource(id = R.drawable.layout3),
            contentDescription = "Background Image",
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp),
            contentAlignment = Alignment.TopStart
        ) {
            Column(
                modifier = Modifier.fillMaxHeight(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    "Explore Your Gallery",
                    style = MaterialTheme.typography.titleSmall,
                    modifier = Modifier.padding(16.dp)
                )
                LazyColumn {
                    items(albums) { album ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(8.dp)
                                .clickable { navController.navigate("album/$album") }
                                .background(Color(android.graphics.Color.rgb(107, 64, 246))),
                            elevation = 8.dp
                        ) {
                            Row(
                                modifier = Modifier.padding(16.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.PhotoAlbum, contentDescription = "Album Icon")
                                Spacer(modifier = Modifier.width(16.dp))
                                Text(album, style = MaterialTheme.typography.titleSmall)
                            }
                        }
                    }
                }
            }
        }
    }
}


@Composable
fun AlbumContent(
    navController: NavController,
    userViewModel: UserViewModel,
    selectedTab: MutableState<Int>,
    pinterestViewModel: PinterestViewModel,
    albumTitle: String
) {
    val context = LocalContext.current
    val allMemories by pinterestViewModel.memories.observeAsState(emptyList())
    val albumMemories = allMemories.filter { it.title == albumTitle }
    val galleryUriList = remember { mutableStateListOf<Uri>() }
    val coroutineScope = rememberCoroutineScope()

    val imageLauncher = rememberLauncherForActivityResult(contract = ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri?.let {
            galleryUriList.add(it)
            coroutineScope.launch {
                val mimeType = context.contentResolver.getType(it)
                pinterestViewModel.createMemory(albumTitle, System.currentTimeMillis(), it.toString(), "image")
            }
        }
    }

    val videoLauncher = rememberLauncherForActivityResult(contract = ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri?.let {
            galleryUriList.add(it)
            coroutineScope.launch {
                val mimeType = context.contentResolver.getType(it)
                pinterestViewModel.createMemory(albumTitle, System.currentTimeMillis(), it.toString(), "video")
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(0.dp),
        contentAlignment = Alignment.TopStart
    ) {
        Image(
            painter = painterResource(id = R.drawable.layout1),
            contentDescription = "Background Image",
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            contentAlignment = Alignment.TopStart
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp)
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Top
            ) {
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(150.dp), // Adjust the column size as needed
                    modifier = Modifier.weight(1f)
                ) {
                    items(albumMemories) { memory ->
                        Card(
                            modifier = Modifier
                                .padding(8.dp)
                                .fillMaxWidth(),
                            backgroundColor = MaterialTheme.colorScheme.surface,
                            elevation = 4.dp
                        ) {
                            val contentResolver = context.contentResolver
                            val mimeType = contentResolver.getType(Uri.parse(memory.mediaPath))
                            if (mimeType != null && mimeType.startsWith("image")) {
                                Image(
                                    painter = rememberImagePainter(Uri.parse(memory.mediaPath)),
                                    contentDescription = null,
                                    modifier = Modifier
                                        .fillMaxSize() // This makes the image fill the entire card
                                )
                            } else if (mimeType != null && mimeType.startsWith("video")) {
                                AndroidView(
                                    factory = {
                                        VideoView(context).apply {
                                            setVideoURI(Uri.parse(memory.mediaPath))
                                            setMediaController(MediaController(context).apply {
                                                setAnchorView(this@apply)
                                            })
                                            requestFocus()
                                            start()
                                        }
                                    }, modifier = Modifier
                                        .fillMaxSize() // This makes the video fill the entire card
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
                Row {
                    Button(
                        onClick = { imageLauncher.launch("image/*") },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFFA500))
                    ) {
                        Icon(Icons.Default.PhotoCamera, contentDescription = "Select Photo")
                        Text("Select Photo")
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = { videoLauncher.launch("video/*") },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFFA500))
                    ) {
                        Icon(Icons.Default.Videocam, contentDescription = "Select Video")
                        Text("Select Video")
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))
                Button(
                    onClick = {
                        navController.popBackStack()
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Done")
                }
            }
        }
    }
}


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PinterestModalDrawerComponent(
    navController: NavController,
    userViewModel: UserViewModel,
    selectedTab: MutableState<Int>,
    pinterestViewModel: PinterestViewModel,
    content: @Composable (PaddingValues) -> Unit
) {
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val coroutineScope = rememberCoroutineScope()
    val user by userViewModel.currentUser.observeAsState()
    val isLogoutDialogVisible by userViewModel.isLogoutDialogVisible.observeAsState(false)
    var showDialog by remember { mutableStateOf(false) }

    ModalDrawer(
        drawerState = drawerState,
        drawerContent = {
            DrawerHeader(user, userViewModel, navController)
            DrawerItems(navController, selectedTab, userViewModel)
        },
        gesturesEnabled = drawerState.isOpen
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("${user?.name ?: "User"} Pinterest", color = Color(0xFFFFA500)) },
                    navigationIcon = {
                        IconButton(onClick = { coroutineScope.launch { drawerState.open() } }) {
                            Icon(Icons.Filled.Menu, contentDescription = "Menu", tint = Color(0xFFFFA500))
                        }
                    },
                    colors = TopAppBarDefaults.smallTopAppBarColors(
                        containerColor = Color(android.graphics.Color.rgb(107, 64, 246))
                    )
                )
            },
            bottomBar = { GalleryBottomBar(navController, selectedTab) }
        ) { paddingValues ->
            content(paddingValues)
        }
    }

    if (isLogoutDialogVisible) {
        LogoutDialog(
            user = user,
            onConfirm = {
                userViewModel.logout()
                navController.navigate("main") {
                    popUpTo("home") { inclusive = true }
                }
            },
            onDismiss = {
                userViewModel.hideLogoutDialog()
            }
        )
    }

    if (showDialog) {
        AlbumCreationDialog(
            onDismiss = { showDialog = false },
            onCreate = { albumName ->
                showDialog = false
                pinterestViewModel.createMemory(albumName, System.currentTimeMillis(), "", "album")
                navController.navigate("album/$albumName")
            }
        )
    }
}



@Composable
fun GalleryBottomBar(navController: NavController, selectedTab: MutableState<Int>) {
    var showDialog by remember { mutableStateOf(false) }
    val context = LocalContext.current // Get the context

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(72.dp)  // Set a fixed height for the bottom navigation bar area
    ) {
        NavigationBar(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth(),
            containerColor = Color(android.graphics.Color.rgb(107, 64, 246))
        ) {
            NavigationBarItem(
                icon = { Icon(Icons.Filled.Home, contentDescription = "Home", tint = Color(0xFFFFA500)) },
                label = { Text("HOME", color = Color.White) },
                selected = selectedTab.value == 0,
                onClick = {
                    selectedTab.value = 0
                    navController.navigate("home")
                }
            )

            NavigationBarItem(
                icon = { Icon(Icons.Filled.Event, contentDescription = "Event", tint = Color(0xFFFFA500)) },
                label = { Text("MAP", color = Color.White) },
                selected = selectedTab.value == 1,
                onClick = {
                    selectedTab.value = 1
                    // Launch MapsActivity
                    val intent = Intent(context, MapsActivity::class.java)
                    context.startActivity(intent)
                }
            )

            Spacer(modifier = Modifier.weight(1f, true))  // Dynamic spacing for alignment

            NavigationBarItem(
                icon = { Icon(Icons.Filled.Notifications, contentDescription = "Notify", tint = Color(0xFFFFA500)) },
                label = { Text("NOTIFY", color = Color.White) },
                selected = selectedTab.value == 2,
                onClick = {
                    selectedTab.value = 2
                    navController.navigate("notifyBottomNav")
                }
            )

            NavigationBarItem(
                icon = { Icon(Icons.Filled.Message, contentDescription = "Message", tint = Color(0xFFFFA500)) },
                label = { Text("BOT", color = Color.White) },
                selected = selectedTab.value == 3,
                onClick = {
                    selectedTab.value = 3
                    navController.navigate("messageBottomNav")
                }
            )
        }

        FloatingActionButton(
            onClick = { showDialog = true },
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 10.dp)
                .size(60.dp),
            containerColor = MaterialTheme.colorScheme.secondary
        ) {
            Icon(
                imageVector = Icons.Filled.Add,
                contentDescription = "Add",
                tint = Color(0xFFFFA500),
                modifier = Modifier.size(36.dp)
            )
        }

        if (showDialog) {
            AlbumCreationDialog(
                onDismiss = { showDialog = false },
                onCreate = { albumName ->
                    showDialog = false
                    navController.navigate("gallery/$albumName")
                }
            )
        }
    }
}

@Composable
fun AlbumCreationDialog(
    onDismiss: () -> Unit,
    onCreate: (String) -> Unit
) {
    var albumName by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Create Album") },
        text = {
            Column {
                TextField(
                    value = albumName,
                    onValueChange = { albumName = it },
                    label = { Text("Album Name") }
                )
            }
        },
        confirmButton = {
            Button(onClick = {
                if (albumName.isNotEmpty()) {
                    onCreate(albumName)
                }
            }) {
                Text("Next")
            }
        },
        dismissButton = {
            Button(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}