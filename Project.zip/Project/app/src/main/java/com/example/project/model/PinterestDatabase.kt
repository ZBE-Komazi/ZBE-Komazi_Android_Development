package com.example.project.model

/*
 * Zintle Komazi
 * 2019098256
 * EXAM PROJECT CSIP6853
 * 5 JUNE 2024

 */

import android.content.Context
import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters

@Entity
data class PinterestMemory(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val date: Long, // Timestamp for the date
    val mediaPath: String, // Path to the stored media
    val mediaType: String, // "image" or "video"
    val title: String // Title for the memory
)

@Dao
interface PinterestDao {

    @Query("SELECT * FROM PinterestMemory")
    fun getAllMemories(): LiveData<List<PinterestMemory>>

    @Insert
    suspend fun insertMemory(memory: PinterestMemory)
}


@Database(entities = [PinterestMemory::class], version = 1)
@TypeConverters(DateConverter::class)
abstract class PinterestDatabase : RoomDatabase() {
    abstract fun pinterestDao(): PinterestDao

    companion object {
        // Singleton prevents multiple instances of database opening at the same time.
        @Volatile
        private var INSTANCE: PinterestDatabase? = null

        fun getDatabase(context: Context): PinterestDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    PinterestDatabase::class.java,
                    "pinterest_database"
                ).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
