package com.example.project.viewmodel
/*
 * Zintle Komazi
 * 2019098256
 * EXAM PROJECT CSIP6853
 * 5 JUNE 2024

 */

import android.app.Application
import android.content.Context
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.project.model.EventItem
import com.example.project.model.FilterDatabase
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream
import java.io.IOException

class FilterViewModel(application: Application) : AndroidViewModel(application) {
    private val database = FilterDatabase.getDatabase(application)
    private val eventItemDao = database.eventItemDao()

    private val _filteredItems = MutableStateFlow<List<EventItem>>(emptyList())
    val filteredItems: StateFlow<List<EventItem>> = _filteredItems

    init {
        filterItems("")
    }

    fun filterItems(category: String) {
        viewModelScope.launch {
            eventItemDao.getItemsByCategory(category).collect { items ->
                _filteredItems.value = items
            }
        }
    }
}

fun saveImageToInternalStorage(context: Context, uri: Uri, fileName: String): String {
    val directory = context.filesDir
    val file = File(directory, fileName)
    try {
        context.contentResolver.openInputStream(uri)?.use { inputStream ->
            FileOutputStream(file).use { outputStream ->
                inputStream.copyTo(outputStream)
            }
        }
    } catch (e: IOException) {
        e.printStackTrace()
    }
    return file.absolutePath
}
