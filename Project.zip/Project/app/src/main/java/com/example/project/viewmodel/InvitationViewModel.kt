package com.example.project.viewmodel


import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.project.model.Invitation
import com.example.project.model.InvitationRepository
import kotlinx.coroutines.launch

class InvitationViewModel(private val repository: InvitationRepository) : ViewModel() {
    val allInvitations: LiveData<List<Invitation>> = repository.allInvitations

    fun createInvitation(title: String, username: String, instagram: String, userId: String, date: String, time: String, userImage: Int, userQrCode: Int) = viewModelScope.launch {
        val newInvitation = Invitation(
            title = title,
            username = username,
            instagram = instagram,
            userId = userId,
            date = date,
            time = time,
            userImage = userImage,
            userQrCode = userQrCode
        )
        repository.insertInvitation(newInvitation)
    }
}


class InvitationViewModelFactory(private val repository: InvitationRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(InvitationViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return InvitationViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
