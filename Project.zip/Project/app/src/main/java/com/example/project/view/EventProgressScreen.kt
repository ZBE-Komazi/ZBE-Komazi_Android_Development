package com.example.project.view

/*
 * Zintle Komazi
 * 2019098256
 * EXAM PROJECT CSIP6853
 * 5 JUNE 2024

 */

import android.view.ViewGroup
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.Button
import androidx.compose.material.ButtonDefaults
import androidx.compose.material.LinearProgressIndicator
import androidx.compose.material.RadioButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.navigation.NavController
import com.example.project.R
import com.example.project.model.EventProgress
import com.example.project.model.chartToJson
import com.example.project.viewmodel.EventProgressViewModel
import com.github.mikephil.charting.charts.LineChart
import com.github.mikephil.charting.charts.PieChart
import com.github.mikephil.charting.data.Entry
import com.github.mikephil.charting.data.LineData
import com.github.mikephil.charting.data.LineDataSet
import com.github.mikephil.charting.data.PieData
import com.github.mikephil.charting.data.PieDataSet
import com.github.mikephil.charting.data.PieEntry
import com.github.mikephil.charting.utils.ColorTemplate

@Composable
fun PieChartView(progressData: List<Pair<String, Float>>) {
    val context = LocalContext.current
    AndroidView(
        factory = {
            PieChart(context).apply {
                layoutParams = ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
                setPadding(16, 16, 16, 16)
                setUsePercentValues(true)
                description.isEnabled = false
                setDrawEntryLabels(true)
                legend.isEnabled = true
            }
        },
        update = { pieChart ->
            val entries = progressData.map { PieEntry(it.second, it.first) }
            val dataSet = PieDataSet(entries, "Milestones")
            dataSet.colors = ColorTemplate.COLORFUL_COLORS.toList()
            val data = PieData(dataSet)
            pieChart.data = data
            pieChart.invalidate()
        },
        modifier = Modifier
            .fillMaxWidth()
            .height(400.dp)
            .padding(16.dp)
    )
}
@Composable
fun LineChartView(progressData: List<Pair<String, Float>>) {
    val context = LocalContext.current
    AndroidView(
        factory = {
            LineChart(context).apply {
                layoutParams = ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
                setPadding(16, 16, 16, 16)
                description.isEnabled = false
                legend.isEnabled = true
                legend.textColor = android.graphics.Color.WHITE // Set legend labels to white
                xAxis.textColor = android.graphics.Color.WHITE  // Set X-axis labels to white
                axisLeft.textColor = android.graphics.Color.WHITE  // Set Y-axis labels to white
                axisRight.isEnabled = false // Disable right Y-axis if not needed
            }
        },
        update = { lineChart ->
            val entries = progressData.mapIndexed { index, pair -> Entry(index.toFloat(), pair.second) }
            val dataSet = LineDataSet(entries, "Milestones")
            dataSet.colors = ColorTemplate.COLORFUL_COLORS.toList()
            dataSet.setCircleColors(*ColorTemplate.COLORFUL_COLORS)
            val data = LineData(dataSet)
            lineChart.data = data
            lineChart.invalidate()
        },
        modifier = Modifier
            .fillMaxWidth()
            .height(550.dp)
            .padding(16.dp)
    )
}

@Composable
fun ProgressContent(navController: NavController, progressPercentage: Int, progressList: List<EventProgress>) {
    val statusValues = mapOf(
        "Not Started" to 1,
        "In Progress" to 3,
        "Complete" to 5
    )
    val progressData = progressList.map { progress ->
        val percentage = (statusValues[progress.status] ?: 0) * 10f
        progress.milestone to percentage
    }
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(0.dp),
        contentAlignment = Alignment.TopStart
    ) {
        Image(
            painter = painterResource(id = R.drawable.layout1),
            contentDescription = "Background Image",
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            contentAlignment = Alignment.TopStart
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp).verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = "User, your progress is $progressPercentage%",
                    style = MaterialTheme.typography.displaySmall,
                    color = Color.White
                )
                Spacer(modifier = Modifier.height(20.dp))

                LinearProgressIndicator(
                    progress = progressPercentage / 100f,
                    color = Color(0xFFFFA500),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)  // Increased height
                        .padding(vertical = 16.dp)
                )
                Spacer(modifier = Modifier.height(30.dp))
                PieChartView(progressData)
                Spacer(modifier = Modifier.height(30.dp))
                LineChartView(progressData)

                Button(
                    onClick = { navController.navigate("home") },
                    modifier = Modifier.align(Alignment.CenterHorizontally).fillMaxWidth()
                ) {
                    Text("Go Home",color=Color(0xFFFFA500))
                }
            }
        }
    }
}

@Composable
fun EventProgressScreen(navController: NavController, viewModel: EventProgressViewModel, eventTitle: String) {
    val (isTracking, setIsTracking) = remember { mutableStateOf(false) }
    val progressList = remember { mutableStateListOf<EventProgress>() }
    val progressPercentage = remember { mutableStateOf(0) }
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(0.dp),
        contentAlignment = Alignment.TopStart
    ) {
        Image(
            painter = painterResource(id = R.drawable.transparent),
            contentDescription = "Background Image",
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            contentAlignment = Alignment.TopStart
        ) {
            if (!isTracking) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = "Event Progress for $eventTitle",
                        style = MaterialTheme.typography.titleMedium,
                        color = MaterialTheme.colorScheme.primary
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = { setIsTracking(true) },
                        colors = ButtonDefaults.buttonColors(backgroundColor = Color(0xFFFFA500)),  // Orange color
                        modifier = Modifier
                            .fillMaxWidth()  // Fill entire width
                    ) {
                        Text("Begin Event Tracking")
                    }
                }
            } else {
                EventTrackingForm(
                    navController,
                    viewModel,
                    eventTitle,
                    progressList,
                    progressPercentage
                )
            }
        }
    }
}


@Composable
fun EventTrackingForm(
    navController: NavController,
    viewModel: EventProgressViewModel,
    eventTitle: String,
    progressList: SnapshotStateList<EventProgress>,
    progressPercentage: MutableState<Int>
) {
    val currentEventId = remember { mutableStateOf(0) }  // Counter for event ID
    val milestones = listOf(
        "Booking a Venue",
        "Sending Invitations",
        "Confirming Attendees",
        "Arranging Catering",
        "Booking Entertainment",
        "Finalizing Decorations",
        "Creating a Schedule"
    )
    val statuses = listOf("Not Started", "In Progress", "Complete")
    val milestoneStatuses = remember { mutableStateMapOf<String, String>() }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(0.dp),
        contentAlignment = Alignment.TopStart
    ) {
        Image(
            painter = painterResource(id = R.drawable.transparent),
            contentDescription = "Background Image",
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            contentAlignment = Alignment.TopStart
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp)
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.Start  // Align to the left
            ) {
                Text(
                    text = "Event Progress for $eventTitle",
                    style = MaterialTheme.typography.titleLarge,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(vertical = 16.dp)
                )

                milestones.forEach { milestone ->
                    Text(
                        text = milestone,
                        style = MaterialTheme.typography.titleLarge,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(vertical = 8.dp)
                    )

                    statuses.forEach { status ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(vertical = 4.dp)
                        ) {
                            RadioButton(
                                selected = milestoneStatuses[milestone] == status,
                                onClick = { milestoneStatuses[milestone] = status }
                            )
                            Text(text = status,style = MaterialTheme.typography.titleLarge,
                                color = Color.White)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = {
                        val eventIdInt = ++currentEventId.value  // Increment the event ID counter
                        val newProgressList = milestones.map { milestone ->
                            EventProgress(
                                eventId = eventIdInt,
                                eventTitle = eventTitle,
                                milestone = milestone,
                                status = milestoneStatuses[milestone] ?: "Not Started"
                            )
                        }
                        viewModel.insertProgress(newProgressList)
                        progressList.clear()
                        progressList.addAll(newProgressList)
                        progressPercentage.value = calculateProgressPercentage(newProgressList)
                        navController.navigate(
                            "progressContent/${progressPercentage.value}/${
                                chartToJson(
                                    newProgressList
                                )
                            }"
                        )
                    },
                    colors = ButtonDefaults.buttonColors(backgroundColor = Color(0xFFFFA500)),  // Orange color
                    modifier = Modifier
                        .fillMaxWidth()  //
                    // Align button to the left
                ) {
                    Text("Update")
                }
            }
        }
    }
}


fun calculateProgressPercentage(progressList: List<EventProgress>): Int {
    val statusValues = mapOf(
        "Not Started" to 1,
        "In Progress" to 3,
        "Complete" to 5
    )

    val total = progressList.sumOf { statusValues[it.status] ?: 0 }
    val average = if (progressList.isNotEmpty()) total.toFloat() / progressList.size else 0f
    return (average / 5 * 100).toInt()
}



