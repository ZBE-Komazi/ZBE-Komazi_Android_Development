package com.example.locationapp_2019098256_part1.viewmodel

/*Zintle Komazi
2019098256
02 May 2024
 */

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.android.gms.maps.model.LatLng
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch


class DirectionsViewModel : ViewModel() {
    private val _directions = MutableStateFlow<List<LatLng>>(emptyList())
    val directions: StateFlow<List<LatLng>> = _directions.asStateFlow()

    // Function to fetch directions
    fun getDirections(from: LatLng, to: LatLng) {
        // Simulate fetching directions
        viewModelScope.launch {
            val simulatedDirections = listOf(from, to)  // Simulated list of LatLng
            _directions.value = simulatedDirections
        }
    }
}
