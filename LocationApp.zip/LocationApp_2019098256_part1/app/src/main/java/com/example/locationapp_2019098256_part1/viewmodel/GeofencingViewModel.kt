package com.example.locationapp_2019098256_part1.viewmodel

/*Zintle Komazi
2019098256
02 May 2024
 */

import android.Manifest
import android.app.Application
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import androidx.core.app.ActivityCompat
import androidx.lifecycle.AndroidViewModel
import com.example.locationapp_2019098256_part1.model.GeofenceBroadcastReceiver
import com.google.android.gms.location.Geofence
import com.google.android.gms.location.GeofencingClient
import com.google.android.gms.location.GeofencingRequest
import com.google.android.gms.location.LocationServices


class GeofencingViewModel(application: Application) : AndroidViewModel(application) {
    private val geofencingClient: GeofencingClient = LocationServices.getGeofencingClient(application)
    private val geofencePendingIntent: PendingIntent by lazy {
        val intent = Intent(getApplication(), GeofenceBroadcastReceiver::class.java)
        PendingIntent.getBroadcast(getApplication(), 0, intent, PendingIntent.FLAG_UPDATE_CURRENT)
    }

    companion object {
        private const val GEOFENCE_RADIUS_IN_METERS = 100f
        private const val GEOFENCE_EXPIRATION_IN_MILLISECONDS = Geofence.NEVER_EXPIRE
        private const val GEOFENCE_DWELL_DELAY_IN_MILLISECONDS = 10000
    }

    fun setupGeofences(context: Context) {
        val geofenceList = listOf(
            Geofence.Builder()
                .setRequestId("University of the Free State")
                .setCircularRegion(-29.1044, 26.2014, GEOFENCE_RADIUS_IN_METERS)
                .setExpirationDuration(GEOFENCE_EXPIRATION_IN_MILLISECONDS)
                .setTransitionTypes(Geofence.GEOFENCE_TRANSITION_ENTER)
                .setLoiteringDelay(GEOFENCE_DWELL_DELAY_IN_MILLISECONDS)
                .build(),
            Geofence.Builder()
                .setRequestId("CampusKey 1")
                .setCircularRegion(-29.1078, 26.2123, GEOFENCE_RADIUS_IN_METERS)
                .setExpirationDuration(GEOFENCE_EXPIRATION_IN_MILLISECONDS)
                .setTransitionTypes(Geofence.GEOFENCE_TRANSITION_ENTER)
                .setLoiteringDelay(GEOFENCE_DWELL_DELAY_IN_MILLISECONDS)
                .build()
        )

        val geofencingRequest = GeofencingRequest.Builder()
            .setInitialTrigger(GeofencingRequest.INITIAL_TRIGGER_ENTER)
            .addGeofences(geofenceList)
            .build()

        if (ActivityCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // Permissions are not granted, and should be requested in the activity.
            return
        }

        geofencingClient.addGeofences(geofencingRequest, geofencePendingIntent)
            .addOnSuccessListener {
                // Handle event for geofence addition success
            }
            .addOnFailureListener {
                // Handle event for geofence addition failure
            }
    }

    override fun onCleared() {
        super.onCleared()
        geofencingClient.removeGeofences(geofencePendingIntent) // Clean up when ViewModel is cleared
    }
}
