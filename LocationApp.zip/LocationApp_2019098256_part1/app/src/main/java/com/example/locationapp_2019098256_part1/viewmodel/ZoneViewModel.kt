package com.example.locationapp_2019098256_part1.viewmodel

/*Zintle Komazi
2019098256
02 May 2024
 */

import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.graphics.Color
import androidx.lifecycle.ViewModel
import com.example.locationapp_2019098256_part1.model.Zone
import com.example.locationapp_2019098256_part1.model.ZoneState
import com.google.android.gms.maps.model.LatLng
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow


class ZoneViewModel : ViewModel() {
    private val _zoneState = MutableStateFlow(ZoneState(listOf()))
    val zoneState = _zoneState.asStateFlow()

    var selectedZone = mutableStateOf<Zone?>(null)

    fun createZone() {
        val newZone = Zone(
            points = listOf(
                LatLng(-29.1044, 26.2014),  // University of the Free State
                LatLng(-29.1045, 26.2015),
                LatLng(-29.1046, 26.2016),
                LatLng(-29.1047, 26.2017)
            ),
            fillColor = Color(0x20FF0000),
            strokeColor = Color(0xFFFF0000)
        )
        _zoneState.value = ZoneState(_zoneState.value.zones + newZone)
    }

    fun selectZone(zone: Zone) {
        selectedZone.value = zone
    }

    fun deleteZone(zone: Zone) {
        _zoneState.value = ZoneState(_zoneState.value.zones - zone)
        if (selectedZone.value == zone) {
            selectedZone.value = null
        }
    }
}