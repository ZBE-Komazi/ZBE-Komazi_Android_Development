package com.example.locationapp_2019098256_part1.view

/*Zintle Komazi
2019098256
02 May 2024
 */

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.navigation.NavController
import com.google.android.gms.maps.model.CameraPosition
import com.google.android.gms.maps.model.LatLng
import com.google.maps.android.compose.GoogleMap
import com.google.maps.android.compose.Marker
import com.google.maps.android.compose.MarkerState
import com.google.maps.android.compose.rememberCameraPositionState


@Composable
fun InteractiveMarkersScreen(navController: NavController) {
    // Coordinates near the University of the Free State
    val markers = remember { mutableStateListOf(
        LatLng(-29.1044, 26.2014), // University of the Free State
        LatLng(-29.1211, 26.2140)  // Bloemfontein Zoo
    )
    }
    val cameraPositionState = rememberCameraPositionState {
        position = CameraPosition.fromLatLngZoom(LatLng(-29.1044, 26.2014), 14f)
    }

    GoogleMap(modifier = Modifier.fillMaxSize(), cameraPositionState = cameraPositionState) {
        markers.forEach { location ->
            Marker(state = MarkerState(position = location))
        }
    }
}
