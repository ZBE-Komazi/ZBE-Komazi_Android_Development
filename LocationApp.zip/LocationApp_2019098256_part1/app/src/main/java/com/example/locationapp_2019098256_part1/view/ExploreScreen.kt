package com.example.locationapp_2019098256_part1.view
/*Zintle Komazi
2019098256
02 May 2024
 */


import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController


@Composable
fun ExploreScreen(navController: NavController) {
    val features = listOf(
        "Real-Time Location Tracking" to "locationTracking",
        "Route Directions" to "routeDirections",
        "Custom Interactive Markers" to "interactiveMarkers",
        "Zone Management" to "zoneManagement",
        "Geofencing" to "geofencing",
        "Layering Different Map Types" to "mapTypes"
    )

    LazyVerticalGrid(
        columns = GridCells.Fixed(2),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        horizontalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        items(features) { feature ->
            FeatureCard(featureName = feature.first, onClick = {
                navController.navigate(feature.second)
            })
        }
    }
}

@Composable
fun FeatureCard(featureName: String, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .padding(8.dp)
            .height(200.dp)  // Set a fixed height for uniformity
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .border(2.dp, MaterialTheme.colorScheme.onSurface), // Use onSurface for border color
        elevation = CardDefaults.elevatedCardElevation(4.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface) // Use surface color
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize() // Fill the card space
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = featureName,
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurface // Use onSurface for text for better contrast
            )
        }
    }
}
