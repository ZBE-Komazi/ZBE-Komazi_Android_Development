package com.example.locationapp_2019098256_part1

import android.Manifest
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.example.locationapp_2019098256_part1.ui.theme.LocationApp_2019098256_part1Theme
import androidx.lifecycle.ViewModelProvider
import android.content.pm.PackageManager
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import android.widget.Toast
import com.example.locationapp_2019098256_part1.MainActivity.Companion.REQUEST_FINE_LOCATION_PERMISSIONS
import com.example.locationapp_2019098256_part1.model.AppNavigation
import com.example.locationapp_2019098256_part1.viewmodel.GeofencingViewModel
import com.google.android.gms.location.GeofencingEvent
import com.google.android.gms.location.GeofenceStatusCodes

class MainActivity : ComponentActivity() {
    private lateinit var geofencingViewModel: GeofencingViewModel
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        geofencingViewModel = ViewModelProvider(this)[GeofencingViewModel::class.java]

        requestPermission()
        setContent {
            LocationApp_2019098256_part1Theme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    AppNavigation(geofencingViewModel, this@MainActivity)
                }
            }
        }
    }

    private fun requestPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
                REQUEST_FINE_LOCATION_PERMISSIONS
            )
        } else {
            geofencingViewModel.setupGeofences(this)  // Setup geofences if permission is already granted
        }
    }

    @Deprecated("Deprecated in superclass")
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_FINE_LOCATION_PERMISSIONS) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                geofencingViewModel.setupGeofences(this)  // Setup geofences once permission is granted
            } else {
                handlePermissionDenied()
            }
        }
    }

    private fun handlePermissionDenied() {
        Toast.makeText(this, "Permission denied. This feature requires location access.", Toast.LENGTH_LONG).show()
        // Consider navigating the user back or disabling specific features
    }

    companion object {
        private const val REQUEST_FINE_LOCATION_PERMISSIONS = 101
    }
}

