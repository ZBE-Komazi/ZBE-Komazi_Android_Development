package com.example.locationapp_2019098256_part1.view

/*Zintle Komazi
2019098256
02 May 2024
 */

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.google.android.gms.maps.model.CameraPosition
import com.google.android.gms.maps.model.LatLng
import com.google.maps.android.compose.GoogleMap
import com.google.maps.android.compose.Polyline
import com.google.maps.android.compose.rememberCameraPositionState
import androidx.compose.runtime.*
import com.example.locationapp_2019098256_part1.viewmodel.DirectionsViewModel
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedTextField

import com.google.android.libraries.places.api.Places
import com.google.android.libraries.places.api.model.Place
import com.google.android.libraries.places.api.net.FetchPlaceRequest
import com.google.android.libraries.places.api.net.PlacesClient

@Composable
fun DirectionsScreen(navController: NavController) {
    val viewModel: DirectionsViewModel = viewModel()
    val directions = viewModel.directions.collectAsState()
    val context = LocalContext.current
    var placeQuery by remember { mutableStateOf("") }
    var currentLocation = LatLng(-34.0, 151.0) // Assume this is obtained from a location provider

    val cameraPositionState = rememberCameraPositionState {
        position = CameraPosition.fromLatLngZoom(currentLocation, 10f)
    }

    if (!Places.isInitialized()) {
        Places.initialize(context, "AIzaSyCwQnInk1cEZkWgwZ1i_U6ByqibCUpJZ0w")
    }
    val placesClient: PlacesClient = Places.createClient(context)

    GoogleMap(
        modifier = Modifier.fillMaxSize(),
        cameraPositionState = cameraPositionState
    ) {
        if (directions.value.isNotEmpty()) {
            Polyline(points = directions.value)
        }
    }

    Column(
        modifier = Modifier.padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        OutlinedTextField(
            value = placeQuery,
            onValueChange = { placeQuery = it },
            label = { Text("Enter destination") },
            modifier = Modifier.fillMaxWidth()
        )
        Button(onClick = {
            val placeFields = listOf(Place.Field.ID, Place.Field.NAME, Place.Field.LAT_LNG)
            val request = FetchPlaceRequest.newInstance(placeQuery, placeFields)

            placesClient.fetchPlace(request).addOnSuccessListener { response ->
                val place = response.place
                viewModel.getDirections(currentLocation, place.latLng!!)
            }
        }) {
            Text("Search and Navigate")
        }
    }
}