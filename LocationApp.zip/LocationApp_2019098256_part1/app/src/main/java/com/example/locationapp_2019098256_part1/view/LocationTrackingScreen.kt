package com.example.locationapp_2019098256_part1.view

/*Zintle Komazi
2019098256
02 May 2024
 */

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.example.locationapp_2019098256_part1.viewmodel.LocationViewModel
import com.google.android.gms.maps.model.CameraPosition
import com.google.android.gms.maps.model.LatLng
import com.google.maps.android.compose.GoogleMap
import com.google.maps.android.compose.MapProperties
import com.google.maps.android.compose.Marker
import com.google.maps.android.compose.MarkerState
import com.google.maps.android.compose.rememberCameraPositionState


@Composable
fun LocationTrackingScreen(navController: NavController) {
    val viewModel: LocationViewModel = viewModel()
    val cameraPositionState = rememberCameraPositionState {
        position = CameraPosition.fromLatLngZoom(LatLng(40.7128, -74.0060), 12f)  // Default to New York City
    }

    LaunchedEffect(key1 = true) {
        viewModel.startLocationUpdates()
    }

    val location by viewModel.currentLocation.collectAsState()
    val address by viewModel.currentAddress.collectAsState()

    GoogleMap(
        modifier = Modifier.fillMaxSize(),
        cameraPositionState = cameraPositionState,
        properties = MapProperties(isMyLocationEnabled = true)
    ) {
        Marker(
            state = MarkerState(position = LatLng(location.latitude, location.longitude)),
            title = "Current Location",
            snippet = address,
            onClick = {
                it.showInfoWindow()
                true  // Return true to indicate that the click event has been handled
            }
        )
        cameraPositionState.position = CameraPosition.fromLatLngZoom(LatLng(location.latitude, location.longitude), 12f)
    }
}