package com.example.locationapp_2019098256_part1.viewmodel

/*Zintle Komazi
2019098256
02 May 2024
 */

import android.location.Location
import com.example.locationapp_2019098256_part1.model.ZoneClusterItem

data class MapState(
    val lastKnownLocation: Location?,
    val clusterItems: List<ZoneClusterItem>,
)