package com.example.locationapp_2019098256_part1.model

/*Zintle Komazi
2019098256
02 May 2024
 */

import androidx.compose.ui.graphics.Color
import com.google.android.gms.maps.model.LatLng


data class Zone(
    val points: List<LatLng>,
    val fillColor: Color, // Now using Color
    val strokeColor: Color // Now using Color
)
data class ZoneState(
    val zones: List<Zone>
)

