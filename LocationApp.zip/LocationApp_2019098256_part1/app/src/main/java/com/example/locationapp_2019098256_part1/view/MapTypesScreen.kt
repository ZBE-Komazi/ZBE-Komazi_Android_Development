package com.example.locationapp_2019098256_part1.view

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.navigation.NavController
import com.google.android.gms.maps.model.CameraPosition
import com.google.android.gms.maps.model.LatLng
import com.google.maps.android.compose.GoogleMap
import com.google.maps.android.compose.MapProperties
import com.google.maps.android.compose.MapType
import com.google.maps.android.compose.rememberCameraPositionState

/*Zintle Komazi
2019098256
02 May 2024
 */

@Composable
fun MapTypesScreen(navController: NavController) {
    var mapType by remember { mutableStateOf(MapType.NORMAL) }
    val cameraPositionState = rememberCameraPositionState {
        position = CameraPosition.fromLatLngZoom(LatLng(-29.1044, 26.2014), 12f) // University of the Free State
    }

    val mapProperties = remember(mapType) {
        MapProperties(mapType = mapType)
    }

    Column {
        Row {
            Button(onClick = { mapType = MapType.NORMAL }) { Text("Normal") }
            Button(onClick = { mapType = MapType.SATELLITE }) { Text("Satellite") }
            Button(onClick = { mapType = MapType.TERRAIN }) { Text("Terrain") }
            Button(onClick = { mapType = MapType.HYBRID }) { Text("Hybrid") }
        }
        GoogleMap(
            modifier = Modifier.fillMaxSize(),
            cameraPositionState = cameraPositionState,
            properties = mapProperties  // Use the mapProperties with the current mapType
        )
    }
}
