package com.example.locationapp_2019098256_part1.view

/*Zintle Komazi
2019098256
02 May 2024
 */

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.example.locationapp_2019098256_part1.viewmodel.ZoneViewModel
import com.google.android.gms.maps.model.CameraPosition
import com.google.android.gms.maps.model.LatLng
import com.google.maps.android.compose.GoogleMap
import com.google.maps.android.compose.MapProperties
import com.google.maps.android.compose.Polygon
import com.google.maps.android.compose.rememberCameraPositionState


@Composable
fun ZoneManagementScreen(navController: NavController, viewModel: ZoneViewModel = viewModel()) {
    val zoneState = viewModel.zoneState.collectAsState().value
    val cameraPositionState = rememberCameraPositionState {
        position = CameraPosition.fromLatLngZoom(LatLng(-29.1044, 26.2014), 12f)  // Bloemfontein, around University of the Free State
    }

    GoogleMap(
        modifier = Modifier.fillMaxSize(),
        cameraPositionState = cameraPositionState,
        properties = MapProperties(isMyLocationEnabled = true)
    ) {
        zoneState.zones.forEach { zone ->
            Polygon(
                points = zone.points,
                fillColor = zone.fillColor,
                strokeColor = zone.strokeColor,
                onClick = {
                    // Handle click event on the polygon
                    viewModel.selectZone(zone)
                    true
                }
            )
        }
    }

    // UI components for managing zones
    Column(modifier = Modifier.padding(16.dp)) {
        Button(onClick = {
            viewModel.createZone()
        }) {
            Text("Add New Zone")
        }

        if (viewModel.selectedZone.value != null) {
            Button(onClick = {
                viewModel.deleteZone(viewModel.selectedZone.value!!)
            }) {
                Text("Delete Selected Zone")
            }
        }
    }
}
