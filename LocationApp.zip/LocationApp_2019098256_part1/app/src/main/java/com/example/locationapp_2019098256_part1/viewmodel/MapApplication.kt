package com.example.locationapp_2019098256_part1.viewmodel

/*Zintle Komazi
2019098256
02 May 2024
 */


import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class MapApplication: Application()