package com.example.locationapp_2019098256_part1.model

/*Zintle Komazi
2019098256
02 May 2024
 */

import android.content.Context
import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.locationapp_2019098256_part1.view.DirectionsScreen
import com.example.locationapp_2019098256_part1.view.ExploreScreen
import com.example.locationapp_2019098256_part1.view.GeofencingScreen
import com.example.locationapp_2019098256_part1.view.InteractiveMarkersScreen
import com.example.locationapp_2019098256_part1.view.LocationTrackingScreen
import com.example.locationapp_2019098256_part1.view.MapTypesScreen
import com.example.locationapp_2019098256_part1.view.WelcomeScreen
import com.example.locationapp_2019098256_part1.view.ZoneManagementScreen
import com.example.locationapp_2019098256_part1.viewmodel.GeofencingViewModel


@Composable
fun AppNavigation(geofencingViewModel: GeofencingViewModel, context: Context) {
    val navController = rememberNavController()

    NavHost(navController, startDestination = "welcome") {
        composable("welcome") { WelcomeScreen(navController) }
        composable("explore") { ExploreScreen(navController) }
        composable("locationTracking") { LocationTrackingScreen(navController) }
        composable("interactiveMarkers") { InteractiveMarkersScreen(navController) }
        composable("mapTypes") { MapTypesScreen(navController) }
        composable("routeDirections") { DirectionsScreen(navController) }
        composable("geofencing") {
            GeofencingScreen(geofencingViewModel, context, navController)
        }
        composable("zoneManagement") { ZoneManagementScreen(navController) }
    }
}
